<?php
ini_set('session.save_path', sys_get_temp_dir());
ini_set('session.cookie_secure', 0);
ini_set('session.cookie_samesite', 'Lax');
ini_set('session.cookie_path', '/');
ini_set('display_errors', 1);
ini_set('log_errors', 1);
ini_set('error_log', __DIR__ . '/php-error.log');
error_reporting(E_ALL);
session_start();
ob_start();
require_once( 'dbconnection.php' );
error_reporting(E_ALL);
if (isset($_SESSION['id']) && intval($_SESSION['id']) > 0) {
  $host = $_SERVER['HTTP_HOST'];
  $uri = rtrim(dirname($_SERVER['PHP_SELF']), '/\\');
  $scheme = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https' : 'http';
  $url = "$scheme://$host$uri/welcome.php";
  ob_end_clean();
  echo '<!DOCTYPE html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>Redirecting</title><style>
html,body{height:100%}body{margin:0}
.overlay{position:fixed;inset:0;background:rgba(0,0,0,.6);display:flex;align-items:center;justify-content:center;z-index:9999}
.panel{background:#fff;color:#222;border-radius:12px;box-shadow:0 10px 30px rgba(0,0,0,.3);width:90%;max-width:420px;padding:24px;text-align:center}
.spinner{width:48px;height:48px;border-radius:50%;border:4px solid #e5e7eb;border-top-color:#2563eb;margin:0 auto 16px;animation:spin 1s linear infinite}
@keyframes spin{to{transform:rotate(360deg)}}
.msg{font-size:18px;margin:8px 0}
.count{font-size:14px;color:#555}
.actions{display:flex;gap:12px;justify-content:center;margin-top:16px;flex-wrap:wrap}
.btn{padding:10px 16px;border:none;border-radius:8px;cursor:pointer}
.secondary{background:#e5e7eb;color:#111}
.primary{background:#2563eb;color:#fff}
</style></head><body>
<div class="overlay" role="dialog" aria-modal="true" aria-label="Redirecting">
  <div class="panel" role="status" aria-live="assertive">
    <div class="spinner" aria-hidden="true"></div>
    <div class="msg">Redirecting...</div>
    <div class="count">Continuing in <span id="count">3</span>s</div>
    <div class="actions">
      <button id="cancel" class="btn secondary" aria-label="Cancel redirect">Cancel</button>
      <button id="now" class="btn primary" aria-label="Redirect now">Go now</button>
    </div>
  </div>
</div>
<script>
var url="'.htmlspecialchars($url,ENT_QUOTES,'UTF-8').'";
var c=3,t=null;
function tick(){c--;document.getElementById("count").textContent=c;if(c<=0){cleanup();location.href=url}}
function cleanup(){if(t){clearInterval(t)}var o=document.querySelector(".overlay");if(o){o.remove()}}
document.getElementById("cancel").addEventListener("click",function(){cleanup()});
document.getElementById("now").addEventListener("click",function(){cleanup();location.href=url});
document.getElementById("count").textContent=c;t=setInterval(tick,1000);setTimeout(function(){cleanup();location.href=url},3000);
</script></body></html>';
  exit;
}
if (isset($_POST['redirect_event']) && $_POST['redirect_event'] === 'start') {
  $em = isset($_POST['email']) ? $_POST['email'] : '';
  $uid = isset($_POST['uid']) ? intval($_POST['uid']) : 0;
  $line = date('c') . " | REDIRECT_START | $em | $uid |  | start\n";
  @file_put_contents(__DIR__ . '/submissions.log', $line, FILE_APPEND);
  header('Content-Type: application/json');
  echo json_encode(array('ok'=>true));
  exit;
}
if (isset($_POST['resend_abstract']) && $_POST['resend_abstract'] === '1') {
  header('Content-Type: application/json');
  $to = "abstract@icpm.ae";
  $subj = "Abstract Resend: Ref #" . (isset($_SESSION['id']) ? $_SESSION['id'] : '');
  $body = "Resent abstract from " . (isset($_SESSION['email']) ? $_SESSION['email'] : '') . " (Ref #" . (isset($_SESSION['id']) ? $_SESSION['id'] : '') . ")";
  $path = isset($_SESSION['abstract_path']) ? $_SESSION['abstract_path'] : null;
  $name = isset($_SESSION['abstract_name']) ? $_SESSION['abstract_name'] : null;
  if (!$path || !is_file($path)) {
    echo json_encode(array('ok'=>false,'error'=>'No abstract file available to resend'));
    exit;
  }
  $res = send_mail_with_attachment_ex($to, $subj, $body, $path, $name, "ICPM <no-reply@icpm.ae>");
  $_SESSION['email_committee_sent'] = $res[0] ? true : false;
  echo json_encode(array('ok'=>$res[0],'transport'=>$res[1],'error'=>$res[2]));
  exit;
}

function sanitize_filename($name) {
    $name = preg_replace('/[^A-Za-z0-9._-]/', '_', $name);
    return substr($name, 0, 180);
}
function validate_filetype($tmp, $name) {
    $allowedExt = array('jpg','jpeg','png','gif','pdf');
    $ext = strtolower(pathinfo($name, PATHINFO_EXTENSION));
    if (!in_array($ext, $allowedExt)) return false;
    $mime = null;
    if (function_exists('finfo_open')) {
        $fi = @finfo_open(FILEINFO_MIME_TYPE);
        if ($fi) {
            $mime = @finfo_file($fi, $tmp);
            @finfo_close($fi);
        }
    }
    if (!$mime) {
        $map = array(
            'jpg' => 'image/jpeg',
            'jpeg' => 'image/jpeg',
            'png' => 'image/png',
            'gif' => 'image/gif',
            'pdf' => 'application/pdf'
        );
        $mime = isset($map[$ext]) ? $map[$ext] : 'application/octet-stream';
    }
    $allowedMime = array('image/jpeg','image/png','image/gif','application/pdf');
    return in_array($mime, $allowedMime);
}
function save_uploaded_file($file) {
    $tmp = $file['tmp_name'];
    $name = sanitize_filename($file['name']);
    $dest = sys_get_temp_dir() . DIRECTORY_SEPARATOR . uniqid('abstract_', true) . '_' . $name;
    if (!move_uploaded_file($tmp, $dest)) return array(false, null, null);
    return array(true, $dest, $name);
}
function scan_file_malware($path) {
    $cmd = null;
    $which = @shell_exec(strtoupper(substr(PHP_OS, 0, 3)) === 'WIN' ? 'where clamscan' : 'which clamscan');
    if (is_string($which) && trim($which) !== '') {
        $cmd = 'clamscan --no-summary ' . escapeshellarg($path);
    }
    if ($cmd) {
        exec($cmd, $out, $code);
        return $code === 0;
    }
    return true;
}
function send_mail_with_attachment($to, $subject, $bodyText, $filePath, $fileName, $from, $replyTo=null) {
    $boundary = md5(uniqid(time(), true));
    $headers = "From: $from\r\n";
    if ($replyTo) $headers .= "Reply-To: $replyTo\r\n";
    $headers .= "MIME-Version: 1.0\r\n";
    $headers .= "Content-Type: multipart/mixed; boundary=\"$boundary\"\r\n";
    $body = "--$boundary\r\n";
    $body .= "Content-Type: text/plain; charset=\"utf-8\"\r\n";
    $body .= "Content-Transfer-Encoding: 7bit\r\n\r\n";
    $body .= $bodyText . "\r\n";
    if ($filePath && is_file($filePath)) {
        $data = chunk_split(base64_encode(file_get_contents($filePath)));
        $mime = 'application/octet-stream';
        if (function_exists('finfo_open')) {
            $fi = @finfo_open(FILEINFO_MIME_TYPE);
            if ($fi) { $mime = @finfo_file($fi, $filePath); @finfo_close($fi); }
        }
        $body .= "--$boundary\r\n";
        $body .= "Content-Type: $mime; name=\"$fileName\"\r\n";
        $body .= "Content-Transfer-Encoding: base64\r\n";
        $body .= "Content-Disposition: attachment; filename=\"$fileName\"\r\n\r\n";
        $body .= $data . "\r\n";
    }
    $body .= "--$boundary--";
    return mail($to, $subject, $body, $headers);
}
function send_mail_with_attachment_ex($to, $subject, $bodyText, $filePath, $fileName, $from, $replyTo=null) {
    $transport = 'mail';
    $error = '';
    $ok = false;
    $ts = date('c');
    $linePrefix = $ts . " | EMAIL_ATTEMPT | $to | " . ($fileName ?: '') . " | ";
    @file_put_contents(__DIR__ . '/submissions.log', $linePrefix . "transport=$transport; subject=" . $subject . "\n", FILE_APPEND);
    $host = getenv('SMTP_HOST');
    $user = getenv('SMTP_USER');
    $pass = getenv('SMTP_PASS');
    $port = getenv('SMTP_PORT');
    $secure = getenv('SMTP_SECURE') ?: 'tls';
    $fromAddr = getenv('SMTP_FROM');
    $fromName = getenv('SMTP_FROM_NAME') ?: 'ICPM';
    $useSmtp = ($host && $user && $pass);
    if ($useSmtp && file_exists(__DIR__ . '/smtp/PHPMailerAutoload.php')) {
        require_once(__DIR__ . '/smtp/PHPMailerAutoload.php');
        $mail = new PHPMailer();
        $mail->IsSMTP();
        $mail->SMTPAuth = true;
        if ($secure) { $mail->SMTPSecure = $secure; }
        $mail->Host = $host;
        $mail->Port = $port ? intval($port) : 587;
        $mail->IsHTML(false);
        $mail->CharSet = 'UTF-8';
        $mail->Username = $user;
        $mail->Password = $pass;
        $mail->SetFrom($fromAddr ?: 'no-reply@icpm.ae', $fromName);
        $mail->Subject = $subject;
        $mail->Body = $bodyText;
        if ($replyTo) { $mail->addReplyTo($replyTo); }
        $mail->AddAddress($to);
        if ($filePath && is_file($filePath)) {
            $mail->AddAttachment($filePath, $fileName ?: basename($filePath));
        }
        $transport = 'smtp';
        try {
            $ok = $mail->Send();
        } catch (Exception $e) {
            $ok = false;
            $error = $e->getMessage();
        }
        if (!$ok && empty($error)) { $error = $mail->ErrorInfo; }
    } else {
        $ok = send_mail_with_attachment($to, $subject, $bodyText, $filePath, $fileName, $from, $replyTo);
        if (!$ok) { $error = 'mail() returned false'; }
    }
    $status = $ok ? 'EMAIL_SENT' : 'EMAIL_FAIL';
    $msg = $ok ? "transport=$transport" : ("transport=$transport; error=" . $error);
    @file_put_contents(__DIR__ . '/submissions.log', $ts . " | $status | $to | " . ($fileName ?: '') . " | " . $msg . "\n", FILE_APPEND);
    return array($ok, $transport, $error);
}
function log_submission($email, $status, $message, $filename, $refId) {
    $line = date('c') . " | $status | $email | $refId | $filename | $message\n";
    @file_put_contents(__DIR__ . '/submissions.log', $line, FILE_APPEND);
}

if (isset($_POST['abstract_event']) && $_POST['abstract_event'] === 'missing') {
    $em = isset($_POST['email']) ? $_POST['email'] : '';
    log_submission($em, 'CLIENT_VALIDATION_FAIL', 'Missing abstract (client)', '', 0);
    header('Content-Type: application/json');
    echo json_encode(array('ok'=>true));
    exit;
}

// Function to get the user IP address
function getUserIP() {
    $userIP =   '';
    if(isset($_SERVER['HTTP_CLIENT_IP'])){
        $userIP =   $_SERVER['HTTP_CLIENT_IP'];
    }elseif(isset($_SERVER['HTTP_X_FORWARDED_FOR'])){
        $userIP =   $_SERVER['HTTP_X_FORWARDED_FOR'];
    }elseif(isset($_SERVER['HTTP_X_FORWARDED'])){
        $userIP =   $_SERVER['HTTP_X_FORWARDED'];
    }elseif(isset($_SERVER['HTTP_X_CLUSTER_CLIENT_IP'])){
        $userIP =   $_SERVER['HTTP_X_CLUSTER_CLIENT_IP'];
    }elseif(isset($_SERVER['HTTP_FORWARDED_FOR'])){
        $userIP =   $_SERVER['HTTP_FORWARDED_FOR'];
    }elseif(isset($_SERVER['HTTP_FORWARDED'])){
        $userIP =   $_SERVER['HTTP_FORWARDED'];
    }elseif(isset($_SERVER['REMOTE_ADDR'])){
        $userIP =   $_SERVER['REMOTE_ADDR'];
    }else{
        $userIP =   'UNKNOWN';
    }
    return $userIP;
}


//Code for Registration

if ( isset( $_POST[ 'signup' ] ) )
{
  $fname = $_POST[ 'fname' ];
  $nationality = $_POST[ 'nationality' ];
  $coauth1name = $_POST[ 'coauth1name' ];
  $coauth1nationality = $_POST[ 'coauth1nationality' ];
  $coauth1email = isset($_POST['coauth1email']) ? $_POST['coauth1email'] : '';
  $coauth2name = $_POST[ 'coauth2name' ];
  $coauth2nationality = $_POST[ 'coauth2nationality' ];
  $coauth2email = isset($_POST['coauth2email']) ? $_POST['coauth2email'] : '';
  $coauth3name = $_POST[ 'coauth3name' ];
  $coauth3nationality = $_POST[ 'coauth3nationality' ];
  $coauth3email = isset($_POST['coauth3email']) ? $_POST['coauth3email'] : '';
  $coauth4name = $_POST[ 'coauth4name' ];
  $coauth4nationality = $_POST[ 'coauth4nationality' ];
  $coauth4email = isset($_POST['coauth4email']) ? $_POST['coauth4email'] : '';
  $coauth5name = $_POST[ 'coauth5name' ];
  $coauth5nationality = $_POST[ 'coauth5nationality' ];
  $coauth5email = isset($_POST['coauth5email']) ? $_POST['coauth5email'] : '';
  $email = $_POST[ 'email' ];
  $profession = $_POST[ 'profession' ];
  $organization = $_POST[ 'organization' ];
  $category = $_POST[ 'category' ];
  $postertitle = isset($_POST['postertitle']) ? $_POST['postertitle'] : '';
  $password = $_POST[ 'password' ];
  $contact = isset($_POST['contact']) ? $_POST['contact'] : (isset($_POST['contactno']) ? $_POST['contactno'] : '');
  $userip = $_POST[ 'userip' ];
  $companyref = $_POST[ 'companyref' ];
  $paypalref = $_POST[ 'paypalref' ];
  $enc_password = password_hash($password, PASSWORD_DEFAULT);
  $abstractPath = null;
  $abstractName = null;
  $abstractMime = null;
  $abstractBlob = null;
  $coauthors_count = isset($_POST['coauthors_count']) ? intval($_POST['coauthors_count']) : 0;
  // Ensure schema email columns exist
  $needCols = array('coauth1email','coauth2email','coauth3email','coauth4email','coauth5email');
  foreach ($needCols as $col) {
    $check = mysqli_query($con, "SELECT 1 FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME='users' AND COLUMN_NAME='$col'");
    if ($check && mysqli_num_rows($check) == 0) {
      @mysqli_query($con, "ALTER TABLE users ADD COLUMN `$col` VARCHAR(255) NULL");
    }
  }
  $ptCheck = mysqli_query($con, "SELECT 1 FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME='users' AND COLUMN_NAME='postertitle'");
  if ($ptCheck && mysqli_num_rows($ptCheck) == 0) {
    @mysqli_query($con, "ALTER TABLE users ADD COLUMN `postertitle` VARCHAR(255) NULL");
  }
  $afn = mysqli_query($con, "SELECT 1 FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME='users' AND COLUMN_NAME='abstract_filename'");
  if ($afn && mysqli_num_rows($afn) == 0) {
    @mysqli_query($con, "ALTER TABLE users ADD COLUMN `abstract_filename` VARCHAR(255) NULL");
  }
  $ami = mysqli_query($con, "SELECT 1 FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME='users' AND COLUMN_NAME='abstract_mime'");
  if ($ami && mysqli_num_rows($ami) == 0) {
    @mysqli_query($con, "ALTER TABLE users ADD COLUMN `abstract_mime` VARCHAR(64) NULL");
  }
  $abl = mysqli_query($con, "SELECT 1 FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME='users' AND COLUMN_NAME='abstract_blob'");
  if ($abl && mysqli_num_rows($abl) == 0) {
    @mysqli_query($con, "ALTER TABLE users ADD COLUMN `abstract_blob` LONGBLOB NULL");
  }
  function valid_email($e){ return filter_var($e, FILTER_VALIDATE_EMAIL) !== false; }
  $emails = array($coauth1email,$coauth2email,$coauth3email,$coauth4email,$coauth5email);
  for ($i=1; $i<=$coauthors_count; $i++) {
    $e = $emails[$i-1];
    if (!$e || !valid_email($e)) { echo "<script>alert('Invalid co-author email for CO-$i');</script>"; exit(); }
    if ($e === $email) { echo "<script>alert('Co-author email must differ from main author email');</script>"; exit(); }
  }
  if (!isset($_FILES['abstract_file']) || !is_uploaded_file($_FILES['abstract_file']['tmp_name'])) {
    echo "<script>alert('Please upload abstract file (JPG, PNG, GIF, PDF)');</script>";
    exit();
  } else {
    $f = $_FILES['abstract_file'];
    if ($f['error'] !== UPLOAD_ERR_OK) {
      echo "<script>alert('Upload failed');</script>"; exit();
    }
    if ($f['size'] > 5 * 1024 * 1024) {
      echo "<script>alert('File too large (max 5MB)');</script>"; exit();
    }
    if (!validate_filetype($f['tmp_name'], $f['name'])) {
      echo "<script>alert('Invalid file format');</script>"; exit();
    }
    list($ok, $p, $n) = save_uploaded_file($f);
    if (!$ok) { echo "<script>alert('Could not save file');</script>"; exit(); }
    if (!scan_file_malware($p)) { echo "<script>alert('File failed security scan');</script>"; exit(); }
    $abstractPath = $p;
    $abstractName = $n;
    $abstractMime = null;
    if (function_exists('finfo_open')) {
      $fi2 = @finfo_open(FILEINFO_MIME_TYPE);
      if ($fi2) { $abstractMime = @finfo_file($fi2, $abstractPath); @finfo_close($fi2); }
    }
    if (!$abstractMime) {
      $ext = strtolower(pathinfo($abstractName, PATHINFO_EXTENSION));
      $map = array('jpg'=>'image/jpeg','jpeg'=>'image/jpeg','png'=>'image/png','gif'=>'image/gif','pdf'=>'application/pdf');
      $abstractMime = isset($map[$ext]) ? $map[$ext] : 'application/octet-stream';
    }
    $abstractBlob = @file_get_contents($abstractPath);
  }
  $stmt = mysqli_prepare( $con, "select id from users where email=?" );
  mysqli_stmt_bind_param($stmt,'s',$email);
  mysqli_stmt_execute($stmt);
  $res = mysqli_stmt_get_result($stmt);
  $row = mysqli_num_rows( $res );
  if ( $row > 0 )
  {
    echo "<script>alert('Email id already exist with another account. Please try with other email id');</script>";
  } else {


    
    $hasCoEmails = true;
    foreach (array('coauth1email','coauth2email','coauth3email','coauth4email','coauth5email') as $c) {
      $q = mysqli_query($con, "SELECT 1 FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME='users' AND COLUMN_NAME='$c'");
      if (!$q || mysqli_num_rows($q) == 0) { $hasCoEmails = false; break; }
    }
    if ($hasCoEmails) {
      $stmt = mysqli_prepare( $con, "insert into users(fname,nationality,coauth1name,coauth1nationality,coauth1email,coauth2name,coauth2nationality,coauth2email,coauth3name,coauth3nationality,coauth3email,coauth4name,coauth4nationality,coauth4email,coauth5name,coauth5nationality,coauth5email,email,profession,organization,postertitle,category,password,contactno,userip,companyref,paypalref,abstract_filename,abstract_mime,abstract_blob) values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)" );
      if ($stmt) {
        mysqli_stmt_bind_param($stmt, str_repeat('s', 30),
          $fname,$nationality,$coauth1name,$coauth1nationality,$coauth1email,
          $coauth2name,$coauth2nationality,$coauth2email,
          $coauth3name,$coauth3nationality,$coauth3email,
          $coauth4name,$coauth4nationality,$coauth4email,
          $coauth5name,$coauth5nationality,$coauth5email,
          $email,$profession,$organization,$postertitle,$category,$enc_password,$contact,$userip,$companyref,$paypalref,$abstractName,$abstractMime,$abstractBlob
        );
      }
    } else {
      $stmt = mysqli_prepare( $con, "insert into users(fname,nationality,coauth1name,coauth1nationality,coauth2name,coauth2nationality,coauth3name,coauth3nationality,coauth4name,coauth4nationality,coauth5name,coauth5nationality,email,profession,organization,postertitle,category,password,contactno,userip,companyref,paypalref,abstract_filename,abstract_mime,abstract_blob) values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)" );
      if ($stmt) {
        mysqli_stmt_bind_param($stmt, str_repeat('s', 25),
          $fname,$nationality,$coauth1name,$coauth1nationality,
          $coauth2name,$coauth2nationality,
          $coauth3name,$coauth3nationality,
          $coauth4name,$coauth4nationality,
          $coauth5name,$coauth5nationality,
          $email,$profession,$organization,$postertitle,$category,$enc_password,$contact,$userip,$companyref,$paypalref,$abstractName,$abstractMime,$abstractBlob
        );
      }
    }
    $msg = $stmt ? mysqli_stmt_execute($stmt) : false;
    if (!$stmt) {
      $fallback = mysqli_prepare($con, "insert into users(fname,nationality,coauth1name,coauth1nationality,coauth1email,coauth2name,coauth2nationality,coauth2email,coauth3name,coauth3nationality,coauth3email,coauth4name,coauth4nationality,coauth4email,coauth5name,coauth5nationality,coauth5email,email,profession,organization,category,password,contactno,userip,companyref,paypalref) values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)");
      if ($fallback) {
        mysqli_stmt_bind_param($fallback, str_repeat('s', 26),
          $fname,$nationality,$coauth1name,$coauth1nationality,$coauth1email,
          $coauth2name,$coauth2nationality,$coauth2email,
          $coauth3name,$coauth3nationality,$coauth3email,
          $coauth4name,$coauth4nationality,$coauth4email,
          $coauth5name,$coauth5nationality,$coauth5email,
          $email,$profession,$organization,$category,$enc_password,$contact,$userip,$companyref,$paypalref
        );
        $msg = mysqli_stmt_execute($fallback);
        if ($msg) {
          $upd = mysqli_prepare($con, "UPDATE users SET postertitle=?, abstract_filename=?, abstract_mime=?, abstract_blob=? WHERE email=?");
          if ($upd) {
            mysqli_stmt_bind_param($upd, "sssss", $postertitle, $abstractName, $abstractMime, $abstractBlob, $email);
            @mysqli_stmt_execute($upd);
          }
        }
      }
    }
    if (!$stmt) { log_submission($email, 'DB_PREPARE_FAIL', 'Prepare failed: '.mysqli_error($con), $abstractName, 0); }
    elseif (!$msg) { log_submission($email, 'DB_EXECUTE_FAIL', 'Execute failed: '.mysqli_error($con), $abstractName, 0); }


    if ( $msg )
    {
      // if ( isset( $_POST[ 'signup' ] ) )
      // {
      //   $password = $_POST[ 'password' ];
      //   $dec_password = $password;
      //   $useremail = $_POST[ 'email' ];
        $stmt = mysqli_prepare( $con, "SELECT * FROM users WHERE email=?" );
        $num = false;
        if ($stmt) {
          mysqli_stmt_bind_param($stmt,'s',$email);
          mysqli_stmt_execute($stmt);
          $ret = mysqli_stmt_get_result($stmt);
          $num = $ret ? mysqli_fetch_array($ret) : false;
        }
        if (!$num) {
          $esc = mysqli_real_escape_string($con, $email);
          $qq = mysqli_query($con, "SELECT * FROM users WHERE email='$esc' LIMIT 1");
          $num = $qq ? mysqli_fetch_array($qq) : false;
        }

        if ( $num )
        {
          $refId = $num[ 'id' ];
          $committee = "abstract@icpm.ae";
          $cmsub = "Abstract Submission: Ref #$refId - $fname";
          $cmbody = "A new abstract submission has been received.\nReference: $refId\nAuthor Email: $email\n";
        $abres = send_mail_with_attachment_ex($committee, $cmsub, $cmbody, $abstractPath, $abstractName, "ICPM <no-reply@icpm.ae>", $email);
        $abok = $abres[0];
        $usersub = "Abstract Submission Received - Ref #$refId";
        $userbody = "Thank you for your submission.\nReference: $refId\nExpected review timeline: 2–3 weeks.\n";
        $ures = send_mail_with_attachment_ex($email, $usersub, $userbody, $abstractPath, $abstractName, "ICPM <no-reply@icpm.ae>");
        $uok = $ures[0];
        $footerImg = "https://reg-sys.com/icpm2026/images/icpm-logo.png";
        $headers = "From: ICPM@reg-sys.com\r\nMIME-Version: 1.0\r\nContent-Type: text/html; charset=utf-8\r\n";
        $coList = array(
          array($coauth1name, $coauth1email),
          array($coauth2name, $coauth2email),
          array($coauth3name, $coauth3email),
          array($coauth4name, $coauth4email),
          array($coauth5name, $coauth5email)
        );
        $sentCoauthors = array();
        for ($i=0; $i<count($coList); $i++) {
          $cn = isset($coList[$i][0]) ? trim($coList[$i][0]) : '';
          $ce = isset($coList[$i][1]) ? trim($coList[$i][1]) : '';
          if ($ce !== '' && filter_var($ce, FILTER_VALIDATE_EMAIL)) {
            $suffix = 'CO'.($i+1);
            $qrData = $refId.'-'.$suffix;
            $subject = "ICPM Poster Co-Author Access - ".$suffix." - ".htmlspecialchars($fname, ENT_QUOTES, 'UTF-8');
            $message = '<div style="font-family:Arial,Helvetica,sans-serif;color:#111;line-height:1.6">
<p>Hello ' . htmlspecialchars($cn !== '' ? $cn : 'Co-Author', ENT_QUOTES, 'UTF-8') . ',</p>
<p>You have been added as a co-author for the ICPM Poster Competition.</p>
<p><strong>Main Author:</strong> ' . htmlspecialchars($fname, ENT_QUOTES, 'UTF-8') . '</p>
<p><strong>Poster Category:</strong> ' . htmlspecialchars($category, ENT_QUOTES, 'UTF-8') . '</p>
<p><strong>Organization:</strong> ' . htmlspecialchars($organization, ENT_QUOTES, 'UTF-8') . '</p>
<p><strong>Login to your account:</strong><br>
<a href="https://reg-sys.com/icpm2026/regnew" target="_blank" rel="noopener">https://reg-sys.com/icpm2026/regnew</a></p>
<p><strong>Credentials</strong><br>
Email: ' . htmlspecialchars($ce, ENT_QUOTES, 'UTF-8') . '<br>
Password: 1234<br>
Registration Number: ' . htmlspecialchars($refId, ENT_QUOTES, 'UTF-8') . '</p>
<p><img src="https://api.qrserver.com/v1/create-qr-code/?size=200x200&data=' . htmlspecialchars($qrData, ENT_QUOTES, 'UTF-8') . '" alt="QR ' . htmlspecialchars($qrData, ENT_QUOTES, 'UTF-8') . '"></p>
<hr style="border:none;border-top:1px solid #eee;margin:16px 0">
<div style="text-align:center">
<img src="' . $footerImg . '" alt="ICPM" width="200" height="78" style="display:inline-block">
</div>
</div>';
            @mail($ce, $subject, $message, $headers);
            $sentCoauthors[] = array('name'=>$cn !== '' ? $cn : 'Co-Author', 'email'=>$ce, 'suffix'=>$suffix);
          }
        }
        $mainSubject = "ICPM Poster Registration Confirmation - Ref #".$refId;
        $mainMessage = '<div style="font-family:Arial,Helvetica,sans-serif;color:#111;line-height:1.6">
<p>Hello ' . htmlspecialchars($fname, ENT_QUOTES, 'UTF-8') . ',</p>
<p>Your registration has been completed.</p>
<p><strong>Login:</strong> <a href="https://reg-sys.com/icpm2026/regnew" target="_blank" rel="noopener">https://reg-sys.com/icpm2026/regnew/</a></p>
<p><strong>Credentials</strong><br>
Email: ' . htmlspecialchars($email, ENT_QUOTES, 'UTF-8') . '<br>
Password: ' . htmlspecialchars($password, ENT_QUOTES, 'UTF-8') . '<br>
Registration Number: ' . htmlspecialchars($refId, ENT_QUOTES, 'UTF-8') . '</p>
<p><img src="https://api.qrserver.com/v1/create-qr-code/?size=200x200&data=' . htmlspecialchars($refId, ENT_QUOTES, 'UTF-8') . '" alt="QR ' . htmlspecialchars($refId, ENT_QUOTES, 'UTF-8') . '"></p>
';
        if (!empty($sentCoauthors)) {
          $mainMessage .= '<p>Co-Author emails sent:</p><ul>';
          foreach ($sentCoauthors as $sc) {
            $mainMessage .= '<li>' . htmlspecialchars($sc['suffix'], ENT_QUOTES, 'UTF-8') . ' - ' . htmlspecialchars($sc['name'], ENT_QUOTES, 'UTF-8') . ' (' . htmlspecialchars($sc['email'], ENT_QUOTES, 'UTF-8') . ')</li>';
          }
          $mainMessage .= '</ul>';
        }
        $mainMessage .= '
<hr style="border:none;border-top:1px solid #eee;margin:16px 0">
<div style="text-align:center">
<img src="' . $footerImg . '" alt="ICPM" width="200" height="78" style="display:inline-block">
</div>
</div>';
        @mail($email, $mainSubject, $mainMessage, $headers);
        $_SESSION['abstract_path'] = $abstractPath;
        $_SESSION['abstract_name'] = $abstractName;
        $_SESSION['email_committee_sent'] = $abok ? true : false;
        $_SESSION['email_user_sent'] = $uok ? true : false;
        log_submission($email, ($abok && $uok)?'SUCCESS':'PARTIAL', ($abok&&$uok)?'Emails sent':'Email error', $abstractName, $refId);
        $extra = "welcome.php";
        session_regenerate_id(true);
        $_SESSION[ 'signup' ] = $_POST[ 'email' ];
        $_SESSION[ 'id' ] = $num[ 'id' ];
          $_SESSION[ 'name' ] = $num[ 'fname' ];
          $_SESSION[ 'fullname' ] = $_SESSION['name'];
          $_SESSION[ 'slname' ] = '';
  		      $_SESSION[ 'snationality' ] = $num[ 'nationality' ];
          $_SESSION[ 'coauth1name' ] = $num[ 'coauth1name' ];
  		      $_SESSION[ 'scoauth1nationality' ] = $num[ 'coauth1nationality' ];
          $_SESSION[ 'coauth2name' ] = $num[ 'coauth2name' ];
    		  $_SESSION[ 'scoauth2nationality' ] = $num[ 'coauth2nationality' ];
    		  $_SESSION[ 'coauth3name' ] = $num[ 'coauth3name' ];
    		  $_SESSION[ 'scoauth3nationality' ] = $num[ 'coauth3nationality' ];
          $_SESSION[ 'coauth4name' ] = $num[ 'coauth4name' ];
    		  $_SESSION[ 'scoauth4nationality' ] = $num[ 'coauth4nationality' ];
    		  $_SESSION[ 'coauth5name' ] = $num[ 'coauth5name' ];
    		  $_SESSION[ 'scoauth5nationality' ] = $num[ 'coauth5nationality' ];
          $_SESSION[ 'email' ] = $num[ 'email' ];
          $_SESSION[ 'profession' ] = $num[ 'profession' ];
          $_SESSION[ 'scategory' ] = $num[ 'category' ];
          $_SESSION[ 'postertitle' ] = isset($num['postertitle']) ? $num['postertitle'] : '';
          $_SESSION[ 'contact' ] = $num[ 'contactno' ];
  		      $_SESSION[ 'userip' ] = $num[ 'userip' ];
          $_SESSION[ 'companyref' ] = $num[ 'companyref' ];
          $_SESSION[ 'paypalref' ] = $num[ 'paypalref' ];
          $host = $_SERVER[ 'HTTP_HOST' ];
          $uri = rtrim( dirname( $_SERVER[ 'PHP_SELF' ] ), '/\\' );
          $scheme = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https' : 'http';
          $target = "$scheme://$host$uri/$extra";
          $okrow = mysqli_query($con, "SELECT id FROM users WHERE id=".$_SESSION['id']);
          if (!$okrow || mysqli_num_rows($okrow) === 0) { echo "<script>alert('Registration not completed. Please try again');</script>"; exit(); }
          $delay = 3000;
          $redirLog = date('c') . " | REDIRECT_SCHEDULED | ".$_SESSION['email']." | ".$_SESSION['id']." | ".$abstractName." | delay=".$delay."ms\n";
          @file_put_contents(__DIR__ . '/submissions.log', $redirLog, FILE_APPEND);
          session_write_close();
          ob_end_clean();
          if (!headers_sent()) {
            @file_put_contents(__DIR__ . '/submissions.log', date('c') . " | REDIRECT_302_SENT | ".$_SESSION['email']." | ".$_SESSION['id']." | \n", FILE_APPEND);
            header("Location: ".$target, true, 302);
            exit();
          } else {
            @file_put_contents(__DIR__ . '/submissions.log', date('c') . " | REDIRECT_FALLBACK | ".$_SESSION['email']." | ".$_SESSION['id']." | \n", FILE_APPEND);
            echo '<!DOCTYPE html><html><head><meta charset="utf-8"><meta http-equiv="Cache-Control" content="no-store"><meta name="viewport" content="width=device-width, initial-scale=1"><meta http-equiv="refresh" content="'.($delay/1000).';url='.$target.'"><title>Completing Registration</title><style>.overlay{position:fixed;left:0;top:0;width:100%;height:100%;display:flex;align-items:center;justify-content:center;background:#fff}.box{text-align:center;font-family:system-ui,Segoe UI,Arial;color:#111}.spinner{width:64px;height:64px;border:6px solid #ddd;border-top-color:#111;border-radius:50%;animation:spin 1s linear infinite;margin:18px auto}@keyframes spin{to{transform:rotate(360deg)}}.count{margin-top:8px;color:#666}</style></head><body><div class="overlay"><div class="box"><div class="spinner"></div><div>Redirecting to Welcome...</div><div class="count" id="count"></div></div></div><script>(function(){var d='.$delay.';var s=document.getElementById("count");var t=Math.floor(d/1000);function u(){s.textContent="Redirect in "+t+"s";}u();var x=setInterval(function(){t--;u();if(t<=0){clearInterval(x);}},1000);try{fetch("",{method:"POST",headers:{"Content-Type":"application/x-www-form-urlencoded"},body:"redirect_event=start&email='.urlencode($_SESSION['email']).'&uid='.$_SESSION['id'].'"});}catch(e){}setTimeout(function(){location.href="'.$target.'";},d);}());</script></body></html>';
            exit();
          }
        } else {
          log_submission($email, 'POST_INSERT_VERIFY_FAIL', 'Row not found after insert', $abstractName, 0);
          echo "<script>alert('Registration failed to save. Please try again');</script>";
          exit();
        }
        }
      }
    }


// Code for login

if ( isset( $_POST[ 'login' ] ) )
{
  $password = $_POST[ 'password' ];
  $dec_password = $password;
  $useremail = $_POST[ 'uemail' ];
  $stmt = mysqli_prepare( $con, "SELECT * FROM users WHERE email=? LIMIT 1" );
  $num = false;
  if ($stmt) {
    mysqli_stmt_bind_param($stmt,'s',$useremail);
    mysqli_stmt_execute($stmt);
    $ret = mysqli_stmt_get_result($stmt);
    $num = $ret ? mysqli_fetch_array($ret) : false;
    if (!$num) {
      $esc = mysqli_real_escape_string($con, $useremail);
      $qq = mysqli_query($con, "SELECT * FROM users WHERE email='$esc' LIMIT 1");
      $num = $qq ? mysqli_fetch_array($qq) : false;
    }
  } else {
    $esc = mysqli_real_escape_string($con, $useremail);
    $ret = mysqli_query($con, "SELECT * FROM users WHERE email='$esc' LIMIT 1");
    $num = $ret ? mysqli_fetch_array($ret) : false;
  }
  if ( $num && (password_verify($password,$num['password']) || $password === $num['password']) )
  {
    session_regenerate_id(true);
    $extra = "welcome.php";
    $_SESSION[ 'login' ] = $_POST[ 'uemail' ];
    $_SESSION[ 'id' ] = $num[ 'id' ];
    $_SESSION[ 'name' ] = $num[ 'fname' ];
    $_SESSION[ 'fullname' ] = $_SESSION['name'];
    $_SESSION[ 'slname' ] = '';
	  $_SESSION[ 'snationality' ] = $num[ 'nationality' ];
    $_SESSION[ 'coauth1name' ] = $num[ 'coauth1name' ];
	  $_SESSION[ 'scoauth1nationality' ] = $num[ 'coauth1nationality' ];
    $_SESSION[ 'coauth2name' ] = $num[ 'coauth2name' ];
	  $_SESSION[ 'scoauth2nationality' ] = $num[ 'coauth2nationality' ];
	      $_SESSION[ 'coauth3name' ] = $num[ 'coauth3name' ];
	  $_SESSION[ 'scoauth3nationality' ] = $num[ 'coauth3nationality' ];
          $_SESSION[ 'coauth4name' ] = $num[ 'coauth4name' ];
	  $_SESSION[ 'scoauth4nationality' ] = $num[ 'coauth4nationality' ];
	  $_SESSION[ 'coauth5name' ] = $num[ 'coauth5name' ];
	  $_SESSION[ 'scoauth5nationality' ] = $num[ 'coauth5nationality' ];
          $_SESSION[ 'email' ] = $num[ 'email' ];
          $_SESSION[ 'profession' ] = $num[ 'profession' ];
          $_SESSION[ 'scategory' ] = $num[ 'category' ];
          $_SESSION[ 'contact' ] = $num[ 'contactno' ];
	  $_SESSION[ 'userip' ] = $num[ 'userip' ];
          $_SESSION[ 'companyref' ] = $num[ 'companyref' ];
          $_SESSION[ 'paypalref' ] = $num[ 'paypalref' ];
    $host = $_SERVER[ 'HTTP_HOST' ];
    $uri = rtrim( dirname( $_SERVER[ 'PHP_SELF' ] ), '/\\' );
  $scheme = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https' : 'http';
  ob_end_clean();
  $url = "$scheme://$host$uri/$extra";
  echo '<!DOCTYPE html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>Redirecting</title><style>
html,body{height:100%}body{margin:0}
.overlay{position:fixed;inset:0;background:rgba(0,0,0,.6);display:flex;align-items:center;justify-content:center;z-index:9999}
.panel{background:#fff;color:#222;border-radius:12px;box-shadow:0 10px 30px rgba(0,0,0,.3);width:90%;max-width:420px;padding:24px;text-align:center}
.spinner{width:48px;height:48px;border-radius:50%;border:4px solid #e5e7eb;border-top-color:#2563eb;margin:0 auto 16px;animation:spin 1s linear infinite}
@keyframes spin{to{transform:rotate(360deg)}}
.msg{font-size:18px;margin:8px 0}
.count{font-size:14px;color:#555}
.actions{display:flex;gap:12px;justify-content:center;margin-top:16px;flex-wrap:wrap}
.btn{padding:10px 16px;border:none;border-radius:8px;cursor:pointer}
.secondary{background:#e5e7eb;color:#111}
.primary{background:#2563eb;color:#fff}
</style></head><body>
<div class="overlay" role="dialog" aria-modal="true" aria-label="Redirecting">
  <div class="panel" role="status" aria-live="assertive">
    <div class="spinner" aria-hidden="true"></div>
    <div class="msg">Redirecting...</div>
    <div class="count">Continuing in <span id="count">3</span>s</div>
    <div class="actions">
      <button id="cancel" class="btn secondary" aria-label="Cancel redirect">Cancel</button>
      <button id="now" class="btn primary" aria-label="Redirect now">Go now</button>
    </div>
  </div>
</div>
<script>
var url="'.htmlspecialchars($url,ENT_QUOTES,'UTF-8').'";
var c=3,t=null;
function tick(){c--;document.getElementById("count").textContent=c;if(c<=0){cleanup();location.href=url}}
function cleanup(){if(t){clearInterval(t)}var o=document.querySelector(".overlay");if(o){o.remove()}}
document.getElementById("cancel").addEventListener("click",function(){cleanup()});
document.getElementById("now").addEventListener("click",function(){cleanup();location.href=url});
document.getElementById("count").textContent=c;t=setInterval(tick,1000);setTimeout(function(){cleanup();location.href=url},3000);
</script></body></html>';
    exit();
  } else
  {
    $co = mysqli_prepare($con, "SELECT id,fname,category,postertitle,coauth1name,coauth1email,coauth2name,coauth2email,coauth3name,coauth3email,coauth4name,coauth4email,coauth5name,coauth5email FROM users WHERE coauth1email=? OR coauth2email=? OR coauth3email=? OR coauth4email=? OR coauth5email=? LIMIT 1");
    mysqli_stmt_bind_param($co,'sssss',$useremail,$useremail,$useremail,$useremail,$useremail);
    mysqli_stmt_execute($co);
    $cres = mysqli_stmt_get_result($co);
    $cnum = mysqli_fetch_array($cres);
    if ($cnum && $password === '1234') {
      $extra = "welcome.php";
      $_SESSION['login'] = $useremail;
      $_SESSION['id'] = $cnum['id'];
      $_SESSION['email'] = $useremail;
      $_SESSION['scategory'] = $cnum['category'];
      $_SESSION['postertitle'] = isset($cnum['postertitle']) ? $cnum['postertitle'] : '';
      $suffix = '';
      $cname = '';
      if (isset($cnum['coauth1email']) && $cnum['coauth1email'] === $useremail) { $suffix='CO1'; $cname=$cnum['coauth1name']; }
      elseif (isset($cnum['coauth2email']) && $cnum['coauth2email'] === $useremail) { $suffix='CO2'; $cname=$cnum['coauth2name']; }
      elseif (isset($cnum['coauth3email']) && $cnum['coauth3email'] === $useremail) { $suffix='CO3'; $cname=$cnum['coauth3name']; }
      elseif (isset($cnum['coauth4email']) && $cnum['coauth4email'] === $useremail) { $suffix='CO4'; $cname=$cnum['coauth4name']; }
      elseif (isset($cnum['coauth5email']) && $cnum['coauth5email'] === $useremail) { $suffix='CO5'; $cname=$cnum['coauth5name']; }
      $_SESSION['name'] = $cname ?: 'Co-Author';
      $_SESSION['fullname'] = $_SESSION['name'];
      $_SESSION['role'] = 'coauthor';
      $_SESSION['coauthor_suffix'] = $suffix;
      $host = $_SERVER[ 'HTTP_HOST' ];
      $uri = rtrim( dirname( $_SERVER[ 'PHP_SELF' ] ), '/\\' );
      $scheme = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https' : 'http';
      ob_end_clean();
      $url = "$scheme://$host$uri/$extra";
      echo '<!DOCTYPE html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>Redirecting</title><style>
html,body{height:100%}body{margin:0}
.overlay{position:fixed;inset:0;background:rgba(0,0,0,.6);display:flex;align-items:center;justify-content:center;z-index:9999}
.panel{background:#fff;color:#222;border-radius:12px;box-shadow:0 10px 30px rgba(0,0,0,.3);width:90%;max-width:420px;padding:24px;text-align:center}
.spinner{width:48px;height:48px;border-radius:50%;border:4px solid #e5e7eb;border-top-color:#2563eb;margin:0 auto 16px;animation:spin 1s linear infinite}
@keyframes spin{to{transform:rotate(360deg)}}
.msg{font-size:18px;margin:8px 0}
.count{font-size:14px;color:#555}
.actions{display:flex;gap:12px;justify-content:center;margin-top:16px;flex-wrap:wrap}
.btn{padding:10px 16px;border:none;border-radius:8px;cursor:pointer}
.secondary{background:#e5e7eb;color:#111}
.primary{background:#2563eb;color:#fff}
</style></head><body>
<div class="overlay" role="dialog" aria-modal="true" aria-label="Redirecting">
  <div class="panel" role="status" aria-live="assertive">
    <div class="spinner" aria-hidden="true"></div>
    <div class="msg">Redirecting...</div>
    <div class="count">Continuing in <span id="count">3</span>s</div>
    <div class="actions">
      <button id="cancel" class="btn secondary" aria-label="Cancel redirect">Cancel</button>
      <button id="now" class="btn primary" aria-label="Redirect now">Go now</button>
    </div>
  </div>
</div>
<script>
var url="'.htmlspecialchars($url,ENT_QUOTES,'UTF-8').'";
var c=3,t=null;
function tick(){c--;document.getElementById("count").textContent=c;if(c<=0){cleanup();location.href=url}}
function cleanup(){if(t){clearInterval(t)}var o=document.querySelector(".overlay");if(o){o.remove()}}
document.getElementById("cancel").addEventListener("click",function(){cleanup()});
document.getElementById("now").addEventListener("click",function(){cleanup();location.href=url});
document.getElementById("count").textContent=c;t=setInterval(tick,1000);setTimeout(function(){cleanup();location.href=url},3000);
</script></body></html>';
      exit();
    } else {
      echo "<script>alert('Invalid username or password');</script>";
      $extra = "index.php";
      $host = $_SERVER[ 'HTTP_HOST' ];
      $uri = rtrim( dirname( $_SERVER[ 'PHP_SELF' ] ), '/\\' );
      exit();
    }
  }
}


//Code for Forgot Password


if ( isset( $_POST[ 'send' ] ) )
{
  $femail = $_POST[ 'femail' ];
  $row1 = mysqli_query( $con, "select email,password,id from users where email='$femail'" );
  $row2 = mysqli_fetch_array( $row1 );
  if ( $row2 > 0 )
  {
    $email = $row2[ 'email' ];
    $subject = "ICPM Password Request";
    $password = $row2[ 'password' ];
	$id = $row2[ 'id' ];
    $footerImg = "https://reg-sys.com/icpm2026/images/icpm-logo.png";
    $message = '<div style="font-family:Arial,Helvetica,sans-serif;color:#111;line-height:1.6">
<p><strong>Password retrieval</strong></p>
<p>Your password is ' . htmlspecialchars($password) . '<br>
Your Registration Number is ' . htmlspecialchars($id) . '</p>
<p><strong>Login:</strong> <a href="https://reg-sys.com/icpm2026/poster26/index.php" target="_blank" rel="noopener">https://reg-sys.com/icpm2026/poster26/index.php</a></p>
<hr style="border:none;border-top:1px solid #eee;margin:16px 0">
<div style="text-align:center">
<img src="' . $footerImg . '" alt="ICPM" width="200" height="78" style="display:inline-block">
</div>
</div>';
    $headers = "From: ICPM@reg-sys.com\r\nMIME-Version: 1.0\r\nContent-Type: text/html; charset=utf-8\r\n";
    mail( $email, $subject, $message, $headers );

	   $to = "$email";
    $subject = "ICPM Password Request";
    $footerImg = "https://reg-sys.com/icpm2026/images/icpm-logo.png";
    $message = '<div style="font-family:Arial,Helvetica,sans-serif;color:#111;line-height:1.6">
<p>Please go to the login page to access your account.</p>
<p><strong>Login:</strong> <a href="https://reg-sys.com/icpm2026/poster26/index.php" target="_blank" rel="noopener">https://reg-sys.com/icpm2026/poster26/index.php</a></p>
<p><strong>Credentials</strong><br>
Email: ' . htmlspecialchars($email) . '<br>
Password: ' . htmlspecialchars($password) . '<br>
Registration Number: ' . htmlspecialchars($id) . '</p>
<hr style="border:none;border-top:1px solid #eee;margin:16px 0">
<div style="text-align:center">
<img src="' . $footerImg . '" alt="ICPM" width="200" height="78" style="display:inline-block">
</div>
</div>';
    $headers = "From: ICPM@reg-sys.com\r\nMIME-Version: 1.0\r\nContent-Type: text/html; charset=utf-8\r\n";
	mail( $email, $subject, $message, $headers );
    echo "<script>alert('Your Password has been sent Successfully');</script>";
  } else
  {
    echo "<script>alert('Email not register with us');</script>";
  }
}

?>
<!DOCTYPE html>

<html>
<head>
<title>Login System</title>
<link href="css/style.css" rel='stylesheet' type='text/css' />
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Elegent Tab Forms,Login Forms,Sign up Forms,Registration Forms,News latter Forms,Elements"./>
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
</script>
<script src="js/jquery.min.js"></script>
<script src="js/easyResponsiveTabs.js" type="text/javascript"></script>
<script type="text/javascript">

					$(document).ready(function () {

						$('#horizontalTab').easyResponsiveTabs({

							type: 'default',

							width: 'auto',

							fit: true

						});

					});

				   </script>
<link href='http://fonts.googleapis.com/css?family=Source+Sans+Pro:200,400,600,700,200italic,300italic,400italic,600italic|Lora:400,700,400italic,700italic|Raleway:400,500,300,600,700,200,100' rel='stylesheet' type='text/css'>
<style>
.coauthor-group{display:none;margin-top:10px;border-top:1px solid #eee;padding-top:10px}
.coauthors-label{font-weight:700;font-size:20px;animation:coflash 1.2s ease-in-out infinite}
.register p{font-weight:600}
@keyframes coflash{0%{opacity:1}50%{opacity:.55}100%{opacity:1}}
.drop-zone{display:block;cursor:pointer;margin:12px 0;color:#111;background:transparent;border:2px solid #ff0000;padding:16px;min-height:72px;border-radius:8px;position:relative;z-index:1;transition:border-color 300ms ease-in-out, box-shadow 300ms ease-in-out}
.drop-zone.error{border-color:#c62828;background:#fff5f5;color:#111}
.drop-zone.error::after{content:" ! ";display:inline-block;margin-left:8px;color:#c62828;font-weight:700}
.drop-zone:focus{outline:2px solid #1e88e5; outline-offset:2px}
.drop-zone.dragover{background:#fff5f5;border-color:#cc0000;color:#111;box-shadow:0 0 0 2px rgba(255,0,0,0.35)}
.upload-status{margin-top:6px;font-size:13px;color:#c62828}
.drop-zone.valid{border-color:#00ff00;box-shadow:0 0 0 2px rgba(0,255,0,0.25)}
.toast-notice{position:fixed;right:12px;top:12px;background:#222;color:#fff;padding:10px 14px;border-radius:6px;box-shadow:0 2px 8px rgba(0,0,0,0.25);z-index:9999}
.modal-notice{position:fixed;left:0;top:0;width:100%;height:100%;background:rgba(0,0,0,0.5);display:none;align-items:center;justify-content:center;z-index:9998}
.modal-notice .content{background:#fff;color:#111;padding:18px 22px;border-radius:8px;max-width:90%;box-shadow:0 2px 10px rgba(0,0,0,0.3)}
</style>
<script type="text/javascript">

    function ShowHideDiv() {

        var chkYes = document.getElementById("chkYes");

        var dvPaymentType = document.getElementById("dvPaymentType");

        dvPaymentType.style.display = chkYes.checked ? "block" : "none";



        var chkNo = document.getElementById("chkNo");

        var dvPaymentPaypal = document.getElementById("dvPaymentPaypal");

        dvPaymentPaypal.style.display = chkNo.checked ? "block" : "none";

    }

</script>
</head>

<body>
<div class="main">
  <h1>ICPM 2026 Registration and Login System<br>
    Poster Competition Only</h1>
  <div class="sap_tabs">
    <div id="horizontalTab" style="display: block; width: 100%; margin: 0px;">
      <ul class="resp-tabs-list">
        <li class="resp-tab-item" aria-controls="tab_item-0" role="tab">
          <div class="top-img"><img src="images/top-note.png" alt=""/></div>
          <span>Register</span> </li>
        <li class="resp-tab-item" aria-controls="tab_item-1" role="tab">
          <div class="top-img"><img src="images/top-lock.png" alt=""/></div>
          <span>Login</span></li>
        <li class="resp-tab-item lost" aria-controls="tab_item-2" role="tab">
          <div class="top-img"><img src="images/top-key.png" alt=""/></div>
          <span>Forgot Password</span></li>
        <div class="clear"></div>
      </ul>
      <div class="resp-tabs-container">
        <div class="tab-1 resp-tab-content" aria-labelledby="tab_item-0">
          <div class="facts">
            <div class="register">
              <form name="registration" method="post" action="" enctype="multipart/form-data">
                <p>Please Make sure you Enter correct Full Names , Email , Category and Mobile Number <br>
                  <span style="color: black">** Abstract should be sent to abstract@icpm.ae with reference number from main auther Email</span></p>
				  <hr>
                <p>Main Auther Full Name </p>
                <input type="text" class="text" value=""  name="fname" required >
				        <p>Main Auther Nationality </p>
                <select name="nationality" class="text" name="nationality" required>
                <option value=""></option>
                <option value="Afghanistan">Afghanistan</option>
                <option value="Aland Islands">Aland Islands</option>
                <option value="Albania">Albania</option>
                <option value="Algeria">Algeria</option>
                <option value="American Samoa">American Samoa</option>
                <option value="Andorra">Andorra</option>
                <option value="Angola">Angola</option>
                <option value="Anguilla">Anguilla</option>
                <option value="Antarctica">Antarctica</option>
                <option value="Antigua and Barbuda">Antigua and Barbuda</option>
                <option value="Argentina">Argentina</option>
                <option value="Armenia">Armenia</option>
                <option value="Aruba">Aruba</option>
                <option value="Australia">Australia</option>
                <option value="Austria">Austria</option>
                <option value="Azerbaijan">Azerbaijan</option>
                <option value="Bahamas">Bahamas</option>
                <option value="Bahrain">Bahrain</option>
                <option value="Bangladesh">Bangladesh</option>
                <option value="Barbados">Barbados</option>
                <option value="Belarus">Belarus</option>
                <option value="Belgium">Belgium</option>
                <option value="Belize">Belize</option>
                <option value="Benin">Benin</option>
                <option value="Bermuda">Bermuda</option>
                <option value="Bhutan">Bhutan</option>
                <option value="Bolivia">Bolivia</option>
                <option value="Bonaire, Sint Eustatius and Saba">Bonaire, Sint Eustatius and Saba</option>
                <option value="Bosnia and Herzegovina">Bosnia and Herzegovina</option>
                <option value="Botswana">Botswana</option>
                <option value="Bouvet Island">Bouvet Island</option>
                <option value="Brazil">Brazil</option>
                <option value="British Indian Ocean Territory">British Indian Ocean Territory</option>
                <option value="Brunei Darussalam">Brunei Darussalam</option>
                <option value="Bulgaria">Bulgaria</option>
                <option value="Burkina Faso">Burkina Faso</option>
                <option value="Burundi">Burundi</option>
                <option value="Cambodia">Cambodia</option>
                <option value="Cameroon">Cameroon</option>
                <option value="Canada">Canada</option>
                <option value="Cape Verde">Cape Verde</option>
                <option value="Cayman Islands">Cayman Islands</option>
                <option value="Central African Republic">Central African Republic</option>
                <option value="Chad">Chad</option>
                <option value="Chile">Chile</option>
                <option value="China">China</option>
                <option value="Christmas Island">Christmas Island</option>
                <option value="Cocos (Keeling) Islands">Cocos (Keeling) Islands</option>
                <option value="Colombia">Colombia</option>
                <option value="Comoros">Comoros</option>
                <option value="Congo">Congo</option>
                <option value="Congo, Democratic Republic of the Congo">Congo, Democratic Republic of the Congo</option>
                <option value="Cook Islands">Cook Islands</option>
                <option value="Costa Rica">Costa Rica</option>
                <option value="Cote D'Ivoire">Cote D'Ivoire</option>
                <option value="Croatia">Croatia</option>
                <option value="Cuba">Cuba</option>
                <option value="Curacao">Curacao</option>
                <option value="Cyprus">Cyprus</option>
                <option value="Czech Republic">Czech Republic</option>
                <option value="Denmark">Denmark</option>
                <option value="Djibouti">Djibouti</option>
                <option value="Dominica">Dominica</option>
                <option value="Dominican Republic">Dominican Republic</option>
                <option value="Ecuador">Ecuador</option>
                <option value="Egypt">Egypt</option>
                <option value="El Salvador">El Salvador</option>
                <option value="Equatorial Guinea">Equatorial Guinea</option>
                <option value="Eritrea">Eritrea</option>
                <option value="Estonia">Estonia</option>
                <option value="Ethiopia">Ethiopia</option>
                <option value="Falkland Islands (Malvinas)">Falkland Islands (Malvinas)</option>
                <option value="Faroe Islands">Faroe Islands</option>
                <option value="Fiji">Fiji</option>
                <option value="Finland">Finland</option>
                <option value="France">France</option>
                <option value="French Guiana">French Guiana</option>
                <option value="French Polynesia">French Polynesia</option>
                <option value="French Southern Territories">French Southern Territories</option>
                <option value="Gabon">Gabon</option>
                <option value="Gambia">Gambia</option>
                <option value="Georgia">Georgia</option>
                <option value="Germany">Germany</option>
                <option value="Ghana">Ghana</option>
                <option value="Gibraltar">Gibraltar</option>
                <option value="Greece">Greece</option>
                <option value="Greenland">Greenland</option>
                <option value="Grenada">Grenada</option>
                <option value="Guadeloupe">Guadeloupe</option>
                <option value="Guam">Guam</option>
                <option value="Guatemala">Guatemala</option>
                <option value="Guernsey">Guernsey</option>
                <option value="Guinea">Guinea</option>
                <option value="Guinea-Bissau">Guinea-Bissau</option>
                <option value="Guyana">Guyana</option>
                <option value="Haiti">Haiti</option>
                <option value="Heard Island and Mcdonald Islands">Heard Island and Mcdonald Islands</option>
                <option value="Holy See (Vatican City State)">Holy See (Vatican City State)</option>
                <option value="Honduras">Honduras</option>
                <option value="Hong Kong">Hong Kong</option>
                <option value="Hungary">Hungary</option>
                <option value="Iceland">Iceland</option>
                <option value="India">India</option>
                <option value="Indonesia">Indonesia</option>
                <option value="Iran, Islamic Republic of">Iran, Islamic Republic of</option>
                <option value="Iraq">Iraq</option>
                <option value="Ireland">Ireland</option>
                <option value="Isle of Man">Isle of Man</option>
                <option value="Israel">Israel</option>
                <option value="Italy">Italy</option>
                <option value="Jamaica">Jamaica</option>
                <option value="Japan">Japan</option>
                <option value="Jersey">Jersey</option>
                <option value="Jordan">Jordan</option>
                <option value="Kazakhstan">Kazakhstan</option>
                <option value="Kenya">Kenya</option>
                <option value="Kiribati">Kiribati</option>
                <option value="Korea, Democratic People's Republic of">Korea, Democratic People's Republic of</option>
                <option value="Korea, Republic of">Korea, Republic of</option>
                <option value="Kosovo">Kosovo</option>
                <option value="Kuwait">Kuwait</option>
                <option value="Kyrgyzstan">Kyrgyzstan</option>
                <option value="Lao People's Democratic Republic">Lao People's Democratic Republic</option>
                <option value="Latvia">Latvia</option>
                <option value="Lebanon">Lebanon</option>
                <option value="Lesotho">Lesotho</option>
                <option value="Liberia">Liberia</option>
                <option value="Libyan Arab Jamahiriya">Libyan Arab Jamahiriya</option>
                <option value="Liechtenstein">Liechtenstein</option>
                <option value="Lithuania">Lithuania</option>
                <option value="Luxembourg">Luxembourg</option>
                <option value="Macao">Macao</option>
                <option value="Macedonia, the Former Yugoslav Republic of">Macedonia, the Former Yugoslav Republic of</option>
                <option value="Madagascar">Madagascar</option>
                <option value="Malawi">Malawi</option>
                <option value="Malaysia">Malaysia</option>
                <option value="Maldives">Maldives</option>
                <option value="Mali">Mali</option>
                <option value="Malta">Malta</option>
                <option value="Marshall Islands">Marshall Islands</option>
                <option value="Martinique">Martinique</option>
                <option value="Mauritania">Mauritania</option>
                <option value="Mauritius">Mauritius</option>
                <option value="Mayotte">Mayotte</option>
                <option value="Mexico">Mexico</option>
                <option value="Micronesia, Federated States of">Micronesia, Federated States of</option>
                <option value="Moldova, Republic of">Moldova, Republic of</option>
                <option value="Monaco">Monaco</option>
                <option value="Mongolia">Mongolia</option>
                <option value="Montenegro">Montenegro</option>
                <option value="Montserrat">Montserrat</option>
                <option value="Morocco">Morocco</option>
                <option value="Mozambique">Mozambique</option>
                <option value="Myanmar">Myanmar</option>
                <option value="Namibia">Namibia</option>
                <option value="Nauru">Nauru</option>
                <option value="Nepal">Nepal</option>
                <option value="Netherlands">Netherlands</option>
                <option value="Netherlands Antilles">Netherlands Antilles</option>
                <option value="New Caledonia">New Caledonia</option>
                <option value="New Zealand">New Zealand</option>
                <option value="Nicaragua">Nicaragua</option>
                <option value="Niger">Niger</option>
                <option value="Nigeria">Nigeria</option>
                <option value="Niue">Niue</option>
                <option value="Norfolk Island">Norfolk Island</option>
                <option value="Northern Mariana Islands">Northern Mariana Islands</option>
                <option value="Norway">Norway</option>
                <option value="Oman">Oman</option>
                <option value="Pakistan">Pakistan</option>
                <option value="Palau">Palau</option>
                <option value="Palestinian Territory, Occupied">Palestinian Territory, Occupied</option>
                <option value="Panama">Panama</option>
                <option value="Papua New Guinea">Papua New Guinea</option>
                <option value="Paraguay">Paraguay</option>
                <option value="Peru">Peru</option>
                <option value="Philippines">Philippines</option>
                <option value="Pitcairn">Pitcairn</option>
                <option value="Poland">Poland</option>
                <option value="Portugal">Portugal</option>
                <option value="Puerto Rico">Puerto Rico</option>
                <option value="Qatar">Qatar</option>
                <option value="Reunion">Reunion</option>
                <option value="Romania">Romania</option>
                <option value="Russian Federation">Russian Federation</option>
                <option value="Rwanda">Rwanda</option>
                <option value="Saint Barthelemy">Saint Barthelemy</option>
                <option value="Saint Helena">Saint Helena</option>
                <option value="Saint Kitts and Nevis">Saint Kitts and Nevis</option>
                <option value="Saint Lucia">Saint Lucia</option>
                <option value="Saint Martin">Saint Martin</option>
                <option value="Saint Pierre and Miquelon">Saint Pierre and Miquelon</option>
                <option value="Saint Vincent and the Grenadines">Saint Vincent and the Grenadines</option>
                <option value="Samoa">Samoa</option>
                <option value="San Marino">San Marino</option>
                <option value="Sao Tome and Principe">Sao Tome and Principe</option>
                <option value="Saudi Arabia">Saudi Arabia</option>
                <option value="Senegal">Senegal</option>
                <option value="Serbia">Serbia</option>
                <option value="Serbia and Montenegro">Serbia and Montenegro</option>
                <option value="Seychelles">Seychelles</option>
                <option value="Sierra Leone">Sierra Leone</option>
                <option value="Singapore">Singapore</option>
                <option value="Sint Maarten">Sint Maarten</option>
                <option value="Slovakia">Slovakia</option>
                <option value="Slovenia">Slovenia</option>
                <option value="Solomon Islands">Solomon Islands</option>
                <option value="Somalia">Somalia</option>
                <option value="South Africa">South Africa</option>
                <option value="South Georgia and the South Sandwich Islands">South Georgia and the South Sandwich Islands</option>
                <option value="South Sudan">South Sudan</option>
                <option value="Spain">Spain</option>
                <option value="Sri Lanka">Sri Lanka</option>
                <option value="Sudan">Sudan</option>
                <option value="Suriname">Suriname</option>
                <option value="Svalbard and Jan Mayen">Svalbard and Jan Mayen</option>
                <option value="Swaziland">Swaziland</option>
                <option value="Sweden">Sweden</option>
                <option value="Switzerland">Switzerland</option>
                <option value="Syrian Arab Republic">Syrian Arab Republic</option>
                <option value="Taiwan, Province of China">Taiwan, Province of China</option>
                <option value="Tajikistan">Tajikistan</option>
                <option value="Tanzania, United Republic of">Tanzania, United Republic of</option>
                <option value="Thailand">Thailand</option>
                <option value="Timor-Leste">Timor-Leste</option>
                <option value="Togo">Togo</option>
                <option value="Tokelau">Tokelau</option>
                <option value="Tonga">Tonga</option>
                <option value="Trinidad and Tobago">Trinidad and Tobago</option>
                <option value="Tunisia">Tunisia</option>
                <option value="Turkey">Turkey</option>
                <option value="Turkmenistan">Turkmenistan</option>
                <option value="Turks and Caicos Islands">Turks and Caicos Islands</option>
                <option value="Tuvalu">Tuvalu</option>
                <option value="Uganda">Uganda</option>
                <option value="Ukraine">Ukraine</option>
                <option value="United Arab Emirates">United Arab Emirates</option>
                <option value="United Kingdom">United Kingdom</option>
                <option value="United States">United States</option>
                <option value="United States Minor Outlying Islands">United States Minor Outlying Islands</option>
                <option value="Uruguay">Uruguay</option>
                <option value="Uzbekistan">Uzbekistan</option>
                <option value="Vanuatu">Vanuatu</option>
                <option value="Venezuela">Venezuela</option>
                <option value="Viet Nam">Viet Nam</option>
                <option value="Virgin Islands, British">Virgin Islands, British</option>
                <option value="Virgin Islands, U.s.">Virgin Islands, U.s.</option>
                <option value="Wallis and Futuna">Wallis and Futuna</option>
                <option value="Western Sahara">Western Sahara</option>
                <option value="Yemen">Yemen</option>
                <option value="Zambia">Zambia</option>
                <option value="Zimbabwe">Zimbabwe</option>
                </select>
                        <p>Main Auther Email Address (Can't register twice with same email) <br>
                  <span style="color: black">* Will be used as user name to login</span></p>
                <input type="text" class="text" value="" name="email"  >
				  	  <hr>
                <p class="coauthors-label">Number of Co Others - required</p>
                <select class="text" name="coauthors_count" required aria-label="Number of Co Others">
                  <option value="" disabled selected>Select number of Co-Authers</option>
                  <option value="0">No Co-Authers</option>
                  <option value="1">1 Co-Auther</option>
                  <option value="2">2 Co-Authers</option>
                  <option value="3">3 Co-Authers</option>
                  <option value="4">4 Co-Authers</option>
                  <option value="5">5 Co-Authers</option>
                </select>
				                  <div class="coauthor-group" id="coauthor-1">
				                  <p>CO-Auther-1 Full Name </p>
                 <input type="text" class="text" value="" name="coauth1name" >
 					        <p>Co-Auther 1 Nationality </p>
                 <select name="coauth1nationality" class="text" name="coauth1nationality">
                 <option value=""></option>
                <option value="Afghanistan">Afghanistan</option>
                <option value="Aland Islands">Aland Islands</option>
                <option value="Albania">Albania</option>
                <option value="Algeria">Algeria</option>
                <option value="American Samoa">American Samoa</option>
                <option value="Andorra">Andorra</option>
                <option value="Angola">Angola</option>
                <option value="Anguilla">Anguilla</option>
                <option value="Antarctica">Antarctica</option>
                <option value="Antigua and Barbuda">Antigua and Barbuda</option>
                <option value="Argentina">Argentina</option>
                <option value="Armenia">Armenia</option>
                <option value="Aruba">Aruba</option>
                <option value="Australia">Australia</option>
                <option value="Austria">Austria</option>
                <option value="Azerbaijan">Azerbaijan</option>
                <option value="Bahamas">Bahamas</option>
                <option value="Bahrain">Bahrain</option>
                <option value="Bangladesh">Bangladesh</option>
                <option value="Barbados">Barbados</option>
                <option value="Belarus">Belarus</option>
                <option value="Belgium">Belgium</option>
                <option value="Belize">Belize</option>
                <option value="Benin">Benin</option>
                <option value="Bermuda">Bermuda</option>
                <option value="Bhutan">Bhutan</option>
                <option value="Bolivia">Bolivia</option>
                <option value="Bonaire, Sint Eustatius and Saba">Bonaire, Sint Eustatius and Saba</option>
                <option value="Bosnia and Herzegovina">Bosnia and Herzegovina</option>
                <option value="Botswana">Botswana</option>
                <option value="Bouvet Island">Bouvet Island</option>
                <option value="Brazil">Brazil</option>
                <option value="British Indian Ocean Territory">British Indian Ocean Territory</option>
                <option value="Brunei Darussalam">Brunei Darussalam</option>
                <option value="Bulgaria">Bulgaria</option>
                <option value="Burkina Faso">Burkina Faso</option>
                <option value="Burundi">Burundi</option>
                <option value="Cambodia">Cambodia</option>
                <option value="Cameroon">Cameroon</option>
                <option value="Canada">Canada</option>
                <option value="Cape Verde">Cape Verde</option>
                <option value="Cayman Islands">Cayman Islands</option>
                <option value="Central African Republic">Central African Republic</option>
                <option value="Chad">Chad</option>
                <option value="Chile">Chile</option>
                <option value="China">China</option>
                <option value="Christmas Island">Christmas Island</option>
                <option value="Cocos (Keeling) Islands">Cocos (Keeling) Islands</option>
                <option value="Colombia">Colombia</option>
                <option value="Comoros">Comoros</option>
                <option value="Congo">Congo</option>
                <option value="Congo, Democratic Republic of the Congo">Congo, Democratic Republic of the Congo</option>
                <option value="Cook Islands">Cook Islands</option>
                <option value="Costa Rica">Costa Rica</option>
                <option value="Cote D'Ivoire">Cote D'Ivoire</option>
                <option value="Croatia">Croatia</option>
                <option value="Cuba">Cuba</option>
                <option value="Curacao">Curacao</option>
                <option value="Cyprus">Cyprus</option>
                <option value="Czech Republic">Czech Republic</option>
                <option value="Denmark">Denmark</option>
                <option value="Djibouti">Djibouti</option>
                <option value="Dominica">Dominica</option>
                <option value="Dominican Republic">Dominican Republic</option>
                <option value="Ecuador">Ecuador</option>
                <option value="Egypt">Egypt</option>
                <option value="El Salvador">El Salvador</option>
                <option value="Equatorial Guinea">Equatorial Guinea</option>
                <option value="Eritrea">Eritrea</option>
                <option value="Estonia">Estonia</option>
                <option value="Ethiopia">Ethiopia</option>
                <option value="Falkland Islands (Malvinas)">Falkland Islands (Malvinas)</option>
                <option value="Faroe Islands">Faroe Islands</option>
                <option value="Fiji">Fiji</option>
                <option value="Finland">Finland</option>
                <option value="France">France</option>
                <option value="French Guiana">French Guiana</option>
                <option value="French Polynesia">French Polynesia</option>
                <option value="French Southern Territories">French Southern Territories</option>
                <option value="Gabon">Gabon</option>
                <option value="Gambia">Gambia</option>
                <option value="Georgia">Georgia</option>
                <option value="Germany">Germany</option>
                <option value="Ghana">Ghana</option>
                <option value="Gibraltar">Gibraltar</option>
                <option value="Greece">Greece</option>
                <option value="Greenland">Greenland</option>
                <option value="Grenada">Grenada</option>
                <option value="Guadeloupe">Guadeloupe</option>
                <option value="Guam">Guam</option>
                <option value="Guatemala">Guatemala</option>
                <option value="Guernsey">Guernsey</option>
                <option value="Guinea">Guinea</option>
                <option value="Guinea-Bissau">Guinea-Bissau</option>
                <option value="Guyana">Guyana</option>
                <option value="Haiti">Haiti</option>
                <option value="Heard Island and Mcdonald Islands">Heard Island and Mcdonald Islands</option>
                <option value="Holy See (Vatican City State)">Holy See (Vatican City State)</option>
                <option value="Honduras">Honduras</option>
                <option value="Hong Kong">Hong Kong</option>
                <option value="Hungary">Hungary</option>
                <option value="Iceland">Iceland</option>
                <option value="India">India</option>
                <option value="Indonesia">Indonesia</option>
                <option value="Iran, Islamic Republic of">Iran, Islamic Republic of</option>
                <option value="Iraq">Iraq</option>
                <option value="Ireland">Ireland</option>
                <option value="Isle of Man">Isle of Man</option>
                <option value="Israel">Israel</option>
                <option value="Italy">Italy</option>
                <option value="Jamaica">Jamaica</option>
                <option value="Japan">Japan</option>
                <option value="Jersey">Jersey</option>
                <option value="Jordan">Jordan</option>
                <option value="Kazakhstan">Kazakhstan</option>
                <option value="Kenya">Kenya</option>
                <option value="Kiribati">Kiribati</option>
                <option value="Korea, Democratic People's Republic of">Korea, Democratic People's Republic of</option>
                <option value="Korea, Republic of">Korea, Republic of</option>
                <option value="Kosovo">Kosovo</option>
                <option value="Kuwait">Kuwait</option>
                <option value="Kyrgyzstan">Kyrgyzstan</option>
                <option value="Lao People's Democratic Republic">Lao People's Democratic Republic</option>
                <option value="Latvia">Latvia</option>
                <option value="Lebanon">Lebanon</option>
                <option value="Lesotho">Lesotho</option>
                <option value="Liberia">Liberia</option>
                <option value="Libyan Arab Jamahiriya">Libyan Arab Jamahiriya</option>
                <option value="Liechtenstein">Liechtenstein</option>
                <option value="Lithuania">Lithuania</option>
                <option value="Luxembourg">Luxembourg</option>
                <option value="Macao">Macao</option>
                <option value="Macedonia, the Former Yugoslav Republic of">Macedonia, the Former Yugoslav Republic of</option>
                <option value="Madagascar">Madagascar</option>
                <option value="Malawi">Malawi</option>
                <option value="Malaysia">Malaysia</option>
                <option value="Maldives">Maldives</option>
                <option value="Mali">Mali</option>
                <option value="Malta">Malta</option>
                <option value="Marshall Islands">Marshall Islands</option>
                <option value="Martinique">Martinique</option>
                <option value="Mauritania">Mauritania</option>
                <option value="Mauritius">Mauritius</option>
                <option value="Mayotte">Mayotte</option>
                <option value="Mexico">Mexico</option>
                <option value="Micronesia, Federated States of">Micronesia, Federated States of</option>
                <option value="Moldova, Republic of">Moldova, Republic of</option>
                <option value="Monaco">Monaco</option>
                <option value="Mongolia">Mongolia</option>
                <option value="Montenegro">Montenegro</option>
                <option value="Montserrat">Montserrat</option>
                <option value="Morocco">Morocco</option>
                <option value="Mozambique">Mozambique</option>
                <option value="Myanmar">Myanmar</option>
                <option value="Namibia">Namibia</option>
                <option value="Nauru">Nauru</option>
                <option value="Nepal">Nepal</option>
                <option value="Netherlands">Netherlands</option>
                <option value="Netherlands Antilles">Netherlands Antilles</option>
                <option value="New Caledonia">New Caledonia</option>
                <option value="New Zealand">New Zealand</option>
                <option value="Nicaragua">Nicaragua</option>
                <option value="Niger">Niger</option>
                <option value="Nigeria">Nigeria</option>
                <option value="Niue">Niue</option>
                <option value="Norfolk Island">Norfolk Island</option>
                <option value="Northern Mariana Islands">Northern Mariana Islands</option>
                <option value="Norway">Norway</option>
                <option value="Oman">Oman</option>
                <option value="Pakistan">Pakistan</option>
                <option value="Palau">Palau</option>
                <option value="Palestinian Territory, Occupied">Palestinian Territory, Occupied</option>
                <option value="Panama">Panama</option>
                <option value="Papua New Guinea">Papua New Guinea</option>
                <option value="Paraguay">Paraguay</option>
                <option value="Peru">Peru</option>
                <option value="Philippines">Philippines</option>
                <option value="Pitcairn">Pitcairn</option>
                <option value="Poland">Poland</option>
                <option value="Portugal">Portugal</option>
                <option value="Puerto Rico">Puerto Rico</option>
                <option value="Qatar">Qatar</option>
                <option value="Reunion">Reunion</option>
                <option value="Romania">Romania</option>
                <option value="Russian Federation">Russian Federation</option>
                <option value="Rwanda">Rwanda</option>
                <option value="Saint Barthelemy">Saint Barthelemy</option>
                <option value="Saint Helena">Saint Helena</option>
                <option value="Saint Kitts and Nevis">Saint Kitts and Nevis</option>
                <option value="Saint Lucia">Saint Lucia</option>
                <option value="Saint Martin">Saint Martin</option>
                <option value="Saint Pierre and Miquelon">Saint Pierre and Miquelon</option>
                <option value="Saint Vincent and the Grenadines">Saint Vincent and the Grenadines</option>
                <option value="Samoa">Samoa</option>
                <option value="San Marino">San Marino</option>
                <option value="Sao Tome and Principe">Sao Tome and Principe</option>
                <option value="Saudi Arabia">Saudi Arabia</option>
                <option value="Senegal">Senegal</option>
                <option value="Serbia">Serbia</option>
                <option value="Serbia and Montenegro">Serbia and Montenegro</option>
                <option value="Seychelles">Seychelles</option>
                <option value="Sierra Leone">Sierra Leone</option>
                <option value="Singapore">Singapore</option>
                <option value="Sint Maarten">Sint Maarten</option>
                <option value="Slovakia">Slovakia</option>
                <option value="Slovenia">Slovenia</option>
                <option value="Solomon Islands">Solomon Islands</option>
                <option value="Somalia">Somalia</option>
                <option value="South Africa">South Africa</option>
                <option value="South Georgia and the South Sandwich Islands">South Georgia and the South Sandwich Islands</option>
                <option value="South Sudan">South Sudan</option>
                <option value="Spain">Spain</option>
                <option value="Sri Lanka">Sri Lanka</option>
                <option value="Sudan">Sudan</option>
                <option value="Suriname">Suriname</option>
                <option value="Svalbard and Jan Mayen">Svalbard and Jan Mayen</option>
                <option value="Swaziland">Swaziland</option>
                <option value="Sweden">Sweden</option>
                <option value="Switzerland">Switzerland</option>
                <option value="Syrian Arab Republic">Syrian Arab Republic</option>
                <option value="Taiwan, Province of China">Taiwan, Province of China</option>
                <option value="Tajikistan">Tajikistan</option>
                <option value="Tanzania, United Republic of">Tanzania, United Republic of</option>
                <option value="Thailand">Thailand</option>
                <option value="Timor-Leste">Timor-Leste</option>
                <option value="Togo">Togo</option>
                <option value="Tokelau">Tokelau</option>
                <option value="Tonga">Tonga</option>
                <option value="Trinidad and Tobago">Trinidad and Tobago</option>
                <option value="Tunisia">Tunisia</option>
                <option value="Turkey">Turkey</option>
                <option value="Turkmenistan">Turkmenistan</option>
                <option value="Turks and Caicos Islands">Turks and Caicos Islands</option>
                <option value="Tuvalu">Tuvalu</option>
                <option value="Uganda">Uganda</option>
                <option value="Ukraine">Ukraine</option>
                <option value="United Arab Emirates">United Arab Emirates</option>
                <option value="United Kingdom">United Kingdom</option>
                <option value="United States">United States</option>
                <option value="United States Minor Outlying Islands">United States Minor Outlying Islands</option>
                <option value="Uruguay">Uruguay</option>
                <option value="Uzbekistan">Uzbekistan</option>
                <option value="Vanuatu">Vanuatu</option>
                <option value="Venezuela">Venezuela</option>
                <option value="Viet Nam">Viet Nam</option>
                <option value="Virgin Islands, British">Virgin Islands, British</option>
                <option value="Virgin Islands, U.s.">Virgin Islands, U.s.</option>
                <option value="Wallis and Futuna">Wallis and Futuna</option>
                <option value="Western Sahara">Western Sahara</option>
                <option value="Yemen">Yemen</option>
                <option value="Zambia">Zambia</option>
                <option value="Zimbabwe">Zimbabwe</option>
                </select>
                <p>Co-Author 1 Email</p>
                <input type="email" class="text" value="" name="coauth1email" aria-label="Co-Author 1 Email">
                </div>
                
				         <div class="coauthor-group" id="coauthor-2">
				         <p>CO-Auther-2 Full Name </p>
                 <input type="text" class="text" value="" name="coauth2name" >
  				  				   <p>Co-Auther 2 Nationality </p>
                 <select name="coauth2nationality" class="text" name="coauth2nationality">
                 <option value=""></option>
                <option value="Afghanistan">Afghanistan</option>
                <option value="Aland Islands">Aland Islands</option>
                <option value="Albania">Albania</option>
                <option value="Algeria">Algeria</option>
                <option value="American Samoa">American Samoa</option>
                <option value="Andorra">Andorra</option>
                <option value="Angola">Angola</option>
                <option value="Anguilla">Anguilla</option>
                <option value="Antarctica">Antarctica</option>
                <option value="Antigua and Barbuda">Antigua and Barbuda</option>
                <option value="Argentina">Argentina</option>
                <option value="Armenia">Armenia</option>
                <option value="Aruba">Aruba</option>
                <option value="Australia">Australia</option>
                <option value="Austria">Austria</option>
                <option value="Azerbaijan">Azerbaijan</option>
                <option value="Bahamas">Bahamas</option>
                <option value="Bahrain">Bahrain</option>
                <option value="Bangladesh">Bangladesh</option>
                <option value="Barbados">Barbados</option>
                <option value="Belarus">Belarus</option>
                <option value="Belgium">Belgium</option>
                <option value="Belize">Belize</option>
                <option value="Benin">Benin</option>
                <option value="Bermuda">Bermuda</option>
                <option value="Bhutan">Bhutan</option>
                <option value="Bolivia">Bolivia</option>
                <option value="Bonaire, Sint Eustatius and Saba">Bonaire, Sint Eustatius and Saba</option>
                <option value="Bosnia and Herzegovina">Bosnia and Herzegovina</option>
                <option value="Botswana">Botswana</option>
                <option value="Bouvet Island">Bouvet Island</option>
                <option value="Brazil">Brazil</option>
                <option value="British Indian Ocean Territory">British Indian Ocean Territory</option>
                <option value="Brunei Darussalam">Brunei Darussalam</option>
                <option value="Bulgaria">Bulgaria</option>
                <option value="Burkina Faso">Burkina Faso</option>
                <option value="Burundi">Burundi</option>
                <option value="Cambodia">Cambodia</option>
                <option value="Cameroon">Cameroon</option>
                <option value="Canada">Canada</option>
                <option value="Cape Verde">Cape Verde</option>
                <option value="Cayman Islands">Cayman Islands</option>
                <option value="Central African Republic">Central African Republic</option>
                <option value="Chad">Chad</option>
                <option value="Chile">Chile</option>
                <option value="China">China</option>
                <option value="Christmas Island">Christmas Island</option>
                <option value="Cocos (Keeling) Islands">Cocos (Keeling) Islands</option>
                <option value="Colombia">Colombia</option>
                <option value="Comoros">Comoros</option>
                <option value="Congo">Congo</option>
                <option value="Congo, Democratic Republic of the Congo">Congo, Democratic Republic of the Congo</option>
                <option value="Cook Islands">Cook Islands</option>
                <option value="Costa Rica">Costa Rica</option>
                <option value="Cote D'Ivoire">Cote D'Ivoire</option>
                <option value="Croatia">Croatia</option>
                <option value="Cuba">Cuba</option>
                <option value="Curacao">Curacao</option>
                <option value="Cyprus">Cyprus</option>
                <option value="Czech Republic">Czech Republic</option>
                <option value="Denmark">Denmark</option>
                <option value="Djibouti">Djibouti</option>
                <option value="Dominica">Dominica</option>
                <option value="Dominican Republic">Dominican Republic</option>
                <option value="Ecuador">Ecuador</option>
                <option value="Egypt">Egypt</option>
                <option value="El Salvador">El Salvador</option>
                <option value="Equatorial Guinea">Equatorial Guinea</option>
                <option value="Eritrea">Eritrea</option>
                <option value="Estonia">Estonia</option>
                <option value="Ethiopia">Ethiopia</option>
                <option value="Falkland Islands (Malvinas)">Falkland Islands (Malvinas)</option>
                <option value="Faroe Islands">Faroe Islands</option>
                <option value="Fiji">Fiji</option>
                <option value="Finland">Finland</option>
                <option value="France">France</option>
                <option value="French Guiana">French Guiana</option>
                <option value="French Polynesia">French Polynesia</option>
                <option value="French Southern Territories">French Southern Territories</option>
                <option value="Gabon">Gabon</option>
                <option value="Gambia">Gambia</option>
                <option value="Georgia">Georgia</option>
                <option value="Germany">Germany</option>
                <option value="Ghana">Ghana</option>
                <option value="Gibraltar">Gibraltar</option>
                <option value="Greece">Greece</option>
                <option value="Greenland">Greenland</option>
                <option value="Grenada">Grenada</option>
                <option value="Guadeloupe">Guadeloupe</option>
                <option value="Guam">Guam</option>
                <option value="Guatemala">Guatemala</option>
                <option value="Guernsey">Guernsey</option>
                <option value="Guinea">Guinea</option>
                <option value="Guinea-Bissau">Guinea-Bissau</option>
                <option value="Guyana">Guyana</option>
                <option value="Haiti">Haiti</option>
                <option value="Heard Island and Mcdonald Islands">Heard Island and Mcdonald Islands</option>
                <option value="Holy See (Vatican City State)">Holy See (Vatican City State)</option>
                <option value="Honduras">Honduras</option>
                <option value="Hong Kong">Hong Kong</option>
                <option value="Hungary">Hungary</option>
                <option value="Iceland">Iceland</option>
                <option value="India">India</option>
                <option value="Indonesia">Indonesia</option>
                <option value="Iran, Islamic Republic of">Iran, Islamic Republic of</option>
                <option value="Iraq">Iraq</option>
                <option value="Ireland">Ireland</option>
                <option value="Isle of Man">Isle of Man</option>
                <option value="Israel">Israel</option>
                <option value="Italy">Italy</option>
                <option value="Jamaica">Jamaica</option>
                <option value="Japan">Japan</option>
                <option value="Jersey">Jersey</option>
                <option value="Jordan">Jordan</option>
                <option value="Kazakhstan">Kazakhstan</option>
                <option value="Kenya">Kenya</option>
                <option value="Kiribati">Kiribati</option>
                <option value="Korea, Democratic People's Republic of">Korea, Democratic People's Republic of</option>
                <option value="Korea, Republic of">Korea, Republic of</option>
                <option value="Kosovo">Kosovo</option>
                <option value="Kuwait">Kuwait</option>
                <option value="Kyrgyzstan">Kyrgyzstan</option>
                <option value="Lao People's Democratic Republic">Lao People's Democratic Republic</option>
                <option value="Latvia">Latvia</option>
                <option value="Lebanon">Lebanon</option>
                <option value="Lesotho">Lesotho</option>
                <option value="Liberia">Liberia</option>
                <option value="Libyan Arab Jamahiriya">Libyan Arab Jamahiriya</option>
                <option value="Liechtenstein">Liechtenstein</option>
                <option value="Lithuania">Lithuania</option>
                <option value="Luxembourg">Luxembourg</option>
                <option value="Macao">Macao</option>
                <option value="Macedonia, the Former Yugoslav Republic of">Macedonia, the Former Yugoslav Republic of</option>
                <option value="Madagascar">Madagascar</option>
                <option value="Malawi">Malawi</option>
                <option value="Malaysia">Malaysia</option>
                <option value="Maldives">Maldives</option>
                <option value="Mali">Mali</option>
                <option value="Malta">Malta</option>
                <option value="Marshall Islands">Marshall Islands</option>
                <option value="Martinique">Martinique</option>
                <option value="Mauritania">Mauritania</option>
                <option value="Mauritius">Mauritius</option>
                <option value="Mayotte">Mayotte</option>
                <option value="Mexico">Mexico</option>
                <option value="Micronesia, Federated States of">Micronesia, Federated States of</option>
                <option value="Moldova, Republic of">Moldova, Republic of</option>
                <option value="Monaco">Monaco</option>
                <option value="Mongolia">Mongolia</option>
                <option value="Montenegro">Montenegro</option>
                <option value="Montserrat">Montserrat</option>
                <option value="Morocco">Morocco</option>
                <option value="Mozambique">Mozambique</option>
                <option value="Myanmar">Myanmar</option>
                <option value="Namibia">Namibia</option>
                <option value="Nauru">Nauru</option>
                <option value="Nepal">Nepal</option>
                <option value="Netherlands">Netherlands</option>
                <option value="Netherlands Antilles">Netherlands Antilles</option>
                <option value="New Caledonia">New Caledonia</option>
                <option value="New Zealand">New Zealand</option>
                <option value="Nicaragua">Nicaragua</option>
                <option value="Niger">Niger</option>
                <option value="Nigeria">Nigeria</option>
                <option value="Niue">Niue</option>
                <option value="Norfolk Island">Norfolk Island</option>
                <option value="Northern Mariana Islands">Northern Mariana Islands</option>
                <option value="Norway">Norway</option>
                <option value="Oman">Oman</option>
                <option value="Pakistan">Pakistan</option>
                <option value="Palau">Palau</option>
                <option value="Palestinian Territory, Occupied">Palestinian Territory, Occupied</option>
                <option value="Panama">Panama</option>
                <option value="Papua New Guinea">Papua New Guinea</option>
                <option value="Paraguay">Paraguay</option>
                <option value="Peru">Peru</option>
                <option value="Philippines">Philippines</option>
                <option value="Pitcairn">Pitcairn</option>
                <option value="Poland">Poland</option>
                <option value="Portugal">Portugal</option>
                <option value="Puerto Rico">Puerto Rico</option>
                <option value="Qatar">Qatar</option>
                <option value="Reunion">Reunion</option>
                <option value="Romania">Romania</option>
                <option value="Russian Federation">Russian Federation</option>
                <option value="Rwanda">Rwanda</option>
                <option value="Saint Barthelemy">Saint Barthelemy</option>
                <option value="Saint Helena">Saint Helena</option>
                <option value="Saint Kitts and Nevis">Saint Kitts and Nevis</option>
                <option value="Saint Lucia">Saint Lucia</option>
                <option value="Saint Martin">Saint Martin</option>
                <option value="Saint Pierre and Miquelon">Saint Pierre and Miquelon</option>
                <option value="Saint Vincent and the Grenadines">Saint Vincent and the Grenadines</option>
                <option value="Samoa">Samoa</option>
                <option value="San Marino">San Marino</option>
                <option value="Sao Tome and Principe">Sao Tome and Principe</option>
                <option value="Saudi Arabia">Saudi Arabia</option>
                <option value="Senegal">Senegal</option>
                <option value="Serbia">Serbia</option>
                <option value="Serbia and Montenegro">Serbia and Montenegro</option>
                <option value="Seychelles">Seychelles</option>
                <option value="Sierra Leone">Sierra Leone</option>
                <option value="Singapore">Singapore</option>
                <option value="Sint Maarten">Sint Maarten</option>
                <option value="Slovakia">Slovakia</option>
                <option value="Slovenia">Slovenia</option>
                <option value="Solomon Islands">Solomon Islands</option>
                <option value="Somalia">Somalia</option>
                <option value="South Africa">South Africa</option>
                <option value="South Georgia and the South Sandwich Islands">South Georgia and the South Sandwich Islands</option>
                <option value="South Sudan">South Sudan</option>
                <option value="Spain">Spain</option>
                <option value="Sri Lanka">Sri Lanka</option>
                <option value="Sudan">Sudan</option>
                <option value="Suriname">Suriname</option>
                <option value="Svalbard and Jan Mayen">Svalbard and Jan Mayen</option>
                <option value="Swaziland">Swaziland</option>
                <option value="Sweden">Sweden</option>
                <option value="Switzerland">Switzerland</option>
                <option value="Syrian Arab Republic">Syrian Arab Republic</option>
                <option value="Taiwan, Province of China">Taiwan, Province of China</option>
                <option value="Tajikistan">Tajikistan</option>
                <option value="Tanzania, United Republic of">Tanzania, United Republic of</option>
                <option value="Thailand">Thailand</option>
                <option value="Timor-Leste">Timor-Leste</option>
                <option value="Togo">Togo</option>
                <option value="Tokelau">Tokelau</option>
                <option value="Tonga">Tonga</option>
                <option value="Trinidad and Tobago">Trinidad and Tobago</option>
                <option value="Tunisia">Tunisia</option>
                <option value="Turkey">Turkey</option>
                <option value="Turkmenistan">Turkmenistan</option>
                <option value="Turks and Caicos Islands">Turks and Caicos Islands</option>
                <option value="Tuvalu">Tuvalu</option>
                <option value="Uganda">Uganda</option>
                <option value="Ukraine">Ukraine</option>
                <option value="United Arab Emirates">United Arab Emirates</option>
                <option value="United Kingdom">United Kingdom</option>
                <option value="United States">United States</option>
                <option value="United States Minor Outlying Islands">United States Minor Outlying Islands</option>
                <option value="Uruguay">Uruguay</option>
                <option value="Uzbekistan">Uzbekistan</option>
                <option value="Vanuatu">Vanuatu</option>
                <option value="Venezuela">Venezuela</option>
                <option value="Viet Nam">Viet Nam</option>
                <option value="Virgin Islands, British">Virgin Islands, British</option>
                <option value="Virgin Islands, U.s.">Virgin Islands, U.s.</option>
                <option value="Wallis and Futuna">Wallis and Futuna</option>
                <option value="Western Sahara">Western Sahara</option>
                <option value="Yemen">Yemen</option>
                <option value="Zambia">Zambia</option>
                <option value="Zimbabwe">Zimbabwe</option>
                </select>
                <p>Co-Author 2 Email</p>
                <input type="email" class="text" value="" name="coauth2email" aria-label="Co-Author 2 Email">
                </div>
				                  <div class="coauthor-group" id="coauthor-3">
				                  <p>CO-Auther-3 Full Name </p>
                 <input type="text" class="text" value="" name="coauth3name" >
  				  				   <p>Co-Auther 3 Nationality </p>
                 <select name="coauth3nationality" class="text" name="coauth3nationality">
                 <option value=""></option>
                <option value="Afghanistan">Afghanistan</option>
                <option value="Aland Islands">Aland Islands</option>
                <option value="Albania">Albania</option>
                <option value="Algeria">Algeria</option>
                <option value="American Samoa">American Samoa</option>
                <option value="Andorra">Andorra</option>
                <option value="Angola">Angola</option>
                <option value="Anguilla">Anguilla</option>
                <option value="Antarctica">Antarctica</option>
                <option value="Antigua and Barbuda">Antigua and Barbuda</option>
                <option value="Argentina">Argentina</option>
                <option value="Armenia">Armenia</option>
                <option value="Aruba">Aruba</option>
                <option value="Australia">Australia</option>
                <option value="Austria">Austria</option>
                <option value="Azerbaijan">Azerbaijan</option>
                <option value="Bahamas">Bahamas</option>
                <option value="Bahrain">Bahrain</option>
                <option value="Bangladesh">Bangladesh</option>
                <option value="Barbados">Barbados</option>
                <option value="Belarus">Belarus</option>
                <option value="Belgium">Belgium</option>
                <option value="Belize">Belize</option>
                <option value="Benin">Benin</option>
                <option value="Bermuda">Bermuda</option>
                <option value="Bhutan">Bhutan</option>
                <option value="Bolivia">Bolivia</option>
                <option value="Bonaire, Sint Eustatius and Saba">Bonaire, Sint Eustatius and Saba</option>
                <option value="Bosnia and Herzegovina">Bosnia and Herzegovina</option>
                <option value="Botswana">Botswana</option>
                <option value="Bouvet Island">Bouvet Island</option>
                <option value="Brazil">Brazil</option>
                <option value="British Indian Ocean Territory">British Indian Ocean Territory</option>
                <option value="Brunei Darussalam">Brunei Darussalam</option>
                <option value="Bulgaria">Bulgaria</option>
                <option value="Burkina Faso">Burkina Faso</option>
                <option value="Burundi">Burundi</option>
                <option value="Cambodia">Cambodia</option>
                <option value="Cameroon">Cameroon</option>
                <option value="Canada">Canada</option>
                <option value="Cape Verde">Cape Verde</option>
                <option value="Cayman Islands">Cayman Islands</option>
                <option value="Central African Republic">Central African Republic</option>
                <option value="Chad">Chad</option>
                <option value="Chile">Chile</option>
                <option value="China">China</option>
                <option value="Christmas Island">Christmas Island</option>
                <option value="Cocos (Keeling) Islands">Cocos (Keeling) Islands</option>
                <option value="Colombia">Colombia</option>
                <option value="Comoros">Comoros</option>
                <option value="Congo">Congo</option>
                <option value="Congo, Democratic Republic of the Congo">Congo, Democratic Republic of the Congo</option>
                <option value="Cook Islands">Cook Islands</option>
                <option value="Costa Rica">Costa Rica</option>
                <option value="Cote D'Ivoire">Cote D'Ivoire</option>
                <option value="Croatia">Croatia</option>
                <option value="Cuba">Cuba</option>
                <option value="Curacao">Curacao</option>
                <option value="Cyprus">Cyprus</option>
                <option value="Czech Republic">Czech Republic</option>
                <option value="Denmark">Denmark</option>
                <option value="Djibouti">Djibouti</option>
                <option value="Dominica">Dominica</option>
                <option value="Dominican Republic">Dominican Republic</option>
                <option value="Ecuador">Ecuador</option>
                <option value="Egypt">Egypt</option>
                <option value="El Salvador">El Salvador</option>
                <option value="Equatorial Guinea">Equatorial Guinea</option>
                <option value="Eritrea">Eritrea</option>
                <option value="Estonia">Estonia</option>
                <option value="Ethiopia">Ethiopia</option>
                <option value="Falkland Islands (Malvinas)">Falkland Islands (Malvinas)</option>
                <option value="Faroe Islands">Faroe Islands</option>
                <option value="Fiji">Fiji</option>
                <option value="Finland">Finland</option>
                <option value="France">France</option>
                <option value="French Guiana">French Guiana</option>
                <option value="French Polynesia">French Polynesia</option>
                <option value="French Southern Territories">French Southern Territories</option>
                <option value="Gabon">Gabon</option>
                <option value="Gambia">Gambia</option>
                <option value="Georgia">Georgia</option>
                <option value="Germany">Germany</option>
                <option value="Ghana">Ghana</option>
                <option value="Gibraltar">Gibraltar</option>
                <option value="Greece">Greece</option>
                <option value="Greenland">Greenland</option>
                <option value="Grenada">Grenada</option>
                <option value="Guadeloupe">Guadeloupe</option>
                <option value="Guam">Guam</option>
                <option value="Guatemala">Guatemala</option>
                <option value="Guernsey">Guernsey</option>
                <option value="Guinea">Guinea</option>
                <option value="Guinea-Bissau">Guinea-Bissau</option>
                <option value="Guyana">Guyana</option>
                <option value="Haiti">Haiti</option>
                <option value="Heard Island and Mcdonald Islands">Heard Island and Mcdonald Islands</option>
                <option value="Holy See (Vatican City State)">Holy See (Vatican City State)</option>
                <option value="Honduras">Honduras</option>
                <option value="Hong Kong">Hong Kong</option>
                <option value="Hungary">Hungary</option>
                <option value="Iceland">Iceland</option>
                <option value="India">India</option>
                <option value="Indonesia">Indonesia</option>
                <option value="Iran, Islamic Republic of">Iran, Islamic Republic of</option>
                <option value="Iraq">Iraq</option>
                <option value="Ireland">Ireland</option>
                <option value="Isle of Man">Isle of Man</option>
                <option value="Israel">Israel</option>
                <option value="Italy">Italy</option>
                <option value="Jamaica">Jamaica</option>
                <option value="Japan">Japan</option>
                <option value="Jersey">Jersey</option>
                <option value="Jordan">Jordan</option>
                <option value="Kazakhstan">Kazakhstan</option>
                <option value="Kenya">Kenya</option>
                <option value="Kiribati">Kiribati</option>
                <option value="Korea, Democratic People's Republic of">Korea, Democratic People's Republic of</option>
                <option value="Korea, Republic of">Korea, Republic of</option>
                <option value="Kosovo">Kosovo</option>
                <option value="Kuwait">Kuwait</option>
                <option value="Kyrgyzstan">Kyrgyzstan</option>
                <option value="Lao People's Democratic Republic">Lao People's Democratic Republic</option>
                <option value="Latvia">Latvia</option>
                <option value="Lebanon">Lebanon</option>
                <option value="Lesotho">Lesotho</option>
                <option value="Liberia">Liberia</option>
                <option value="Libyan Arab Jamahiriya">Libyan Arab Jamahiriya</option>
                <option value="Liechtenstein">Liechtenstein</option>
                <option value="Lithuania">Lithuania</option>
                <option value="Luxembourg">Luxembourg</option>
                <option value="Macao">Macao</option>
                <option value="Macedonia, the Former Yugoslav Republic of">Macedonia, the Former Yugoslav Republic of</option>
                <option value="Madagascar">Madagascar</option>
                <option value="Malawi">Malawi</option>
                <option value="Malaysia">Malaysia</option>
                <option value="Maldives">Maldives</option>
                <option value="Mali">Mali</option>
                <option value="Malta">Malta</option>
                <option value="Marshall Islands">Marshall Islands</option>
                <option value="Martinique">Martinique</option>
                <option value="Mauritania">Mauritania</option>
                <option value="Mauritius">Mauritius</option>
                <option value="Mayotte">Mayotte</option>
                <option value="Mexico">Mexico</option>
                <option value="Micronesia, Federated States of">Micronesia, Federated States of</option>
                <option value="Moldova, Republic of">Moldova, Republic of</option>
                <option value="Monaco">Monaco</option>
                <option value="Mongolia">Mongolia</option>
                <option value="Montenegro">Montenegro</option>
                <option value="Montserrat">Montserrat</option>
                <option value="Morocco">Morocco</option>
                <option value="Mozambique">Mozambique</option>
                <option value="Myanmar">Myanmar</option>
                <option value="Namibia">Namibia</option>
                <option value="Nauru">Nauru</option>
                <option value="Nepal">Nepal</option>
                <option value="Netherlands">Netherlands</option>
                <option value="Netherlands Antilles">Netherlands Antilles</option>
                <option value="New Caledonia">New Caledonia</option>
                <option value="New Zealand">New Zealand</option>
                <option value="Nicaragua">Nicaragua</option>
                <option value="Niger">Niger</option>
                <option value="Nigeria">Nigeria</option>
                <option value="Niue">Niue</option>
                <option value="Norfolk Island">Norfolk Island</option>
                <option value="Northern Mariana Islands">Northern Mariana Islands</option>
                <option value="Norway">Norway</option>
                <option value="Oman">Oman</option>
                <option value="Pakistan">Pakistan</option>
                <option value="Palau">Palau</option>
                <option value="Palestinian Territory, Occupied">Palestinian Territory, Occupied</option>
                <option value="Panama">Panama</option>
                <option value="Papua New Guinea">Papua New Guinea</option>
                <option value="Paraguay">Paraguay</option>
                <option value="Peru">Peru</option>
                <option value="Philippines">Philippines</option>
                <option value="Pitcairn">Pitcairn</option>
                <option value="Poland">Poland</option>
                <option value="Portugal">Portugal</option>
                <option value="Puerto Rico">Puerto Rico</option>
                <option value="Qatar">Qatar</option>
                <option value="Reunion">Reunion</option>
                <option value="Romania">Romania</option>
                <option value="Russian Federation">Russian Federation</option>
                <option value="Rwanda">Rwanda</option>
                <option value="Saint Barthelemy">Saint Barthelemy</option>
                <option value="Saint Helena">Saint Helena</option>
                <option value="Saint Kitts and Nevis">Saint Kitts and Nevis</option>
                <option value="Saint Lucia">Saint Lucia</option>
                <option value="Saint Martin">Saint Martin</option>
                <option value="Saint Pierre and Miquelon">Saint Pierre and Miquelon</option>
                <option value="Saint Vincent and the Grenadines">Saint Vincent and the Grenadines</option>
                <option value="Samoa">Samoa</option>
                <option value="San Marino">San Marino</option>
                <option value="Sao Tome and Principe">Sao Tome and Principe</option>
                <option value="Saudi Arabia">Saudi Arabia</option>
                <option value="Senegal">Senegal</option>
                <option value="Serbia">Serbia</option>
                <option value="Serbia and Montenegro">Serbia and Montenegro</option>
                <option value="Seychelles">Seychelles</option>
                <option value="Sierra Leone">Sierra Leone</option>
                <option value="Singapore">Singapore</option>
                <option value="Sint Maarten">Sint Maarten</option>
                <option value="Slovakia">Slovakia</option>
                <option value="Slovenia">Slovenia</option>
                <option value="Solomon Islands">Solomon Islands</option>
                <option value="Somalia">Somalia</option>
                <option value="South Africa">South Africa</option>
                <option value="South Georgia and the South Sandwich Islands">South Georgia and the South Sandwich Islands</option>
                <option value="South Sudan">South Sudan</option>
                <option value="Spain">Spain</option>
                <option value="Sri Lanka">Sri Lanka</option>
                <option value="Sudan">Sudan</option>
                <option value="Suriname">Suriname</option>
                <option value="Svalbard and Jan Mayen">Svalbard and Jan Mayen</option>
                <option value="Swaziland">Swaziland</option>
                <option value="Sweden">Sweden</option>
                <option value="Switzerland">Switzerland</option>
                <option value="Syrian Arab Republic">Syrian Arab Republic</option>
                <option value="Taiwan, Province of China">Taiwan, Province of China</option>
                <option value="Tajikistan">Tajikistan</option>
                <option value="Tanzania, United Republic of">Tanzania, United Republic of</option>
                <option value="Thailand">Thailand</option>
                <option value="Timor-Leste">Timor-Leste</option>
                <option value="Togo">Togo</option>
                <option value="Tokelau">Tokelau</option>
                <option value="Tonga">Tonga</option>
                <option value="Trinidad and Tobago">Trinidad and Tobago</option>
                <option value="Tunisia">Tunisia</option>
                <option value="Turkey">Turkey</option>
                <option value="Turkmenistan">Turkmenistan</option>
                <option value="Turks and Caicos Islands">Turks and Caicos Islands</option>
                <option value="Tuvalu">Tuvalu</option>
                <option value="Uganda">Uganda</option>
                <option value="Ukraine">Ukraine</option>
                <option value="United Arab Emirates">United Arab Emirates</option>
                <option value="United Kingdom">United Kingdom</option>
                <option value="United States">United States</option>
                <option value="United States Minor Outlying Islands">United States Minor Outlying Islands</option>
                <option value="Uruguay">Uruguay</option>
                <option value="Uzbekistan">Uzbekistan</option>
                <option value="Vanuatu">Vanuatu</option>
                <option value="Venezuela">Venezuela</option>
                <option value="Viet Nam">Viet Nam</option>
                <option value="Virgin Islands, British">Virgin Islands, British</option>
                <option value="Virgin Islands, U.s.">Virgin Islands, U.s.</option>
                <option value="Wallis and Futuna">Wallis and Futuna</option>
                <option value="Western Sahara">Western Sahara</option>
                <option value="Yemen">Yemen</option>
                <option value="Zambia">Zambia</option>
                <option value="Zimbabwe">Zimbabwe</option>
                </select>
                <p>Co-Author 3 Email</p>
                <input type="email" class="text" value="" name="coauth3email" aria-label="Co-Author 3 Email">
                </div>
				         <div class="coauthor-group" id="coauthor-4">
				         <p>CO-Auther-4 Full Name </p>
                 <input type="text" class="text" value="" name="coauth4name" >
  				  			<p>Co-Auther 4 Nationality </p>
                 <select name="coauth4nationality" class="text" name="coauth4nationality">
                 <option value=""></option>
                <option value="Afghanistan">Afghanistan</option>
                <option value="Aland Islands">Aland Islands</option>
                <option value="Albania">Albania</option>
                <option value="Algeria">Algeria</option>
                <option value="American Samoa">American Samoa</option>
                <option value="Andorra">Andorra</option>
                <option value="Angola">Angola</option>
                <option value="Anguilla">Anguilla</option>
                <option value="Antarctica">Antarctica</option>
                <option value="Antigua and Barbuda">Antigua and Barbuda</option>
                <option value="Argentina">Argentina</option>
                <option value="Armenia">Armenia</option>
                <option value="Aruba">Aruba</option>
                <option value="Australia">Australia</option>
                <option value="Austria">Austria</option>
                <option value="Azerbaijan">Azerbaijan</option>
                <option value="Bahamas">Bahamas</option>
                <option value="Bahrain">Bahrain</option>
                <option value="Bangladesh">Bangladesh</option>
                <option value="Barbados">Barbados</option>
                <option value="Belarus">Belarus</option>
                <option value="Belgium">Belgium</option>
                <option value="Belize">Belize</option>
                <option value="Benin">Benin</option>
                <option value="Bermuda">Bermuda</option>
                <option value="Bhutan">Bhutan</option>
                <option value="Bolivia">Bolivia</option>
                <option value="Bonaire, Sint Eustatius and Saba">Bonaire, Sint Eustatius and Saba</option>
                <option value="Bosnia and Herzegovina">Bosnia and Herzegovina</option>
                <option value="Botswana">Botswana</option>
                <option value="Bouvet Island">Bouvet Island</option>
                <option value="Brazil">Brazil</option>
                <option value="British Indian Ocean Territory">British Indian Ocean Territory</option>
                <option value="Brunei Darussalam">Brunei Darussalam</option>
                <option value="Bulgaria">Bulgaria</option>
                <option value="Burkina Faso">Burkina Faso</option>
                <option value="Burundi">Burundi</option>
                <option value="Cambodia">Cambodia</option>
                <option value="Cameroon">Cameroon</option>
                <option value="Canada">Canada</option>
                <option value="Cape Verde">Cape Verde</option>
                <option value="Cayman Islands">Cayman Islands</option>
                <option value="Central African Republic">Central African Republic</option>
                <option value="Chad">Chad</option>
                <option value="Chile">Chile</option>
                <option value="China">China</option>
                <option value="Christmas Island">Christmas Island</option>
                <option value="Cocos (Keeling) Islands">Cocos (Keeling) Islands</option>
                <option value="Colombia">Colombia</option>
                <option value="Comoros">Comoros</option>
                <option value="Congo">Congo</option>
                <option value="Congo, Democratic Republic of the Congo">Congo, Democratic Republic of the Congo</option>
                <option value="Cook Islands">Cook Islands</option>
                <option value="Costa Rica">Costa Rica</option>
                <option value="Cote D'Ivoire">Cote D'Ivoire</option>
                <option value="Croatia">Croatia</option>
                <option value="Cuba">Cuba</option>
                <option value="Curacao">Curacao</option>
                <option value="Cyprus">Cyprus</option>
                <option value="Czech Republic">Czech Republic</option>
                <option value="Denmark">Denmark</option>
                <option value="Djibouti">Djibouti</option>
                <option value="Dominica">Dominica</option>
                <option value="Dominican Republic">Dominican Republic</option>
                <option value="Ecuador">Ecuador</option>
                <option value="Egypt">Egypt</option>
                <option value="El Salvador">El Salvador</option>
                <option value="Equatorial Guinea">Equatorial Guinea</option>
                <option value="Eritrea">Eritrea</option>
                <option value="Estonia">Estonia</option>
                <option value="Ethiopia">Ethiopia</option>
                <option value="Falkland Islands (Malvinas)">Falkland Islands (Malvinas)</option>
                <option value="Faroe Islands">Faroe Islands</option>
                <option value="Fiji">Fiji</option>
                <option value="Finland">Finland</option>
                <option value="France">France</option>
                <option value="French Guiana">French Guiana</option>
                <option value="French Polynesia">French Polynesia</option>
                <option value="French Southern Territories">French Southern Territories</option>
                <option value="Gabon">Gabon</option>
                <option value="Gambia">Gambia</option>
                <option value="Georgia">Georgia</option>
                <option value="Germany">Germany</option>
                <option value="Ghana">Ghana</option>
                <option value="Gibraltar">Gibraltar</option>
                <option value="Greece">Greece</option>
                <option value="Greenland">Greenland</option>
                <option value="Grenada">Grenada</option>
                <option value="Guadeloupe">Guadeloupe</option>
                <option value="Guam">Guam</option>
                <option value="Guatemala">Guatemala</option>
                <option value="Guernsey">Guernsey</option>
                <option value="Guinea">Guinea</option>
                <option value="Guinea-Bissau">Guinea-Bissau</option>
                <option value="Guyana">Guyana</option>
                <option value="Haiti">Haiti</option>
                <option value="Heard Island and Mcdonald Islands">Heard Island and Mcdonald Islands</option>
                <option value="Holy See (Vatican City State)">Holy See (Vatican City State)</option>
                <option value="Honduras">Honduras</option>
                <option value="Hong Kong">Hong Kong</option>
                <option value="Hungary">Hungary</option>
                <option value="Iceland">Iceland</option>
                <option value="India">India</option>
                <option value="Indonesia">Indonesia</option>
                <option value="Iran, Islamic Republic of">Iran, Islamic Republic of</option>
                <option value="Iraq">Iraq</option>
                <option value="Ireland">Ireland</option>
                <option value="Isle of Man">Isle of Man</option>
                <option value="Israel">Israel</option>
                <option value="Italy">Italy</option>
                <option value="Jamaica">Jamaica</option>
                <option value="Japan">Japan</option>
                <option value="Jersey">Jersey</option>
                <option value="Jordan">Jordan</option>
                <option value="Kazakhstan">Kazakhstan</option>
                <option value="Kenya">Kenya</option>
                <option value="Kiribati">Kiribati</option>
                <option value="Korea, Democratic People's Republic of">Korea, Democratic People's Republic of</option>
                <option value="Korea, Republic of">Korea, Republic of</option>
                <option value="Kosovo">Kosovo</option>
                <option value="Kuwait">Kuwait</option>
                <option value="Kyrgyzstan">Kyrgyzstan</option>
                <option value="Lao People's Democratic Republic">Lao People's Democratic Republic</option>
                <option value="Latvia">Latvia</option>
                <option value="Lebanon">Lebanon</option>
                <option value="Lesotho">Lesotho</option>
                <option value="Liberia">Liberia</option>
                <option value="Libyan Arab Jamahiriya">Libyan Arab Jamahiriya</option>
                <option value="Liechtenstein">Liechtenstein</option>
                <option value="Lithuania">Lithuania</option>
                <option value="Luxembourg">Luxembourg</option>
                <option value="Macao">Macao</option>
                <option value="Macedonia, the Former Yugoslav Republic of">Macedonia, the Former Yugoslav Republic of</option>
                <option value="Madagascar">Madagascar</option>
                <option value="Malawi">Malawi</option>
                <option value="Malaysia">Malaysia</option>
                <option value="Maldives">Maldives</option>
                <option value="Mali">Mali</option>
                <option value="Malta">Malta</option>
                <option value="Marshall Islands">Marshall Islands</option>
                <option value="Martinique">Martinique</option>
                <option value="Mauritania">Mauritania</option>
                <option value="Mauritius">Mauritius</option>
                <option value="Mayotte">Mayotte</option>
                <option value="Mexico">Mexico</option>
                <option value="Micronesia, Federated States of">Micronesia, Federated States of</option>
                <option value="Moldova, Republic of">Moldova, Republic of</option>
                <option value="Monaco">Monaco</option>
                <option value="Mongolia">Mongolia</option>
                <option value="Montenegro">Montenegro</option>
                <option value="Montserrat">Montserrat</option>
                <option value="Morocco">Morocco</option>
                <option value="Mozambique">Mozambique</option>
                <option value="Myanmar">Myanmar</option>
                <option value="Namibia">Namibia</option>
                <option value="Nauru">Nauru</option>
                <option value="Nepal">Nepal</option>
                <option value="Netherlands">Netherlands</option>
                <option value="Netherlands Antilles">Netherlands Antilles</option>
                <option value="New Caledonia">New Caledonia</option>
                <option value="New Zealand">New Zealand</option>
                <option value="Nicaragua">Nicaragua</option>
                <option value="Niger">Niger</option>
                <option value="Nigeria">Nigeria</option>
                <option value="Niue">Niue</option>
                <option value="Norfolk Island">Norfolk Island</option>
                <option value="Northern Mariana Islands">Northern Mariana Islands</option>
                <option value="Norway">Norway</option>
                <option value="Oman">Oman</option>
                <option value="Pakistan">Pakistan</option>
                <option value="Palau">Palau</option>
                <option value="Palestinian Territory, Occupied">Palestinian Territory, Occupied</option>
                <option value="Panama">Panama</option>
                <option value="Papua New Guinea">Papua New Guinea</option>
                <option value="Paraguay">Paraguay</option>
                <option value="Peru">Peru</option>
                <option value="Philippines">Philippines</option>
                <option value="Pitcairn">Pitcairn</option>
                <option value="Poland">Poland</option>
                <option value="Portugal">Portugal</option>
                <option value="Puerto Rico">Puerto Rico</option>
                <option value="Qatar">Qatar</option>
                <option value="Reunion">Reunion</option>
                <option value="Romania">Romania</option>
                <option value="Russian Federation">Russian Federation</option>
                <option value="Rwanda">Rwanda</option>
                <option value="Saint Barthelemy">Saint Barthelemy</option>
                <option value="Saint Helena">Saint Helena</option>
                <option value="Saint Kitts and Nevis">Saint Kitts and Nevis</option>
                <option value="Saint Lucia">Saint Lucia</option>
                <option value="Saint Martin">Saint Martin</option>
                <option value="Saint Pierre and Miquelon">Saint Pierre and Miquelon</option>
                <option value="Saint Vincent and the Grenadines">Saint Vincent and the Grenadines</option>
                <option value="Samoa">Samoa</option>
                <option value="San Marino">San Marino</option>
                <option value="Sao Tome and Principe">Sao Tome and Principe</option>
                <option value="Saudi Arabia">Saudi Arabia</option>
                <option value="Senegal">Senegal</option>
                <option value="Serbia">Serbia</option>
                <option value="Serbia and Montenegro">Serbia and Montenegro</option>
                <option value="Seychelles">Seychelles</option>
                <option value="Sierra Leone">Sierra Leone</option>
                <option value="Singapore">Singapore</option>
                <option value="Sint Maarten">Sint Maarten</option>
                <option value="Slovakia">Slovakia</option>
                <option value="Slovenia">Slovenia</option>
                <option value="Solomon Islands">Solomon Islands</option>
                <option value="Somalia">Somalia</option>
                <option value="South Africa">South Africa</option>
                <option value="South Georgia and the South Sandwich Islands">South Georgia and the South Sandwich Islands</option>
                <option value="South Sudan">South Sudan</option>
                <option value="Spain">Spain</option>
                <option value="Sri Lanka">Sri Lanka</option>
                <option value="Sudan">Sudan</option>
                <option value="Suriname">Suriname</option>
                <option value="Svalbard and Jan Mayen">Svalbard and Jan Mayen</option>
                <option value="Swaziland">Swaziland</option>
                <option value="Sweden">Sweden</option>
                <option value="Switzerland">Switzerland</option>
                <option value="Syrian Arab Republic">Syrian Arab Republic</option>
                <option value="Taiwan, Province of China">Taiwan, Province of China</option>
                <option value="Tajikistan">Tajikistan</option>
                <option value="Tanzania, United Republic of">Tanzania, United Republic of</option>
                <option value="Thailand">Thailand</option>
                <option value="Timor-Leste">Timor-Leste</option>
                <option value="Togo">Togo</option>
                <option value="Tokelau">Tokelau</option>
                <option value="Tonga">Tonga</option>
                <option value="Trinidad and Tobago">Trinidad and Tobago</option>
                <option value="Tunisia">Tunisia</option>
                <option value="Turkey">Turkey</option>
                <option value="Turkmenistan">Turkmenistan</option>
                <option value="Turks and Caicos Islands">Turks and Caicos Islands</option>
                <option value="Tuvalu">Tuvalu</option>
                <option value="Uganda">Uganda</option>
                <option value="Ukraine">Ukraine</option>
                <option value="United Arab Emirates">United Arab Emirates</option>
                <option value="United Kingdom">United Kingdom</option>
                <option value="United States">United States</option>
                <option value="United States Minor Outlying Islands">United States Minor Outlying Islands</option>
                <option value="Uruguay">Uruguay</option>
                <option value="Uzbekistan">Uzbekistan</option>
                <option value="Vanuatu">Vanuatu</option>
                <option value="Venezuela">Venezuela</option>
                <option value="Viet Nam">Viet Nam</option>
                <option value="Virgin Islands, British">Virgin Islands, British</option>
                <option value="Virgin Islands, U.s.">Virgin Islands, U.s.</option>
                <option value="Wallis and Futuna">Wallis and Futuna</option>
                <option value="Western Sahara">Western Sahara</option>
                <option value="Yemen">Yemen</option>
                <option value="Zambia">Zambia</option>
                <option value="Zimbabwe">Zimbabwe</option>
                </select>
                <p>Co-Author 4 Email</p>
                <input type="email" class="text" value="" name="coauth4email" aria-label="Co-Author 4 Email">
                </div>
				                  <div class="coauthor-group" id="coauthor-5">
				                  <p>CO-Auther-5 Full Name </p>
                 <input type="text" class="text" value="" name="coauth5name" >
  				  				   <p>Co-Auther 5 Nationality </p>
                 <select name="coauth5nationality" class="text" name="coauth5nationality">
                 <option value=""></option>
                <option value="Afghanistan">Afghanistan</option>
                <option value="Aland Islands">Aland Islands</option>
                <option value="Albania">Albania</option>
                <option value="Algeria">Algeria</option>
                <option value="American Samoa">American Samoa</option>
                <option value="Andorra">Andorra</option>
                <option value="Angola">Angola</option>
                <option value="Anguilla">Anguilla</option>
                <option value="Antarctica">Antarctica</option>
                <option value="Antigua and Barbuda">Antigua and Barbuda</option>
                <option value="Argentina">Argentina</option>
                <option value="Armenia">Armenia</option>
                <option value="Aruba">Aruba</option>
                <option value="Australia">Australia</option>
                <option value="Austria">Austria</option>
                <option value="Azerbaijan">Azerbaijan</option>
                <option value="Bahamas">Bahamas</option>
                <option value="Bahrain">Bahrain</option>
                <option value="Bangladesh">Bangladesh</option>
                <option value="Barbados">Barbados</option>
                <option value="Belarus">Belarus</option>
                <option value="Belgium">Belgium</option>
                <option value="Belize">Belize</option>
                <option value="Benin">Benin</option>
                <option value="Bermuda">Bermuda</option>
                <option value="Bhutan">Bhutan</option>
                <option value="Bolivia">Bolivia</option>
                <option value="Bonaire, Sint Eustatius and Saba">Bonaire, Sint Eustatius and Saba</option>
                <option value="Bosnia and Herzegovina">Bosnia and Herzegovina</option>
                <option value="Botswana">Botswana</option>
                <option value="Bouvet Island">Bouvet Island</option>
                <option value="Brazil">Brazil</option>
                <option value="British Indian Ocean Territory">British Indian Ocean Territory</option>
                <option value="Brunei Darussalam">Brunei Darussalam</option>
                <option value="Bulgaria">Bulgaria</option>
                <option value="Burkina Faso">Burkina Faso</option>
                <option value="Burundi">Burundi</option>
                <option value="Cambodia">Cambodia</option>
                <option value="Cameroon">Cameroon</option>
                <option value="Canada">Canada</option>
                <option value="Cape Verde">Cape Verde</option>
                <option value="Cayman Islands">Cayman Islands</option>
                <option value="Central African Republic">Central African Republic</option>
                <option value="Chad">Chad</option>
                <option value="Chile">Chile</option>
                <option value="China">China</option>
                <option value="Christmas Island">Christmas Island</option>
                <option value="Cocos (Keeling) Islands">Cocos (Keeling) Islands</option>
                <option value="Colombia">Colombia</option>
                <option value="Comoros">Comoros</option>
                <option value="Congo">Congo</option>
                <option value="Congo, Democratic Republic of the Congo">Congo, Democratic Republic of the Congo</option>
                <option value="Cook Islands">Cook Islands</option>
                <option value="Costa Rica">Costa Rica</option>
                <option value="Cote D'Ivoire">Cote D'Ivoire</option>
                <option value="Croatia">Croatia</option>
                <option value="Cuba">Cuba</option>
                <option value="Curacao">Curacao</option>
                <option value="Cyprus">Cyprus</option>
                <option value="Czech Republic">Czech Republic</option>
                <option value="Denmark">Denmark</option>
                <option value="Djibouti">Djibouti</option>
                <option value="Dominica">Dominica</option>
                <option value="Dominican Republic">Dominican Republic</option>
                <option value="Ecuador">Ecuador</option>
                <option value="Egypt">Egypt</option>
                <option value="El Salvador">El Salvador</option>
                <option value="Equatorial Guinea">Equatorial Guinea</option>
                <option value="Eritrea">Eritrea</option>
                <option value="Estonia">Estonia</option>
                <option value="Ethiopia">Ethiopia</option>
                <option value="Falkland Islands (Malvinas)">Falkland Islands (Malvinas)</option>
                <option value="Faroe Islands">Faroe Islands</option>
                <option value="Fiji">Fiji</option>
                <option value="Finland">Finland</option>
                <option value="France">France</option>
                <option value="French Guiana">French Guiana</option>
                <option value="French Polynesia">French Polynesia</option>
                <option value="French Southern Territories">French Southern Territories</option>
                <option value="Gabon">Gabon</option>
                <option value="Gambia">Gambia</option>
                <option value="Georgia">Georgia</option>
                <option value="Germany">Germany</option>
                <option value="Ghana">Ghana</option>
                <option value="Gibraltar">Gibraltar</option>
                <option value="Greece">Greece</option>
                <option value="Greenland">Greenland</option>
                <option value="Grenada">Grenada</option>
                <option value="Guadeloupe">Guadeloupe</option>
                <option value="Guam">Guam</option>
                <option value="Guatemala">Guatemala</option>
                <option value="Guernsey">Guernsey</option>
                <option value="Guinea">Guinea</option>
                <option value="Guinea-Bissau">Guinea-Bissau</option>
                <option value="Guyana">Guyana</option>
                <option value="Haiti">Haiti</option>
                <option value="Heard Island and Mcdonald Islands">Heard Island and Mcdonald Islands</option>
                <option value="Holy See (Vatican City State)">Holy See (Vatican City State)</option>
                <option value="Honduras">Honduras</option>
                <option value="Hong Kong">Hong Kong</option>
                <option value="Hungary">Hungary</option>
                <option value="Iceland">Iceland</option>
                <option value="India">India</option>
                <option value="Indonesia">Indonesia</option>
                <option value="Iran, Islamic Republic of">Iran, Islamic Republic of</option>
                <option value="Iraq">Iraq</option>
                <option value="Ireland">Ireland</option>
                <option value="Isle of Man">Isle of Man</option>
                <option value="Israel">Israel</option>
                <option value="Italy">Italy</option>
                <option value="Jamaica">Jamaica</option>
                <option value="Japan">Japan</option>
                <option value="Jersey">Jersey</option>
                <option value="Jordan">Jordan</option>
                <option value="Kazakhstan">Kazakhstan</option>
                <option value="Kenya">Kenya</option>
                <option value="Kiribati">Kiribati</option>
                <option value="Korea, Democratic People's Republic of">Korea, Democratic People's Republic of</option>
                <option value="Korea, Republic of">Korea, Republic of</option>
                <option value="Kosovo">Kosovo</option>
                <option value="Kuwait">Kuwait</option>
                <option value="Kyrgyzstan">Kyrgyzstan</option>
                <option value="Lao People's Democratic Republic">Lao People's Democratic Republic</option>
                <option value="Latvia">Latvia</option>
                <option value="Lebanon">Lebanon</option>
                <option value="Lesotho">Lesotho</option>
                <option value="Liberia">Liberia</option>
                <option value="Libyan Arab Jamahiriya">Libyan Arab Jamahiriya</option>
                <option value="Liechtenstein">Liechtenstein</option>
                <option value="Lithuania">Lithuania</option>
                <option value="Luxembourg">Luxembourg</option>
                <option value="Macao">Macao</option>
                <option value="Macedonia, the Former Yugoslav Republic of">Macedonia, the Former Yugoslav Republic of</option>
                <option value="Madagascar">Madagascar</option>
                <option value="Malawi">Malawi</option>
                <option value="Malaysia">Malaysia</option>
                <option value="Maldives">Maldives</option>
                <option value="Mali">Mali</option>
                <option value="Malta">Malta</option>
                <option value="Marshall Islands">Marshall Islands</option>
                <option value="Martinique">Martinique</option>
                <option value="Mauritania">Mauritania</option>
                <option value="Mauritius">Mauritius</option>
                <option value="Mayotte">Mayotte</option>
                <option value="Mexico">Mexico</option>
                <option value="Micronesia, Federated States of">Micronesia, Federated States of</option>
                <option value="Moldova, Republic of">Moldova, Republic of</option>
                <option value="Monaco">Monaco</option>
                <option value="Mongolia">Mongolia</option>
                <option value="Montenegro">Montenegro</option>
                <option value="Montserrat">Montserrat</option>
                <option value="Morocco">Morocco</option>
                <option value="Mozambique">Mozambique</option>
                <option value="Myanmar">Myanmar</option>
                <option value="Namibia">Namibia</option>
                <option value="Nauru">Nauru</option>
                <option value="Nepal">Nepal</option>
                <option value="Netherlands">Netherlands</option>
                <option value="Netherlands Antilles">Netherlands Antilles</option>
                <option value="New Caledonia">New Caledonia</option>
                <option value="New Zealand">New Zealand</option>
                <option value="Nicaragua">Nicaragua</option>
                <option value="Niger">Niger</option>
                <option value="Nigeria">Nigeria</option>
                <option value="Niue">Niue</option>
                <option value="Norfolk Island">Norfolk Island</option>
                <option value="Northern Mariana Islands">Northern Mariana Islands</option>
                <option value="Norway">Norway</option>
                <option value="Oman">Oman</option>
                <option value="Pakistan">Pakistan</option>
                <option value="Palau">Palau</option>
                <option value="Palestinian Territory, Occupied">Palestinian Territory, Occupied</option>
                <option value="Panama">Panama</option>
                <option value="Papua New Guinea">Papua New Guinea</option>
                <option value="Paraguay">Paraguay</option>
                <option value="Peru">Peru</option>
                <option value="Philippines">Philippines</option>
                <option value="Pitcairn">Pitcairn</option>
                <option value="Poland">Poland</option>
                <option value="Portugal">Portugal</option>
                <option value="Puerto Rico">Puerto Rico</option>
                <option value="Qatar">Qatar</option>
                <option value="Reunion">Reunion</option>
                <option value="Romania">Romania</option>
                <option value="Russian Federation">Russian Federation</option>
                <option value="Rwanda">Rwanda</option>
                <option value="Saint Barthelemy">Saint Barthelemy</option>
                <option value="Saint Helena">Saint Helena</option>
                <option value="Saint Kitts and Nevis">Saint Kitts and Nevis</option>
                <option value="Saint Lucia">Saint Lucia</option>
                <option value="Saint Martin">Saint Martin</option>
                <option value="Saint Pierre and Miquelon">Saint Pierre and Miquelon</option>
                <option value="Saint Vincent and the Grenadines">Saint Vincent and the Grenadines</option>
                <option value="Samoa">Samoa</option>
                <option value="San Marino">San Marino</option>
                <option value="Sao Tome and Principe">Sao Tome and Principe</option>
                <option value="Saudi Arabia">Saudi Arabia</option>
                <option value="Senegal">Senegal</option>
                <option value="Serbia">Serbia</option>
                <option value="Serbia and Montenegro">Serbia and Montenegro</option>
                <option value="Seychelles">Seychelles</option>
                <option value="Sierra Leone">Sierra Leone</option>
                <option value="Singapore">Singapore</option>
                <option value="Sint Maarten">Sint Maarten</option>
                <option value="Slovakia">Slovakia</option>
                <option value="Slovenia">Slovenia</option>
                <option value="Solomon Islands">Solomon Islands</option>
                <option value="Somalia">Somalia</option>
                <option value="South Africa">South Africa</option>
                <option value="South Georgia and the South Sandwich Islands">South Georgia and the South Sandwich Islands</option>
                <option value="South Sudan">South Sudan</option>
                <option value="Spain">Spain</option>
                <option value="Sri Lanka">Sri Lanka</option>
                <option value="Sudan">Sudan</option>
                <option value="Suriname">Suriname</option>
                <option value="Svalbard and Jan Mayen">Svalbard and Jan Mayen</option>
                <option value="Swaziland">Swaziland</option>
                <option value="Sweden">Sweden</option>
                <option value="Switzerland">Switzerland</option>
                <option value="Syrian Arab Republic">Syrian Arab Republic</option>
                <option value="Taiwan, Province of China">Taiwan, Province of China</option>
                <option value="Tajikistan">Tajikistan</option>
                <option value="Tanzania, United Republic of">Tanzania, United Republic of</option>
                <option value="Thailand">Thailand</option>
                <option value="Timor-Leste">Timor-Leste</option>
                <option value="Togo">Togo</option>
                <option value="Tokelau">Tokelau</option>
                <option value="Tonga">Tonga</option>
                <option value="Trinidad and Tobago">Trinidad and Tobago</option>
                <option value="Tunisia">Tunisia</option>
                <option value="Turkey">Turkey</option>
                <option value="Turkmenistan">Turkmenistan</option>
                <option value="Turks and Caicos Islands">Turks and Caicos Islands</option>
                <option value="Tuvalu">Tuvalu</option>
                <option value="Uganda">Uganda</option>
                <option value="Ukraine">Ukraine</option>
                <option value="United Arab Emirates">United Arab Emirates</option>
                <option value="United Kingdom">United Kingdom</option>
                <option value="United States">United States</option>
                <option value="United States Minor Outlying Islands">United States Minor Outlying Islands</option>
                <option value="Uruguay">Uruguay</option>
                <option value="Uzbekistan">Uzbekistan</option>
                <option value="Vanuatu">Vanuatu</option>
                <option value="Venezuela">Venezuela</option>
                <option value="Viet Nam">Viet Nam</option>
                <option value="Virgin Islands, British">Virgin Islands, British</option>
                <option value="Virgin Islands, U.s.">Virgin Islands, U.s.</option>
                <option value="Wallis and Futuna">Wallis and Futuna</option>
                <option value="Western Sahara">Western Sahara</option>
                <option value="Yemen">Yemen</option>
                <option value="Zambia">Zambia</option>
                <option value="Zimbabwe">Zimbabwe</option>
                </select>
                <p>Co-Author 5 Email</p>
                <input type="email" class="text" value="" name="coauth5email" aria-label="Co-Author 5 Email">
                </div>
				  	  <hr>
        
                <p>Profession </p>
                <select type="text" class="text" name="profession" value="" required>
                  <option></option>
                  <option value="Pharmacist">Pharmacist</option>
                  <option value="Physician">Physician</option>
                  <option value="Nurse">Nurse</option>
                  <option value="Other">Other</option>
                </select>
                <p>Category </p>
                <select type="text" class="text" name="category" value="Poster Competetion" required>
                  <option selected value="Poster Competetion">Poster Competetion</option>
                </select>
                <p>Poster Title </p>
                <input type="text" class="text" value="" name="postertitle" required>
                <p>Organization - University </p>
                <input type="text" class="text" value="" name="organization" required>
                <p>Password - (Create your own password and keep it for future login) </p>
                <input type="password" value="" name="password" required>
                <p>Mobile/Phone No. </p>
                <input type="text" value="" name="contact"  required>
                <hr />
               
	            <p>IP (Automatically Detected)</p>
				<input type="text" value="<?php echo getUserIP(); ?>" name="userip"  required readonly	 >


                <!--
								<p>

									<span>PLease Select Payment Type</span><br>

									<label for="chkYes">

									    <input type="radio" id="chkYes" name="chkPaymentType" onclick="ShowHideDiv()" required="" />

									    Paid by Organization Or Company

									</label><br>

									<label for="chkNo">

									    <input type="radio" id="chkNo" name="chkPaymentType" onclick="ShowHideDiv()" />

									    Self Payment ( Card or paypal )

									</label>

								</p>
-->

                <div id="dvPaymentType" style="display: block">
                  <p>University Name</p>
                  <input type="text" name="companyref" id="companyref" />
                </div>
                <div id="dvPaymentPaypal" style="display: none">
                  <p>* Plaese Make Payment<br>
                    * Copy Reference Number <br>
                    . Or <br>
                    * Fill with Registered Company Name into Requested Field</p>
                  <div id="smart-button-container">
                    <div style="text-align: center;">
                      <div id="paypal-button-container"></div>
                    </div>
                  </div>
                  <script src="https://www.paypal.com/sdk/js?client-id=AcFaEDQrIEflQi69flYQrw7QSirRAyXM8VeC0wBSO74PUEhzQCxFSWHFdKAZbLQZbze-17Li-r6yQyk2&currency=USD" data-sdk-integration-source="button-factory"></script>
                  <script>
										    function initPayPalButton() {
										      paypal.Buttons({
										        style: {
										          shape: 'rect',
										          color: 'black',
										          layout: 'vertical',
										          label: 'pay',

										        },

										        createOrder: function(data, actions) {
										          return actions.order.create({
										            purchase_units: [{"description":"Poster Competition","amount":{"currency_code":"USD","value":45}}]
										          });
										        },

										        onApprove: function(data, actions) {
										          return actions.order.capture().then(function(details) {
										            alert('Transaction completed by ' + details.payer.name.given_name + '!');
										          });
										        },

										        onError: function(err) {
										          console.log(err);
										        }
										      }).render('#paypal-button-container');
										    }
										    initPayPalButton();
										  </script>
                  <p>PayPal / Payment Reference Number After Payment Success</p>
                  <input type="text" class="text" value="" name="paypalref"  >
                </div>
                 <p id="abstractDrop" class="drop-zone" aria-label="Abstract upload area" tabindex="0">Drag & drop file here or click to select</p>
                <input type="file" id="abstractFile" name="abstract_file" accept=".jpg,.jpeg,.png,.gif,.pdf" style="display:none">
                <div class="upload-status" id="uploadStatus" aria-live="assertive" role="alert"></div>
                <progress id="uploadProgress" value="0" max="100" style="display:none;width:100%"></progress>
                <hr />
                <div class="sign-up">
                  <input type="reset" value="Reset">
                  <input type="submit" name="signup"  value="Sign Up" >
                  <div class="clear"> </div>
                </div>
              </form>
            </div>
          </div>
        </div>
        <div class="tab-2 resp-tab-content" aria-labelledby="tab_item-1">
          <div class="facts">
            <div class="login">
              <div class="buttons"> </div>
              <form name="login" action="" method="post">
                <input type="text" class="text" name="uemail" value="" placeholder="Enter your registered email"  >
                <a href="#" class=" icon email"></a>
                <input type="password" value="" name="password" placeholder="Enter valid password">
                <a href="#" class=" icon lock"></a>
                <div class="p-container">
                  <div class="submit two">
                    <input type="submit" name="login" value="LOG IN" >
                  </div>
                  <div class="clear"> </div>
                </div>
              </form>
            </div>
          </div>
        </div>
        <div class="tab-2 resp-tab-content" aria-labelledby="tab_item-1">
          <div class="facts">
            <div class="login">
              <div class="buttons"> </div>
              <form name="login" action="" method="post">
                <input type="text" class="text" name="femail" value="" placeholder="Enter your registered email" required  >
                <a href="#" class=" icon email"></a>
                <div class="submit three">
                  <input type="submit" name="send" onClick="myFunction()" value="Send Email" >
                </div>
              </form>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
</body>
<script>
$(function(){
  var dz = $('#abstractDrop');
  var fi = $('#abstractFile');
  var st = $('#uploadStatus');
  var pg = $('#uploadProgress');
  var locale = 'en';
  var messages = {
    en: {
      required: 'Abstract upload is required to complete pres signup',
      selectFile: 'Please select a file to upload',
      invalidType: 'Invalid file type',
      tooLarge: 'File too large',
      ready: 'Ready'
    }
  };
  function msg(key){ return (messages[locale] && messages[locale][key]) || key; }
  function vfile(f){
    if (!f) return 'No file selected';
    var ok = ['image/jpeg','image/png','image/gif','application/pdf'];
    if (ok.indexOf(f.type) === -1) return msg('invalidType');
    if (f.size > 5*1024*1024) return msg('tooLarge');
    return '';
  }
  function pick(){ fi.click(); }
  function showError(text){
    dz.addClass('error').removeClass('valid');
    st.text(text).css('color','#c62828');
    try { dz.css({'border-color':'#ff0000'}); } catch(e){}
    try{ dz[0].scrollIntoView({behavior:'smooth', block:'center'}); }catch(e){}
    var w = window.innerWidth;
    // Toast for tablet/desktop
    if (w >= 768 && w < 1200) {
      var t = $('<div class="toast-notice" role="alert" aria-live="assertive"></div>').text(text);
      $('body').append(t);
      setTimeout(function(){ t.fadeOut(300, function(){ t.remove(); }); }, 4000);
    }
    // Modal for large desktop
    if (w >= 1200) {
      var m = $('<div class="modal-notice" role="alertdialog" aria-modal="true"><div class="content"></div></div>');
      m.find('.content').text(text);
      $('body').append(m);
      m.fadeIn(150);
      setTimeout(function(){ m.fadeOut(300, function(){ m.remove(); }); }, 4000);
    }
  }
  function clearError(){
    dz.removeClass('error');
    try { dz.css({'border-color':''}); } catch(e){}
    st.text('').css('color','');
    $('.toast-notice').remove();
    $('.modal-notice').remove();
  }
  dz.on('click keypress', function(e){ if (e.type==='click' || e.key==='Enter' || e.key===' ') { pick(); } });
  dz.on('dragenter dragover', function(e){ e.preventDefault(); e.stopPropagation(); dz.addClass('dragover'); });
  dz.on('dragleave drop', function(e){ e.preventDefault(); e.stopPropagation(); dz.removeClass('dragover'); });
  dz.on('drop', function(e){
    var files = e.originalEvent.dataTransfer.files;
    if (!files || !files[0]) return;
    var f = files[0];
    var err = vfile(f);
    if (err) { showError(err); fi.val(''); return; }
    var dt = new DataTransfer();
    dt.items.add(f);
    fi[0].files = dt.files;
    clearError();
    dz.addClass('valid');
    st.text(msg('ready') + ': ' + f.name + ' (' + Math.round(f.size/1024) + ' KB)').css('color','#2e7d32');
    var reader = new FileReader();
    pg.show(); pg.val(0);
    reader.onprogress = function(ev){ if (ev.lengthComputable) { pg.val(Math.round(ev.loaded/ev.total*100)); } };
    reader.onloadend = function(){ setTimeout(function(){ pg.hide(); }, 300); };
    reader.readAsArrayBuffer(f);
  });
  fi.on('change', function(){
    var f = this.files[0];
    if (!f) return;
    var err = vfile(f);
    if (err) { showError(err); fi.val(''); return; }
    clearError();
    dz.addClass('valid');
    st.text(msg('ready') + ': ' + f.name + ' (' + Math.round(f.size/1024) + ' KB)').css('color','#2e7d32');
  });
  var s = $('select[name="coauthors_count"]');
  function u(){
    var n = parseInt(s.val() || 0);
    for (var i = 1; i <= 5; i++) {
      var show = i <= n;
      $('#coauthor-' + i).toggle(show);
      $('input[name="coauth' + i + 'name"]').prop('required', show);
      $('select[name="coauth' + i + 'nationality"]').prop('required', show);
      $('input[name="coauth' + i + 'email"]').prop('required', show);
    }
  }
  s.on('change', u);
  u();
  $('form[name="registration"]').on('submit', function(e){
    var sv = s.val();
    if (!sv) { alert('Please select number of Co-Authors'); e.preventDefault(); return false; }
    var n = parseInt(sv || 0);
    for (var i = 1; i <= n; i++) {
      var name = $.trim($('input[name="coauth' + i + 'name"]').val());
      var nat = $('select[name="coauth' + i + 'nationality"]').val();
      var em = $.trim($('input[name="coauth' + i + 'email"]').val());
      var re = /^[^@\s]+@[^@\s]+\.[^@\s]+$/;
      if (!name || !nat) {
        alert('Please fill all visible co-author fields');
        e.preventDefault();
        return false;
      }
      if (!re.test(em)) {
        alert('Please enter a valid email for CO-' + i);
        e.preventDefault();
        return false;
      }
    }
    var f = fi[0].files[0];
    if (!f) {
      showError(msg('selectFile'));
      try {
        $.post('', { abstract_event: 'missing', email: $('input[name="email"]').val() });
      } catch(e){}
      e.preventDefault();
      return false;
    }
    return true;
  });
});
</script>
<script>
(function(){
  function findLabel(el){
    var p = el.previousElementSibling;
    while (p && !(p.tagName && (p.tagName.toLowerCase()==='p' || p.tagName.toLowerCase()==='label'))) { p = p.previousElementSibling; }
    return p;
  }
  function apply(el){
    if (!el.required) return;
    el.setAttribute('aria-required','true');
    var lab = findLabel(el);
    if (!lab) return;
    lab.classList.add('required-label');
    var star = lab.querySelector('.req-star');
    if (!star) {
      star = document.createElement('span');
      star.className = 'req-star';
      star.setAttribute('aria-hidden','true');
      star.textContent = '*';
      lab.appendChild(star);
    }
    function check(){
      var v = el.checkValidity();
      el.setAttribute('aria-invalid', v ? 'false' : 'true');
      if (v) { star.classList.add('hidden'); } else { star.classList.remove('hidden'); }
    }
    var t;
    function deb(){
      if (t) clearTimeout(t);
      t = setTimeout(check, 350);
    }
    el.addEventListener('input', deb);
    el.addEventListener('change', deb);
    el.addEventListener('blur', check);
    check();
  }
  function scan(form){
    var ctrls = form.querySelectorAll('input, select, textarea');
    ctrls.forEach(function(el){
      apply(el);
    });
    var mo = new MutationObserver(function(mut){
      mut.forEach(function(m){
        if (m.type==='attributes' && m.attributeName==='required') apply(m.target);
      });
    });
    ctrls.forEach(function(el){
      mo.observe(el, { attributes:true, attributeFilter:['required'] });
    });
  }
  document.querySelectorAll('form').forEach(scan);
})();
</script>
</html>
