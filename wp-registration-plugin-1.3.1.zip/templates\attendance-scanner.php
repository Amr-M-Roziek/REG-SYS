<?php if (!defined('ABSPATH')) { exit; } ?>
<div class="wrp-attendance-scanner">
    <h2>QR Code Attendance Scanner</h2>
    
    <div class="wrp-scanner-controls">
        <button id="wrp-start-scanner" class="wrp-btn">Start Scanner</button>
        <button id="wrp-stop-scanner" class="wrp-btn" style="display:none;">Stop Scanner</button>
        
        <div class="wrp-scan-mode">
            <label>
                <input type="radio" name="scan_mode" value="check_in" checked> Check In
            </label>
            <label>
                <input type="radio" name="scan_mode" value="check_out"> Check Out
            </label>
        </div>
    </div>

    <div id="wrp-qr-reader" style="display:none; margin: 20px 0;"></div>
    
    <div id="wrp-scan-result" class="wrp-messages" style="display:none;"></div>
    
    <div class="wrp-recent-scans">
        <h3>Recent Scans</h3>
        <div id="wrp-recent-list"></div>
    </div>

    <div class="wrp-manual-entry">
        <h3>Manual Entry</h3>
        <form id="wrp-manual-scan-form">
            <div class="wrp-field">
                <label>Enter Unique ID:</label>
                <input type="text" id="wrp-manual-id" placeholder="e.g., 2025-000001" />
            </div>
            <button type="submit" class="wrp-btn">Submit</button>
        </form>
    </div>
</div>

<style>
.wrp-attendance-scanner {
    max-width: 800px;
    margin: 0 auto;
    padding: 20px;
}

.wrp-scanner-controls {
    margin: 20px 0;
    text-align: center;
}

.wrp-scan-mode {
    margin-top: 15px;
}

.wrp-scan-mode label {
    margin: 0 15px;
    font-size: 16px;
}

#wrp-qr-reader {
    border: 2px solid #cbd5e1;
    border-radius: 8px;
    overflow: hidden;
}

.wrp-recent-scans {
    margin-top: 30px;
}

#wrp-recent-list {
    background: #f8fafc;
    border: 1px solid #e2e8f0;
    border-radius: 6px;
    padding: 15px;
    min-height: 100px;
}

.wrp-scan-item {
    padding: 10px;
    margin: 5px 0;
    background: white;
    border-left: 4px solid #22c55e;
    border-radius: 4px;
}

.wrp-scan-item.error {
    border-left-color: #ef4444;
}

.wrp-manual-entry {
    margin-top: 30px;
    padding: 20px;
    background: #f1f5f9;
    border-radius: 8px;
}
</style>
