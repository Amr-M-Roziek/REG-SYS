# Simple Registration Form (WRP)

A lightweight WordPress plugin that provides a front-end user registration form via shortcode.

- Shortcode: `[wrp_registration_form]`
- Settings: default role, auto login, admin/user email notifications, success message

## Installation

1. Copy the `wp-registration-plugin` folder into `wp-content/plugins/`.
2. In WordPress Admin, go to `Plugins` and activate "Simple Registration Form (WRP)".
3. Go to `Settings -> Registration Form` to configure options.
4. (Optional) Use `WRP Builder` in the admin menu to drag-and-drop fields, then click `Save Form`.
5. Create a page (e.g., `Register`) and add the shortcode `[wrp_registration_form]`.
5. Publish the page.
6. To display a logged-in user’s QR, add `\[wrp_user_qr]` to any page.
7. To let users edit their profile, add `\[wrp_edit_profile]` to a page.
8. To provide a logout button, add `\[wrp_logout]` to a page.
9. To let users delete their account, add `\[wrp_delete_account]` to a page.
10. To show a combined options panel, add `\[wrp_account_options]` to a page.

## Features

- Drag-and-drop builder (Username, Email, First/Last Name, Password + Confirm)
- Additional fields: Text box, Country dropdown, Radio (Yes/No), Checkbox
- Validation, nonce, honeypot spam prevention
- Assigns default role from settings
- Optional auto-login after registration
- Optional email notifications to admin and user
- Assigns a unique ID starting with the current year (e.g., `2025-000001`)
- Generates a QR code for each user; display via success view or `\[wrp_user_qr]`
- Front-end profile edit form via `\[wrp_edit_profile]` (email, names, password)
- Front-end logout button via `\[wrp_logout]`
- Front-end delete account via `\[wrp_delete_account]` (password confirmation; soft delete for regular users, hard delete only if the role permits `delete_users`)
- Combined “Account Options” panel via `\[wrp_account_options]`
 - Builder style options: Light/Dark/Glass themes, multiple accent colors (blue/green/red/purple/orange), rounded/square corners

## Accessing the Builder

- Correct URL: `wp-admin/admin.php?page=wrp-form-builder`
- Do not use `wp-admin/wrp-form-builder` — this path is not a valid WordPress admin endpoint and will 404 at the web server level.
- From the WordPress admin, the “Builder” submenu under the `WRP` menu automatically points to the correct URL.

### Permanent Fix for Legacy Links (Optional)

If any external links or bookmarks point to `wp-admin/wrp-form-builder`, add a web‑server redirect to the correct admin URL:

- Apache (`.htaccess`):
  - `RewriteEngine On`
  - `RewriteRule ^wp-admin/wrp-form-builder$ wp-admin/admin.php?page=wrp-form-builder [QSA,L]`

- Nginx:
  - `location = /wp-admin/wrp-form-builder { return 301 /wp-admin/admin.php?page=wrp-form-builder; }`

This preserves older links and ensures users land on the Builder reliably.

### Troubleshooting 404s

- Verify the plugin is activated (`Plugins → Simple Registration Form (WRP)`).
- Use the admin menu `WRP → Builder` or the exact URL `wp-admin/admin.php?page=wrp-form-builder`.
- Ensure the current user has `manage_options` capability (Administrators by default). Insufficient permissions show an access error, not a 404.
- Check server logs for any direct requests to `/wp-admin/wrp-form-builder` (access/error logs) and update links to the correct path.


## Deletion & Privacy Settings

- Roles allowed hard delete: select which roles can permanently delete their accounts.
- Anonymize on soft delete: when enabled, the plugin replaces user email with a unique placeholder (`deleted+USERID@domain`) and clears names and bio, sets display name (configurable, default "Deleted User").
- Placeholder email domain: base placeholder used to construct unique emails, e.g., `deleted@example.invalid`.

Notes:
- Administrator deletion is blocked unless the Administrator role is explicitly allowed in the “Roles allowed hard delete” list.
- Soft delete also notifies the site admin via email.

## Notes

- Use strong passwords and consider enabling additional spam protection (e.g., reCAPTCHA) if needed.
- For advanced drag-and-drop form building, consider WPForms, Formidable Forms, RegistrationMagic, or similar plugins.

### Builder Field Notes
- Country dropdown includes a standard country list.
- Radio defaults to Yes/No; Checkbox is a single toggle.
- Values for added fields are stored in user meta (e.g., `wrp_text_1`, `wrp_country_1`, `wrp_radio_1`, `wrp_checkbox_1`).

### Builder Style Options
- In `WRP Builder`, set Theme (Light/Dark/Glass), Accent (Blue/Green/Red/Purple/Orange), and Corners (Rounded/Square).
- Styles apply to the front-end registration form via theme and accent classes with CSS variables in `assets/style.css`.

## Updates

- Automatic update checks can be enabled in `Settings → Registration Form → Updates`.
- Set the `Update manifest URL` to a JSON endpoint you host (default: `http://reg-sys.com/Plugins/SimpleRegistration/latest.json`).
- Expected manifest JSON:
  - `{ "version": "1.0.2", "download_url": "http://reg-sys.com/Plugins/SimpleRegistration/wp-registration-plugin-1.0.2.zip", "requires": "5.0", "tested": "6.6", "changelog": "Add automatic update checker and update settings; provide manifest support for plugin details modal; improve slug matching." }`
- When a newer `version` is detected, WordPress will show an update for this plugin in the Plugins screen and update via the `download_url` ZIP.
 
## Requirements

- PHP: 7.4 – 8.2 tested and supported. The plugin prevents activation on older PHP versions and shows an admin notice if the environment is unsupported.
- WordPress: Tested on WordPress 5.0 – 6.6.

## Testing & CI

- PHP unit tests cover non-WordPress components (download signature generation, release channel classification) and run across PHP 7.4, 8.0, 8.1, and 8.2.
- Linting: All PHP files are syntax-checked (`php -l`) in the CI matrix.
- CI: See `.github/workflows/php-matrix.yml` for the multi-version pipeline.

## Changelog

- 1.3.1
  - 🐛 FIX: Removed duplicate code in find_page_with_shortcode and find_qr_profile_page functions
  - 🐛 FIX: Centralized utility functions in main plugin class for better maintainability
  - 🔧 Improved code structure and eliminated redundancy across classes

- 1.3.0
  - ✨ NEW: Added Mobile Number field with numbers-only validation
  - ✨ NEW: Added Organization text field
  - ✨ NEW: Added Profession dropdown field with admin management
  - ✨ NEW: Manage Professions admin page for editing dropdown options
  - ✨ NEW: Numbers-only input validation for mobile fields
  - ✨ Enhanced form builder with new field types in palette
  - ✨ Updated default form configuration with new field examples
  - 🎨 Improved preview functionality for new field types
  - 🔧 Backend processing and validation for new field types

- 1.2.1
  - ✨ NEW: Placeholder text support for all form fields
  - ✨ Edit field modal now includes placeholder input
  - ✨ Preview shows placeholder text in form fields
  - ✨ Default form config updated with placeholder examples
  - 🎨 Enhanced form builder UX with placeholder help text
  - 🐛 Fixed missing placeholder support in form rendering

- 1.2.0
  - ✨ NEW: Front-end Form Builder with drag-and-drop interface
  - ✨ NEW: `[wrp_form_builder]` shortcode for accessible form editing
  - ✨ Auto-creates "Form Builder" page on plugin activation
  - 🎨 Beautiful 3-panel interface: Field Library, Canvas, Styling
  - ⚡ Real-time form configuration with AJAX save
  - 🔒 Administrator-only access with login redirect
  - 📱 Fully responsive mobile-friendly builder
  - 🎯 Visual drag-and-drop field management
  - ✏️ Inline field editing with modal interface
  - 💾 Auto-save configuration to database
  - 🎨 Live theme, accent, and style customization

- 1.1.1
  - 🔒 Improved Form Builder access control
  - ✨ Added login redirect for unauthenticated users accessing Builder
  - ✨ Added clear error message for non-admin users
  - 🎨 Better user experience with informative access denied page
  - 🐛 Fixed blank page issue when accessing Builder without permissions

- 1.1.0
  - ✨ NEW: Complete QR code-based attendance tracking system
  - ✨ NEW: Camera-based QR scanner for check-in/check-out
  - ✨ NEW: Admin attendance dashboard with daily list, reports, and analytics
  - ✨ NEW: Manual attendance entry for offline scenarios
  - ✨ NEW: User attendance history and statistics
  - ✨ NEW: CSV export functionality for attendance data
  - ✨ NEW: IP address tracking and audit trail
  - ✨ NEW: Three new shortcodes: [wrp_scan_qr], [wrp_my_attendance], [wrp_attendance_stats]
  - 🐛 Fixed email notification variable references in registration
  - 📊 New database table: wp_wrp_attendance
  - 🔒 Enhanced security with capability checks and nonce verification
  - 📱 Mobile-responsive attendance interface
  - 🎨 New admin menu: WRP → Attendance

- 1.0.3
  - Enhance PHP compatibility (7.4–8.2) with activation guard and admin notice for unsupported environments.
  - Add CI pipeline running lint and unit tests across PHP 7.4, 8.0, 8.1, and 8.2.
  - Extract docs site library and add unit tests for signed URLs and release classification.
  - Update documentation for requirements and testing.

- 1.0.2
  - Add automatic update checker and update settings.
  - Provide manifest support for plugin details modal; improve slug matching.
  - Include `docs/latest.json` and `docs/latest-1.0.2.json` for hosting updates.

- 1.0.1
  - Version bump and exported `wp-registration-plugin-1.0.1.zip`.

- 1.0.0
  - Initial public release with builder fields and style themes.
  - Includes admin users page and printable badges.