<?php
if (!defined('ABSPATH')) {
    exit;
}

/**
 * WRP Attendance System
 * Handles QR-based check-in/check-out and attendance tracking
 */
class WRP_Attendance
{
    private static $instance;
    private $table_name;

    public static function instance()
    {
        if (!self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    private function __construct()
    {
        global $wpdb;
        $this->table_name = $wpdb->prefix . 'wrp_attendance';
        
        // Hooks
        add_action('admin_menu', [$this, 'add_menu']);
        add_action('wp_enqueue_scripts', [$this, 'register_assets']);
        add_action('admin_enqueue_scripts', [$this, 'register_admin_assets']);
        
        // Shortcodes
        add_shortcode('wrp_scan_qr', [$this, 'render_scan_shortcode']);
        add_shortcode('wrp_my_attendance', [$this, 'render_my_attendance_shortcode']);
        add_shortcode('wrp_attendance_stats', [$this, 'render_stats_shortcode']);
        
        // AJAX handlers
        add_action('wp_ajax_wrp_check_in', [$this, 'ajax_check_in']);
        add_action('wp_ajax_nopriv_wrp_check_in', [$this, 'ajax_check_in']);
        add_action('wp_ajax_wrp_manual_attendance', [$this, 'ajax_manual_attendance']);
        add_action('wp_ajax_wrp_export_attendance', [$this, 'ajax_export_attendance']);
    }

    /**
     * Create attendance table on plugin activation
     */
    public static function create_table()
    {
        global $wpdb;
        $table_name = $wpdb->prefix . 'wrp_attendance';
        $charset_collate = $wpdb->get_charset_collate();

        $sql = "CREATE TABLE IF NOT EXISTS $table_name (
            id bigint(20) NOT NULL AUTO_INCREMENT,
            user_id bigint(20) NOT NULL,
            unique_id varchar(50) NOT NULL,
            check_in datetime NOT NULL,
            check_out datetime DEFAULT NULL,
            status varchar(20) DEFAULT 'present',
            notes text DEFAULT NULL,
            location varchar(255) DEFAULT NULL,
            ip_address varchar(45) DEFAULT NULL,
            created_by bigint(20) DEFAULT NULL,
            created_at datetime DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY  (id),
            KEY user_id (user_id),
            KEY unique_id (unique_id),
            KEY check_in (check_in),
            KEY status (status)
        ) $charset_collate;";

        require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
        dbDelta($sql);
    }

    public function register_assets()
    {
        wp_register_style('wrp-attendance-style', WRP_PLUGIN_URL . 'assets/attendance.css', ['wrp-style'], WRP_PLUGIN_VERSION);
        wp_register_script('wrp-qr-scanner', WRP_PLUGIN_URL . 'assets/html5-qrcode.min.js', [], '2.3.8', true);
        wp_register_script('wrp-attendance-script', WRP_PLUGIN_URL . 'assets/attendance.js', ['jquery', 'wrp-qr-scanner'], WRP_PLUGIN_VERSION, true);
        
        wp_localize_script('wrp-attendance-script', 'WRP_ATTENDANCE', [
            'ajax_url' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('wrp_attendance_nonce'),
        ]);
    }

    public function register_admin_assets($hook)
    {
        if (strpos($hook, 'wrp-attendance') === false) {
            return;
        }
        wp_enqueue_style('wrp-admin-style', WRP_PLUGIN_URL . 'assets/admin.css', [], WRP_PLUGIN_VERSION);
        wp_enqueue_script('wrp-attendance-admin', WRP_PLUGIN_URL . 'assets/attendance-admin.js', ['jquery'], WRP_PLUGIN_VERSION, true);
        wp_localize_script('wrp-attendance-admin', 'WRP_ATTENDANCE_ADMIN', [
            'ajax_url' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('wrp_attendance_nonce'),
        ]);
    }

    public function add_menu()
    {
        add_submenu_page(
            'wrp',
            'Attendance',
            'Attendance',
            'manage_options',
            'wrp-attendance',
            [$this, 'render_attendance_page']
        );
    }

    /**
     * QR Scanner Shortcode
     */
    public function render_scan_shortcode($atts = [])
    {
        if (!current_user_can('edit_users')) {
            return '<div class="wrp-error">You do not have permission to scan attendance.</div>';
        }

        wp_enqueue_style('wrp-attendance-style');
        wp_enqueue_script('wrp-attendance-script');

        ob_start();
        include WRP_PLUGIN_DIR . 'templates/attendance-scanner.php';
        return ob_get_clean();
    }

    /**
     * My Attendance Shortcode
     */
    public function render_my_attendance_shortcode($atts = [])
    {
        if (!is_user_logged_in()) {
            return '<div class="wrp-error">Please log in to view your attendance.</div>';
        }

        wp_enqueue_style('wrp-attendance-style');
        
        $user = wp_get_current_user();
        $records = $this->get_user_attendance($user->ID);

        ob_start();
        include WRP_PLUGIN_DIR . 'templates/my-attendance.php';
        return ob_get_clean();
    }

    /**
     * Attendance Stats Shortcode
     */
    public function render_stats_shortcode($atts = [])
    {
        if (!is_user_logged_in()) {
            return '<div class="wrp-error">Please log in to view statistics.</div>';
        }

        wp_enqueue_style('wrp-attendance-style');
        
        $user = wp_get_current_user();
        $stats = $this->get_user_stats($user->ID);

        ob_start();
        ?>
        <div class="wrp-attendance-stats">
            <h3>Your Attendance Statistics</h3>
            <div class="wrp-stats-grid">
                <div class="wrp-stat-card">
                    <div class="wrp-stat-value"><?php echo esc_html($stats['total_days']); ?></div>
                    <div class="wrp-stat-label">Total Days</div>
                </div>
                <div class="wrp-stat-card">
                    <div class="wrp-stat-value"><?php echo esc_html($stats['present_days']); ?></div>
                    <div class="wrp-stat-label">Present</div>
                </div>
                <div class="wrp-stat-card">
                    <div class="wrp-stat-value"><?php echo esc_html($stats['absent_days']); ?></div>
                    <div class="wrp-stat-label">Absent</div>
                </div>
                <div class="wrp-stat-card">
                    <div class="wrp-stat-value"><?php echo esc_html($stats['attendance_rate']); ?>%</div>
                    <div class="wrp-stat-label">Attendance Rate</div>
                </div>
            </div>
        </div>
        <?php
        return ob_get_clean();
    }

    /**
     * AJAX: Check-in/Check-out
     */
    public function ajax_check_in()
    {
        check_ajax_referer('wrp_attendance_nonce', 'nonce');

        $unique_id = isset($_POST['unique_id']) ? sanitize_text_field($_POST['unique_id']) : '';
        $action_type = isset($_POST['action_type']) ? sanitize_text_field($_POST['action_type']) : 'check_in';

        if (empty($unique_id)) {
            wp_send_json_error(['message' => 'Invalid QR code']);
        }

        // Find user by unique ID
        $users = get_users([
            'meta_key' => 'wrp_unique_id',
            'meta_value' => $unique_id,
            'number' => 1,
        ]);

        if (empty($users)) {
            wp_send_json_error(['message' => 'User not found']);
        }

        $user = $users[0];
        global $wpdb;

        if ($action_type === 'check_in') {
            // Check if already checked in today
            $today = current_time('Y-m-d');
            $existing = $wpdb->get_row($wpdb->prepare(
                "SELECT * FROM {$this->table_name} WHERE user_id = %d AND DATE(check_in) = %s AND check_out IS NULL",
                $user->ID,
                $today
            ));

            if ($existing) {
                wp_send_json_error(['message' => 'Already checked in today']);
            }

            // Insert check-in record
            $result = $wpdb->insert(
                $this->table_name,
                [
                    'user_id' => $user->ID,
                    'unique_id' => $unique_id,
                    'check_in' => current_time('mysql'),
                    'status' => 'present',
                    'ip_address' => $this->get_client_ip(),
                    'created_by' => get_current_user_id(),
                ],
                ['%d', '%s', '%s', '%s', '%s', '%d']
            );

            if ($result) {
                wp_send_json_success([
                    'message' => 'Check-in successful',
                    'user' => $user->display_name,
                    'time' => current_time('H:i:s'),
                ]);
            }
        } else {
            // Check-out
            $record = $wpdb->get_row($wpdb->prepare(
                "SELECT * FROM {$this->table_name} WHERE user_id = %d AND DATE(check_in) = %s AND check_out IS NULL ORDER BY id DESC LIMIT 1",
                $user->ID,
                current_time('Y-m-d')
            ));

            if (!$record) {
                wp_send_json_error(['message' => 'No active check-in found']);
            }

            $result = $wpdb->update(
                $this->table_name,
                ['check_out' => current_time('mysql')],
                ['id' => $record->id],
                ['%s'],
                ['%d']
            );

            if ($result !== false) {
                wp_send_json_success([
                    'message' => 'Check-out successful',
                    'user' => $user->display_name,
                    'time' => current_time('H:i:s'),
                ]);
            }
        }

        wp_send_json_error(['message' => 'Database error']);
    }

    /**
     * AJAX: Manual attendance entry
     */
    public function ajax_manual_attendance()
    {
        check_ajax_referer('wrp_attendance_nonce', 'nonce');

        if (!current_user_can('edit_users')) {
            wp_send_json_error(['message' => 'Permission denied']);
        }

        $user_id = isset($_POST['user_id']) ? (int)$_POST['user_id'] : 0;
        $date = isset($_POST['date']) ? sanitize_text_field($_POST['date']) : '';
        $status = isset($_POST['status']) ? sanitize_text_field($_POST['status']) : 'present';
        $notes = isset($_POST['notes']) ? sanitize_textarea_field($_POST['notes']) : '';

        if (!$user_id || !$date) {
            wp_send_json_error(['message' => 'Invalid data']);
        }

        $user = get_user_by('id', $user_id);
        if (!$user) {
            wp_send_json_error(['message' => 'User not found']);
        }

        $unique_id = get_user_meta($user_id, 'wrp_unique_id', true);

        global $wpdb;
        $result = $wpdb->insert(
            $this->table_name,
            [
                'user_id' => $user_id,
                'unique_id' => $unique_id,
                'check_in' => $date . ' 09:00:00',
                'check_out' => $status === 'present' ? $date . ' 17:00:00' : null,
                'status' => $status,
                'notes' => $notes,
                'created_by' => get_current_user_id(),
            ],
            ['%d', '%s', '%s', '%s', '%s', '%s', '%d']
        );

        if ($result) {
            wp_send_json_success(['message' => 'Attendance recorded']);
        }

        wp_send_json_error(['message' => 'Database error']);
    }

    /**
     * Admin attendance page
     */
    public function render_attendance_page()
    {
        if (!current_user_can('manage_options')) {
            return;
        }

        $view = isset($_GET['view']) ? sanitize_text_field($_GET['view']) : 'list';

        switch ($view) {
            case 'report':
                $this->render_report_view();
                break;
            case 'manual':
                $this->render_manual_entry();
                break;
            default:
                $this->render_list_view();
                break;
        }
    }

    private function render_list_view()
    {
        $date_filter = isset($_GET['date']) ? sanitize_text_field($_GET['date']) : current_time('Y-m-d');
        $user_filter = isset($_GET['user_id']) ? (int)$_GET['user_id'] : 0;

        global $wpdb;
        $query = "SELECT a.*, u.display_name, u.user_email FROM {$this->table_name} a 
                  LEFT JOIN {$wpdb->users} u ON a.user_id = u.ID 
                  WHERE DATE(a.check_in) = %s";
        $params = [$date_filter];

        if ($user_filter) {
            $query .= " AND a.user_id = %d";
            $params[] = $user_filter;
        }

        $query .= " ORDER BY a.check_in DESC";
        $records = $wpdb->get_results($wpdb->prepare($query, $params));

        include WRP_PLUGIN_DIR . 'templates/admin-attendance-list.php';
    }

    private function render_report_view()
    {
        $start_date = isset($_GET['start_date']) ? sanitize_text_field($_GET['start_date']) : date('Y-m-01');
        $end_date = isset($_GET['end_date']) ? sanitize_text_field($_GET['end_date']) : date('Y-m-d');

        $stats = $this->get_attendance_report($start_date, $end_date);

        include WRP_PLUGIN_DIR . 'templates/admin-attendance-report.php';
    }

    private function render_manual_entry()
    {
        $users = get_users(['orderby' => 'display_name', 'order' => 'ASC']);
        include WRP_PLUGIN_DIR . 'templates/admin-attendance-manual.php';
    }

    /**
     * Get user attendance records
     */
    private function get_user_attendance($user_id, $limit = 30)
    {
        global $wpdb;
        return $wpdb->get_results($wpdb->prepare(
            "SELECT * FROM {$this->table_name} WHERE user_id = %d ORDER BY check_in DESC LIMIT %d",
            $user_id,
            $limit
        ));
    }

    /**
     * Get user statistics
     */
    private function get_user_stats($user_id)
    {
        global $wpdb;
        
        $total = $wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(DISTINCT DATE(check_in)) FROM {$this->table_name} WHERE user_id = %d",
            $user_id
        ));

        $present = $wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(*) FROM {$this->table_name} WHERE user_id = %d AND status = 'present'",
            $user_id
        ));

        $absent = $wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(*) FROM {$this->table_name} WHERE user_id = %d AND status = 'absent'",
            $user_id
        ));

        $rate = $total > 0 ? round(($present / $total) * 100, 1) : 0;

        return [
            'total_days' => (int)$total,
            'present_days' => (int)$present,
            'absent_days' => (int)$absent,
            'attendance_rate' => $rate,
        ];
    }

    /**
     * Get attendance report
     */
    private function get_attendance_report($start_date, $end_date)
    {
        global $wpdb;
        
        $total_records = $wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(*) FROM {$this->table_name} WHERE DATE(check_in) BETWEEN %s AND %s",
            $start_date,
            $end_date
        ));

        $unique_users = $wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(DISTINCT user_id) FROM {$this->table_name} WHERE DATE(check_in) BETWEEN %s AND %s",
            $start_date,
            $end_date
        ));

        $by_status = $wpdb->get_results($wpdb->prepare(
            "SELECT status, COUNT(*) as count FROM {$this->table_name} 
             WHERE DATE(check_in) BETWEEN %s AND %s 
             GROUP BY status",
            $start_date,
            $end_date
        ), OBJECT_K);

        $daily_stats = $wpdb->get_results($wpdb->prepare(
            "SELECT DATE(check_in) as date, COUNT(*) as count 
             FROM {$this->table_name} 
             WHERE DATE(check_in) BETWEEN %s AND %s 
             GROUP BY DATE(check_in) 
             ORDER BY date DESC",
            $start_date,
            $end_date
        ));

        return [
            'total_records' => $total_records,
            'unique_users' => $unique_users,
            'by_status' => $by_status,
            'daily_stats' => $daily_stats,
        ];
    }

    /**
     * Get client IP address
     */
    private function get_client_ip()
    {
        $ip = '';
        if (!empty($_SERVER['HTTP_CLIENT_IP'])) {
            $ip = $_SERVER['HTTP_CLIENT_IP'];
        } elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
            $ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
        } else {
            $ip = $_SERVER['REMOTE_ADDR'];
        }
        return sanitize_text_field($ip);
    }

    /**
     * AJAX: Export attendance
     */
    public function ajax_export_attendance()
    {
        check_ajax_referer('wrp_attendance_nonce', 'nonce');

        if (!current_user_can('manage_options')) {
            wp_send_json_error(['message' => 'Permission denied']);
        }

        $start_date = isset($_POST['start_date']) ? sanitize_text_field($_POST['start_date']) : '';
        $end_date = isset($_POST['end_date']) ? sanitize_text_field($_POST['end_date']) : '';

        global $wpdb;
        $records = $wpdb->get_results($wpdb->prepare(
            "SELECT a.*, u.display_name, u.user_email 
             FROM {$this->table_name} a 
             LEFT JOIN {$wpdb->users} u ON a.user_id = u.ID 
             WHERE DATE(a.check_in) BETWEEN %s AND %s 
             ORDER BY a.check_in DESC",
            $start_date,
            $end_date
        ));

        // Generate CSV
        $filename = 'attendance_' . $start_date . '_to_' . $end_date . '.csv';
        
        header('Content-Type: text/csv; charset=utf-8');
        header('Content-Disposition: attachment; filename=' . $filename);
        
        $output = fopen('php://output', 'w');
        fputcsv($output, ['ID', 'User', 'Email', 'Unique ID', 'Check In', 'Check Out', 'Status', 'Notes']);
        
        foreach ($records as $record) {
            fputcsv($output, [
                $record->id,
                $record->display_name,
                $record->user_email,
                $record->unique_id,
                $record->check_in,
                $record->check_out,
                $record->status,
                $record->notes,
            ]);
        }
        
        fclose($output);
        exit;
    }
}
