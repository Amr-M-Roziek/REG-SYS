<?php
// SimpleRegistration index site configuration

return [
    'brand' => [
        'name' => 'Reg-Sys',
        'primary' => '#0b5fff',
        'secondary' => '#111827',
        'accent' => '#14b8a6',
        'font_family' => "system-ui, -apple-system, Segoe UI, Roboto, Ubuntu, 'Helvetica Neue', Arial, 'Noto Sans', 'Apple Color Emoji', 'Segoe UI Emoji', 'Segoe UI Symbol'",
    ],
    'security' => [
        'enable_https_redirect' => true,
        'hsts_seconds' => 31536000,
        'csp' => "default-src 'self'; style-src 'self' 'unsafe-inline' https://fonts.googleapis.com; font-src https://fonts.gstatic.com; script-src 'self' 'unsafe-inline'; img-src 'self' data:",
        'referrer_policy' => 'no-referrer-when-downgrade',
        'download_token_ttl' => 600, // seconds
        'download_secret' => 'change-this-secret-to-a-long-random-string',
        'rate_limit_per_hour' => 50,
    ],
    'cache' => [
        'versions_ttl' => 60, // seconds
    ],
    'paths' => [
        'data' => __DIR__ . '/data',
        'downloads_dir' => __DIR__ . '/../..', // adjust to directory where zips are stored on server
    ],
];
?>