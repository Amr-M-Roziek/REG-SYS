(function($) {
    'use strict';

    let currentConfig = [];
    let editingField = null;

    $(document).ready(function() {
        initBuilder();
        loadSavedConfig();
        bindEvents();
    });

    function initBuilder() {
        // Set theme, accent, and style from localized data
        $('#wrp-theme-select').val(WRP_FRONTEND_BUILDER.theme);
        $('#wrp-accent-select').val(WRP_FRONTEND_BUILDER.accent);
        $('#wrp-style-select').val(WRP_FRONTEND_BUILDER.style);
    }

    function loadSavedConfig() {
        currentConfig = WRP_FRONTEND_BUILDER.config || [];
        renderCanvas();
    }

    function renderCanvas() {
        const canvas = $('#wrp-frontend-canvas');
        canvas.empty();

        if (currentConfig.length === 0) {
            canvas.append('<p class="canvas-placeholder">Drag fields here to build your form</p>');
            return;
        }

        currentConfig.forEach((field, index) => {
            const fieldEl = createFieldElement(field, index);
            canvas.append(fieldEl);
        });

        makeSortable();
    }

    function createFieldElement(field, index) {
        const required = field.required ? '<span class="field-required-badge">Required</span>' : '';
        const label = field.label || ucFirst(field.type.replace(/_/g, ' '));
        
        return $(`
            <div class="wrp-canvas-field" data-index="${index}" draggable="true">
                <div class="field-header">
                    <div class="field-info">
                        <span class="field-type-badge">${field.type}</span>
                        ${required}
                    </div>
                    <div class="field-actions">
                        <button class="field-action-btn edit-field" title="Edit">✏️</button>
                        <button class="field-action-btn delete-field" title="Delete">🗑️</button>
                    </div>
                </div>
                <div class="field-label-text">${label}</div>
            </div>
        `);
    }

    function ucFirst(str) {
        return str.charAt(0).toUpperCase() + str.slice(1);
    }

    function bindEvents() {
        // Drag from palette
        $('.wrp-palette-item').on('dragstart', function(e) {
            e.originalEvent.dataTransfer.effectAllowed = 'copy';
            e.originalEvent.dataTransfer.setData('text/plain', $(this).data('type'));
        });

        // Canvas drop area
        const canvas = $('#wrp-frontend-canvas');
        
        canvas.on('dragover', function(e) {
            e.preventDefault();
            e.originalEvent.dataTransfer.dropEffect = 'copy';
            $(this).addClass('drag-over');
        });

        canvas.on('dragleave', function(e) {
            $(this).removeClass('drag-over');
        });

        canvas.on('drop', function(e) {
            e.preventDefault();
            $(this).removeClass('drag-over');
            
            const type = e.originalEvent.dataTransfer.getData('text/plain');
            if (type) {
                addField(type);
            }
        });

        // Edit field
        $(document).on('click', '.edit-field', function(e) {
            e.stopPropagation();
            const index = $(this).closest('.wrp-canvas-field').data('index');
            openEditModal(index);
        });

        // Delete field
        $(document).on('click', '.delete-field', function(e) {
            e.stopPropagation();
            const index = $(this).closest('.wrp-canvas-field').data('index');
            deleteField(index);
        });

        // Save builder
        $('#wrp-save-builder').on('click', saveBuilder);

        // Preview form
        $('#wrp-preview-form').on('click', function() {
            showPreview();
        });

        // Modal actions
        $('.wrp-modal-close, #cancel-field-edit').on('click', closeEditModal);
        $('#save-field-edit').on('click', saveFieldEdit);
        
        // Numbers-only input for mobile fields in preview
        $(document).on('input', 'input[type="tel"]', function() {
            this.value = this.value.replace(/[^0-9]/g, '');
        });
    }

    function addField(type) {
        const newField = {
            type: type,
            label: ucFirst(type.replace(/_/g, ' ')),
            placeholder: '',
            required: false
        };
        currentConfig.push(newField);
        renderCanvas();
    }

    function deleteField(index) {
        if (confirm('Are you sure you want to delete this field?')) {
            currentConfig.splice(index, 1);
            renderCanvas();
        }
    }

    function makeSortable() {
        const canvas = $('#wrp-frontend-canvas');
        let draggedIndex = null;

        $('.wrp-canvas-field').on('dragstart', function(e) {
            draggedIndex = $(this).data('index');
            $(this).addClass('dragging');
            e.originalEvent.dataTransfer.effectAllowed = 'move';
        });

        $('.wrp-canvas-field').on('dragend', function(e) {
            $(this).removeClass('dragging');
        });

        $('.wrp-canvas-field').on('dragover', function(e) {
            e.preventDefault();
            e.originalEvent.dataTransfer.dropEffect = 'move';
            
            const targetIndex = $(this).data('index');
            if (draggedIndex !== null && draggedIndex !== targetIndex) {
                const draggedItem = currentConfig[draggedIndex];
                currentConfig.splice(draggedIndex, 1);
                currentConfig.splice(targetIndex, 0, draggedItem);
                draggedIndex = targetIndex;
                renderCanvas();
            }
        });
    }

    function openEditModal(index) {
        editingField = index;
        const field = currentConfig[index];
        
        $('#field-label').val(field.label);
        $('#field-placeholder').val(field.placeholder || '');
        $('#field-required').prop('checked', field.required);
        $('#wrp-edit-modal').fadeIn(200);
    }

    function closeEditModal() {
        $('#wrp-edit-modal').fadeOut(200);
        editingField = null;
    }

    function saveFieldEdit() {
        if (editingField !== null) {
            currentConfig[editingField].label = $('#field-label').val();
            currentConfig[editingField].placeholder = $('#field-placeholder').val();
            currentConfig[editingField].required = $('#field-required').is(':checked');
            renderCanvas();
            closeEditModal();
        }
    }

    function saveBuilder() {
        const theme = $('#wrp-theme-select').val();
        const accent = $('#wrp-accent-select').val();
        const style = $('#wrp-style-select').val();

        const data = {
            action: 'wrp_save_frontend_builder',
            nonce: WRP_FRONTEND_BUILDER.nonce,
            wrp_config: JSON.stringify(currentConfig),
            wrp_theme: theme,
            wrp_accent: accent,
            wrp_style: style
        };

        const btn = $('#wrp-save-builder');
        const status = $('#wrp-save-status');
        
        btn.prop('disabled', true).text('💾 Saving...');
        status.text('');

        $.post(WRP_FRONTEND_BUILDER.ajaxurl, data, function(response) {
            btn.prop('disabled', false).text('💾 Save Form');
            
            if (response.success) {
                status.text('✅ ' + response.data.message).css('color', '#10b981');
                setTimeout(function() {
                    status.fadeOut(function() {
                        $(this).text('').show();
                    });
                }, 3000);
            } else {
                status.text('❌ ' + (response.data.message || 'Save failed')).css('color', '#ef4444');
            }
        }).fail(function() {
            btn.prop('disabled', false).text('💾 Save Form');
            status.text('❌ Network error').css('color', '#ef4444');
        });
    }

    function showPreview() {
        if (currentConfig.length === 0) {
            alert('Please add some fields to your form before previewing.');
            return;
        }

        const theme = $('#wrp-theme-select').val();
        const accent = $('#wrp-accent-select').val();
        const style = $('#wrp-style-select').val();

        // Build preview HTML
        let previewHTML = `
            <div class="wrp-preview-container" data-theme="${theme}" data-accent="${accent}" data-style="${style}">
                <div class="wrp-form-wrapper">
                    <h2>Registration Form Preview</h2>
                    <form class="wrp-form" autocomplete="off">
        `;

        let textCount = 0, countryCount = 0, radioCount = 0, checkboxCount = 0;

        currentConfig.forEach((field) => {
            const required = field.required ? ' <span style="color:#ef4444;">*</span>' : '';
            const requiredAttr = field.required ? ' required' : '';
            const label = field.label || ucFirst(field.type.replace(/_/g, ' '));
            const placeholder = field.placeholder || '';

            previewHTML += '<div class="wrp-field">';
            previewHTML += `<label>${label}${required}</label>`;

            switch(field.type) {
                case 'username':
                    previewHTML += `<input type="text" name="wrp_username" placeholder="${placeholder || 'Enter username'}"${requiredAttr} />`;
                    break;
                case 'email':
                    previewHTML += `<input type="email" name="wrp_email" placeholder="${placeholder || 'Enter email'}"${requiredAttr} />`;
                    break;
                case 'password':
                    previewHTML += `<input type="password" name="wrp_password" placeholder="${placeholder || 'Enter password'}"${requiredAttr} />`;
                    break;
                case 'password_confirm':
                    previewHTML += `<input type="password" name="wrp_password2" placeholder="${placeholder || 'Confirm password'}"${requiredAttr} />`;
                    break;
                case 'first_name':
                    previewHTML += `<input type="text" name="wrp_first_name" placeholder="${placeholder || 'Enter first name'}"${requiredAttr} />`;
                    break;
                case 'last_name':
                    previewHTML += `<input type="text" name="wrp_last_name" placeholder="${placeholder || 'Enter last name'}"${requiredAttr} />`;
                    break;
                case 'text':
                    textCount++;
                    previewHTML += `<input type="text" name="wrp_text_${textCount}" placeholder="${placeholder || 'Enter text'}"${requiredAttr} />`;
                    break;
                case 'mobile':
                    textCount++;
                    previewHTML += `<input type="tel" name="wrp_mobile_${textCount}" placeholder="${placeholder || 'Enter mobile number'}"${requiredAttr} />`;
                    break;
                case 'organization':
                    textCount++;
                    previewHTML += `<input type="text" name="wrp_organization_${textCount}" placeholder="${placeholder || 'Enter organization'}"${requiredAttr} />`;
                    break;
                case 'profession':
                    textCount++;
                    // Get profession options from localized data or use defaults
                    const professions = WRP_FRONTEND_BUILDER.professions || ['Doctor', 'Engineer', 'Teacher', 'Lawyer', 'Artist'];
                    previewHTML += `<select name="wrp_profession_${textCount}"${requiredAttr}>`;
                    previewHTML += `<option value="">${placeholder || 'Select profession...'}</option>`;
                    professions.forEach(prof => {
                        previewHTML += `<option value="${prof}">${prof}</option>`;
                    });
                    previewHTML += '</select>';
                    break;
                case 'country':
                    countryCount++;
                    previewHTML += `<select name="wrp_country_${countryCount}"${requiredAttr}>
                        <option value="">${placeholder || 'Select country...'}</option>
                        <option value="US">United States</option>
                        <option value="UK">United Kingdom</option>
                        <option value="CA">Canada</option>
                        <option value="AU">Australia</option>
                    </select>`;
                    break;
                case 'radio':
                    radioCount++;
                    previewHTML += `
                        <div class="wrp-radio-group">
                            <label><input type="radio" name="wrp_radio_${radioCount}" value="yes"${requiredAttr} /> Yes</label>
                            <label><input type="radio" name="wrp_radio_${radioCount}" value="no" /> No</label>
                        </div>`;
                    break;
                case 'checkbox':
                    checkboxCount++;
                    previewHTML += `<label><input type="checkbox" name="wrp_checkbox_${checkboxCount}" value="1"${requiredAttr} /> ${label}</label>`;
                    break;
            }

            previewHTML += '</div>';
        });

        previewHTML += `
                        <div class="wrp-actions">
                            <button type="button" class="wrp-btn" disabled>Register (Preview Only)</button>
                        </div>
                    </form>
                </div>
            </div>
        `;

        // Create and show preview modal
        const previewModal = $(`
            <div id="wrp-preview-modal" class="wrp-modal" style="display:block;">
                <div class="wrp-modal-content wrp-preview-modal-content">
                    <span class="wrp-modal-close">&times;</span>
                    <h3>📋 Form Preview</h3>
                    <div class="preview-info">
                        <p><strong>Theme:</strong> ${ucFirst(theme)} | <strong>Accent:</strong> ${ucFirst(accent)} | <strong>Style:</strong> ${ucFirst(style)}</p>
                    </div>
                    ${previewHTML}
                </div>
            </div>
        `);

        $('body').append(previewModal);

        // Close modal
        previewModal.find('.wrp-modal-close').on('click', function() {
            previewModal.fadeOut(200, function() {
                $(this).remove();
            });
        });

        // Click outside to close
        previewModal.on('click', function(e) {
            if ($(e.target).is('.wrp-modal')) {
                previewModal.fadeOut(200, function() {
                    $(this).remove();
                });
            }
        });
    }

})(jQuery);
