<?php
$config = require __DIR__ . '/config.php';
$statsFile = $config['paths']['data'] . '/stats.json';
header('Content-Type: application/json');
if (!file_exists($statsFile)) {
    echo json_encode(new stdClass());
    exit;
}
echo file_get_contents($statsFile);
?>