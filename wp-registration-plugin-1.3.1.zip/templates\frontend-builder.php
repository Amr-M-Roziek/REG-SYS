<?php
/**
 * Frontend Form Builder Template
 * Displays drag-and-drop form builder interface
 */
defined('ABSPATH') || exit;
?>

<div class="wrp-frontend-builder">
    <div class="wrp-builder-header">
        <h2>🎨 Form Builder</h2>
        <p class="description">Drag fields from the left panel to build your registration form. Click fields to edit labels and requirements.</p>
    </div>

    <div class="wrp-builder-container">
        <!-- Field Library Panel -->
        <div class="wrp-builder-panel wrp-palette-panel">
            <h3>📦 Field Library</h3>
            <div class="wrp-palette-items">
                <div class="wrp-palette-item" draggable="true" data-type="username">
                    <span class="field-icon">👤</span>
                    <span class="field-label">Username</span>
                </div>
                <div class="wrp-palette-item" draggable="true" data-type="email">
                    <span class="field-icon">📧</span>
                    <span class="field-label">Email</span>
                </div>
                <div class="wrp-palette-item" draggable="true" data-type="password">
                    <span class="field-icon">🔒</span>
                    <span class="field-label">Password</span>
                </div>
                <div class="wrp-palette-item" draggable="true" data-type="password_confirm">
                    <span class="field-icon">🔐</span>
                    <span class="field-label">Confirm Password</span>
                </div>
                <div class="wrp-palette-item" draggable="true" data-type="first_name">
                    <span class="field-icon">✍️</span>
                    <span class="field-label">First Name</span>
                </div>
                <div class="wrp-palette-item" draggable="true" data-type="last_name">
                    <span class="field-icon">✍️</span>
                    <span class="field-label">Last Name</span>
                </div>
                <div class="wrp-palette-item" draggable="true" data-type="text">
                    <span class="field-icon">📝</span>
                    <span class="field-label">Text Field</span>
                </div>
                <div class="wrp-palette-item" draggable="true" data-type="mobile">
                    <span class="field-icon">📱</span>
                    <span class="field-label">Mobile Number</span>
                </div>
                <div class="wrp-palette-item" draggable="true" data-type="organization">
                    <span class="field-icon">🏢</span>
                    <span class="field-label">Organization</span>
                </div>
                <div class="wrp-palette-item" draggable="true" data-type="profession">
                    <span class="field-icon">💼</span>
                    <span class="field-label">Profession</span>
                </div>
                <div class="wrp-palette-item" draggable="true" data-type="country">
                    <span class="field-icon">🌍</span>
                    <span class="field-label">Country</span>
                </div>
                <div class="wrp-palette-item" draggable="true" data-type="radio">
                    <span class="field-icon">⚪</span>
                    <span class="field-label">Radio Button</span>
                </div>
                <div class="wrp-palette-item" draggable="true" data-type="checkbox">
                    <span class="field-icon">☑️</span>
                    <span class="field-label">Checkbox</span>
                </div>
            </div>
        </div>

        <!-- Form Canvas Panel -->
        <div class="wrp-builder-panel wrp-canvas-panel">
            <h3>🎯 Form Canvas</h3>
            <div id="wrp-frontend-canvas" class="wrp-canvas-area">
                <p class="canvas-placeholder">Drag fields here to build your form</p>
            </div>
            <div class="wrp-builder-actions">
                <button id="wrp-save-builder" class="wrp-btn wrp-btn-primary">💾 Save Form</button>
                <button id="wrp-preview-form" class="wrp-btn wrp-btn-secondary">👁️ Preview</button>
                <span id="wrp-save-status" class="save-status"></span>
            </div>
        </div>

        <!-- Styling Panel -->
        <div class="wrp-builder-panel wrp-style-panel">
            <h3>🎨 Form Styles</h3>
            <div class="style-options">
                <div class="style-group">
                    <label for="wrp-theme-select">Theme</label>
                    <select id="wrp-theme-select">
                        <option value="light">Light</option>
                        <option value="dark">Dark</option>
                        <option value="glass">Glass</option>
                    </select>
                </div>
                <div class="style-group">
                    <label for="wrp-accent-select">Accent Color</label>
                    <select id="wrp-accent-select">
                        <option value="blue">Blue</option>
                        <option value="green">Green</option>
                        <option value="red">Red</option>
                        <option value="purple">Purple</option>
                        <option value="orange">Orange</option>
                    </select>
                </div>
                <div class="style-group">
                    <label for="wrp-style-select">Corners</label>
                    <select id="wrp-style-select">
                        <option value="rounded">Rounded</option>
                        <option value="square">Square</option>
                    </select>
                </div>
            </div>
            <div class="style-preview">
                <p class="description">These settings affect the appearance of your registration form on the front-end.</p>
            </div>
        </div>
    </div>

    <!-- Edit Field Modal -->
    <div id="wrp-edit-modal" class="wrp-modal" style="display:none;">
        <div class="wrp-modal-content">
            <span class="wrp-modal-close">&times;</span>
            <h3>Edit Field</h3>
            <div class="modal-body">
                <div class="form-group">
                    <label for="field-label">Field Label</label>
                    <input type="text" id="field-label" class="form-control" />
                </div>
                <div class="form-group">
                    <label for="field-placeholder">Placeholder Text</label>
                    <input type="text" id="field-placeholder" class="form-control" placeholder="Enter placeholder text..." />
                    <p class="field-help">Optional text shown inside the input field as a hint</p>
                </div>
                <div class="form-group">
                    <label>
                        <input type="checkbox" id="field-required" />
                        Required Field
                    </label>
                </div>
                <div class="modal-actions">
                    <button id="save-field-edit" class="wrp-btn wrp-btn-primary">Save Changes</button>
                    <button id="cancel-field-edit" class="wrp-btn wrp-btn-secondary">Cancel</button>
                </div>
            </div>
        </div>
    </div>
</div>
