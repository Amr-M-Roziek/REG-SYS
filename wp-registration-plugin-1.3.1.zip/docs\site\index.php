<?php
// SimpleRegistration downloads index

$config = require __DIR__ . '/config.php';
require_once __DIR__ . '/lib.php';

// Security headers and HTTPS enforcement
if ($config['security']['enable_https_redirect'] && (!isset($_SERVER['HTTPS']) || $_SERVER['HTTPS'] === 'off')) {
    $host = $_SERVER['HTTP_HOST'] ?? '';
    $uri = $_SERVER['REQUEST_URI'] ?? '/';
    header('Location: https://' . $host . $uri, true, 301);
    exit;
}
header('Strict-Transport-Security: max-age=' . (int)$config['security']['hsts_seconds']);
header('Content-Security-Policy: ' . $config['security']['csp']);
header('Referrer-Policy: ' . $config['security']['referrer_policy']);

// Load versions via library
$versions = sr_load_versions($config);

// Basic HTML
?><!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title><?php echo htmlspecialchars($config['brand']['name']); ?> Plugins – SimpleRegistration</title>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="assets/styles.css" />
</head>
<body>
  <header class="site-header">
    <div class="container">
      <h1>Simple Registration – Downloads</h1>
      <p>Browse all versions, verify checksums, and download securely.</p>
    </div>
  </header>
  <main class="container">
    <section class="controls">
      <div class="control-group">
        <label for="searchVersion">Version</label>
        <input id="searchVersion" type="text" placeholder="e.g., 1.0.2" />
      </div>
      <div class="control-group">
        <label for="dateFrom">From</label>
        <input id="dateFrom" type="date" />
      </div>
      <div class="control-group">
        <label for="dateTo">To</label>
        <input id="dateTo" type="date" />
      </div>
      <div class="control-group">
        <label for="sizeThreshold">Min size (MB)</label>
        <input id="sizeThreshold" type="number" min="0" step="0.01" />
      </div>
    </section>

    <section>
      <div id="versionList" class="version-list"></div>
    </section>
  </main>

  <footer class="site-footer container">
    <small>&copy; <?php echo date('Y'); ?> <?php echo htmlspecialchars($config['brand']['name']); ?>. All rights reserved.</small>
  </footer>

  <script>window.__SR_CONFIG__ = {
    brand: <?php echo json_encode($config['brand']); ?>,
  };</script>
  <script>window.__SR_VERSIONS__ = <?php echo json_encode($versions, JSON_UNESCAPED_SLASHES); ?>;</script>
  <script src="js/app.js"></script>
</body>
</html>
<?php
?>
