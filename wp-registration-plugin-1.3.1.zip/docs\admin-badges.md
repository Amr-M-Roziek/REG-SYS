# WRP Users Admin & Printable Badges

This plugin adds a dedicated admin page to manage users and print badges.

## Access

- Navigate to `WP Admin → WRP Users`.

## Capabilities

- Search users by login/email and filter by role.
- Edit user email, display name, first name, last name, role.
- View and edit each user's year-based unique ID.
- Automatically generate and persist a QR code for the unique ID.
- Open a print-optimized badge page per user.

## Badge Layout

- Includes site name, user display name, unique ID, and QR code.
- Print button triggers the browser print dialog.
- Print-specific stylesheet hides admin chrome and optimizes layout for cards.

## Notes

- If a user has no unique ID/QR, the page creates them on demand.
- The QR image is sourced from a public API (`api.qrserver.com`).