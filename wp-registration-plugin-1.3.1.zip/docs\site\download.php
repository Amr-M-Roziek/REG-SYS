<?php
$config = require __DIR__ . '/config.php';

// Validate signature
$v = $_GET['v'] ?? '';
$file = $_GET['file'] ?? '';
$exp = (int)($_GET['exp'] ?? 0);
$sig = $_GET['sig'] ?? '';

if (!$v || !$file || !$exp || !$sig) {
    http_response_code(400);
    echo 'Bad request';
    exit;
}
if ($exp < time()) {
    http_response_code(403);
    echo 'Link expired';
    exit;
}
$params = http_build_query(['v' => $v, 'file' => $file, 'exp' => $exp]);
$expected = hash_hmac('sha256', $params, $config['security']['download_secret']);
if (!hash_equals($expected, $sig)) {
    http_response_code(403);
    echo 'Invalid signature';
    exit;
}

// Rate limiting
$ip = $_SERVER['REMOTE_ADDR'] ?? 'unknown';
$rateKey = sha1('rate:' . $ip);
$dataDir = $config['paths']['data'];
if (!is_dir($dataDir)) @mkdir($dataDir, 0775, true);
$rateFile = $dataDir . '/rate_' . $rateKey . '.json';
$now = time();
$window = 3600; // 1 hour
$limit = (int)$config['security']['rate_limit_per_hour'];
$history = [];
if (file_exists($rateFile)) {
    $history = json_decode(file_get_contents($rateFile), true) ?: [];
}
// prune old entries
$history = array_values(array_filter($history, function($ts) use ($now, $window) { return ($now - (int)$ts) < $window; }));
if (count($history) >= $limit) {
    http_response_code(429);
    header('Retry-After: 3600');
    echo 'Rate limit exceeded';
    exit;
}
$history[] = $now;
file_put_contents($rateFile, json_encode($history));

// Resolve file and stream
$base = rtrim($config['paths']['downloads_dir'], '/\\');
$path = $base . DIRECTORY_SEPARATOR . $file;
if (!file_exists($path)) {
    http_response_code(404);
    echo 'File not found';
    exit;
}

// Update stats
$statsFile = $dataDir . '/stats.json';
$stats = file_exists($statsFile) ? json_decode(file_get_contents($statsFile), true) : [];
if (!isset($stats[$v])) $stats[$v] = ['downloads' => 0, 'last_download' => null];
$stats[$v]['downloads'] += 1;
$stats[$v]['last_download'] = date('c');
file_put_contents($statsFile, json_encode($stats));

// Stream file
header('Content-Type: application/zip');
header('Content-Disposition: attachment; filename="' . basename($path) . '"');
header('Content-Length: ' . filesize($path));
readfile($path);
exit;
?>