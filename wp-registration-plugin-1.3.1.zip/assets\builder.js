(function($){
  function defaultConfig(){
    return [
      {type:'username',label:'Username',required:true},
      {type:'email',label:'Email',required:true},
      {type:'password',label:'Password',required:true},
      {type:'password_confirm',label:'Confirm Password',required:true},
      {type:'first_name',label:'First Name',required:false},
      {type:'last_name',label:'Last Name',required:false}
    ];
  }

  function getConfig(){
    var cfg = (WRP_BUILDER && Array.isArray(WRP_BUILDER.config)) ? WRP_BUILDER.config : defaultConfig();
    return cfg;
  }

  function renderRow(field){
    var $row = $('<div class="wrp-field-row" draggable="true"></div>');
    $row.data('field', field);
    var $label = $('<input type="text" class="wrp-row-label" />').val(field.label);
    var $req = $('<label><input type="checkbox" class="wrp-row-required"/> Required</label>');
    $req.find('input').prop('checked', !!field.required);
    var $type = $('<span class="wrp-row-type"></span>').text('['+field.type+']');
    var $del = $('<button type="button" class="button">Remove</button>');
    var $actions = $('<div class="wrp-row-actions"></div>').append($type,$del);
    $row.append($label,$req,$actions);

    $label.on('input', function(){ field.label = $(this).val(); });
    $req.find('input').on('change', function(){ field.required = $(this).is(':checked'); });
    $del.on('click', function(){ $row.remove(); });

    // drag reorder support
    $row.on('dragstart', function(e){ e.originalEvent.dataTransfer.setData('text/plain','drag'); $(this).addClass('dragging'); });
    $row.on('dragend', function(){ $(this).removeClass('dragging'); });
    return $row;
  }

  function serialize(){
    var arr = [];
    $('#wrp-canvas-list .wrp-field-row').each(function(){
      var f = $(this).data('field');
      arr.push({type:f.type,label:f.label,required:!!f.required});
    });
    return arr;
  }

  function initDragAndDrop(){
    var $list = $('#wrp-canvas-list');
    $list.on('dragover', function(e){ e.preventDefault();
      var dragging = $('.wrp-field-row.dragging')[0];
      var after = getDragAfterElement($list[0], e.originalEvent.clientY);
      if(!after) $list[0].appendChild(dragging);
      else $list[0].insertBefore(dragging, after);
    });

    function getDragAfterElement(container, y){
      var els = [].slice.call(container.querySelectorAll('.wrp-field-row:not(.dragging)'));
      var closest = null, closestOffset = Number.NEGATIVE_INFINITY;
      els.forEach(function(el){
        var box = el.getBoundingClientRect();
        var offset = y - box.top - box.height/2;
        if(offset < 0 && offset > closestOffset){ closestOffset = offset; closest = el; }
      });
      return closest;
    }

    // Palette dragging
    $('.wrp-item').on('dragstart', function(e){
      e.originalEvent.dataTransfer.setData('text/plain', $(this).data('type'));
    });
    $list.on('drop', function(e){ e.preventDefault();
      var type = e.originalEvent.dataTransfer.getData('text/plain');
      if(!type) return;
      var defaultLabels = {
        username:'Username', email:'Email', password:'Password', password_confirm:'Confirm Password', first_name:'First Name', last_name:'Last Name',
        text:'Text', country:'Country', radio:'Radio', checkbox:'Checkbox'
      };
      var field = {type:type,label:defaultLabels[type]||type,required:false};
      var $row = renderRow(field);
      $list.append($row);
    });
  }

  function renderCanvas(){
    var $list = $('#wrp-canvas-list');
    $list.empty();
    getConfig().forEach(function(f){ $list.append(renderRow($.extend({}, f))); });
  }

  function bindSave(){
    $('#wrp-save').on('click', function(){
      var data = serialize();
      var $form = $('<form method="post" action="'+WRP_BUILDER.saveUrl+'"></form>');
      $form.append('<input type="hidden" name="wrp_builder_nonce_field" value="'+WRP_BUILDER.nonce+'" />');
      $form.append('<input type="hidden" name="wrp_config" />');
      // style options
      var theme = $('#wrp-theme-select').val() || WRP_BUILDER.theme || 'light';
      var accent = $('#wrp-accent-select').val() || WRP_BUILDER.accent || 'blue';
      var styleOpt = $('#wrp-style-select').val() || WRP_BUILDER.style || 'rounded';
      $form.append('<input type="hidden" name="wrp_theme" value="'+theme+'" />');
      $form.append('<input type="hidden" name="wrp_accent" value="'+accent+'" />');
      $form.append('<input type="hidden" name="wrp_style" value="'+styleOpt+'" />');
      $form.find('[name=wrp_config]').val(JSON.stringify(data));
      $('body').append($form);
      $form.trigger('submit');
    });
  }

  $(function(){
    renderCanvas();
    initDragAndDrop();
    bindSave();
    // init selects
    $('#wrp-theme-select').val(WRP_BUILDER.theme||'light');
    $('#wrp-accent-select').val(WRP_BUILDER.accent||'blue');
    $('#wrp-style-select').val(WRP_BUILDER.style||'rounded');
  });
})(jQuery);