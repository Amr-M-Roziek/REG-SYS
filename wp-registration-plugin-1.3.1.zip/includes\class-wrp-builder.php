<?php
if (!defined('ABSPATH')) { exit; }

class WRP_Builder {
    private static $instance;

    public static function instance() {
        if (!self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    private function __construct() {
        // Register the Builder as a submenu under the top-level WRP menu
        add_action('admin_menu', [$this, 'add_menu']);
        add_action('admin_enqueue_scripts', [$this, 'enqueue']);
        add_action('admin_post_wrp_save_builder', [$this, 'save_builder']);
    }

    public function add_menu() {
        // Add Builder as a submenu under the parent 'wrp' menu
        add_submenu_page(
            'wrp',
            'WRP Form Builder',
            'Builder',
            'manage_options',
            'wrp-form-builder',
            [$this, 'render_page']
        );
        
        // Add Professions management page
        add_submenu_page(
            'wrp',
            'WRP Manage Professions',
            'Manage Professions',
            'manage_options',
            'wrp-manage-professions',
            [$this, 'render_professions_page']
        );
    }

    public function enqueue($hook) {
        // Only enqueue Builder assets on our submenu screen
        if ($hook !== 'wrp_page_wrp-form-builder') { return; }
        wp_enqueue_style('wrp-builder-style', WRP_PLUGIN_URL . 'assets/builder.css', [], WRP_PLUGIN_VERSION);
        wp_enqueue_script('wrp-builder-script', WRP_PLUGIN_URL . 'assets/builder.js', ['jquery'], WRP_PLUGIN_VERSION, true);
        $config = get_option('wrp_form_config', []);
        $theme = get_option('wrp_form_theme', 'light');
        $accent = get_option('wrp_form_accent', 'blue');
        $styleOpt = get_option('wrp_form_style', 'rounded');
        wp_localize_script('wrp-builder-script', 'WRP_BUILDER', [
            'config' => is_array($config) ? $config : [],
            'nonce' => wp_create_nonce('wrp_builder_nonce'),
            'saveUrl' => admin_url('admin-post.php?action=wrp_save_builder'),
            'theme' => $theme,
            'accent' => $accent,
            'style' => $styleOpt,
        ]);
    }

    public function render_page() {
        if (!current_user_can('manage_options')) {
            if (!is_user_logged_in()) {
                // Redirect to login if not logged in
                auth_redirect();
            } else {
                // Show error message if logged in but not admin
                echo '<div class="wrap">';
                echo '<h1>Access Denied</h1>';
                echo '<div class="notice notice-error"><p><strong>Sorry, you do not have permission to access this page.</strong></p></div>';
                echo '<p>You need to be an Administrator to access the Form Builder.</p>';
                echo '<p><a href="' . esc_url(admin_url()) . '" class="button button-primary">Go to Dashboard</a></p>';
                echo '</div>';
            }
            return;
        }
        echo '<div class="wrap wrp-builder">';
        echo '<h1>WRP Drag-and-Drop Form Builder</h1>';
        echo '<p>Drag fields from the left into the form area on the right. Reorder by dragging. Click a field to edit its label and required flag.</p>';

        // Quick links to front-end pages
        $reg_id = WRP_Plugin::instance()->find_page_with_shortcode('wrp_registration_form');
        $acct_id = WRP_Plugin::instance()->find_page_with_shortcode('wrp_account_options');
        $qrp_id = WRP_Plugin::instance()->find_qr_profile_page();
        echo '<div class="notice notice-info" style="margin-top:12px;">';
        echo '<p><strong>Shortcuts:</strong> ';
        if ($reg_id) {
            $reg_view = get_permalink($reg_id);
            $reg_edit = admin_url('post.php?post=' . (int)$reg_id . '&action=edit');
            echo '<a class="button" href="' . esc_url($reg_view) . '" target="_blank">View Registration page</a> ';
            echo '<a class="button" href="' . esc_url($reg_edit) . '">Edit Registration page</a> ';
        } else {
            $create_url = wp_nonce_url(admin_url('admin-post.php?action=wrp_create_pages'), 'wrp_create_pages');
            echo '<span class="description">Registration page not found.</span> ';
            echo '<a class="button button-primary" href="' . esc_url($create_url) . '">Create required pages</a> ';
        }
        if ($acct_id) {
            $acct_view = get_permalink($acct_id);
            $acct_edit = admin_url('post.php?post=' . (int)$acct_id . '&action=edit');
            echo '<a class="button" href="' . esc_url($acct_view) . '" target="_blank">View Account page</a> ';
            echo '<a class="button" href="' . esc_url($acct_edit) . '">Edit Account page</a> ';
        }
        if ($qrp_id) {
            $qrp_view = get_permalink($qrp_id);
            $qrp_edit = admin_url('post.php?post=' . (int)$qrp_id . '&action=edit');
            echo '<a class="button" href="' . esc_url($qrp_view) . '" target="_blank">View QR & Profile page</a> ';
            echo '<a class="button" href="' . esc_url($qrp_edit) . '">Edit QR & Profile page</a> ';
        } else {
            $create_qrp = wp_nonce_url(admin_url('admin-post.php?action=wrp_create_qr_profile'), 'wrp_create_qr_profile');
            echo '<span class="description">QR & Profile page not found.</span> ';
            echo '<a class="button" href="' . esc_url($create_qrp) . '">Create QR & Profile page</a> ';
        }
        echo '</p></div>';

        echo '<div class="wrp-builder-columns">';
        echo '  <div class="wrp-palette">';
        echo '    <h2>Field Library</h2>';
        echo '    <div class="wrp-palette-items">';
        $items = [
            ['type' => 'username', 'label' => 'Username'],
            ['type' => 'email', 'label' => 'Email'],
            ['type' => 'password', 'label' => 'Password'],
            ['type' => 'password_confirm', 'label' => 'Confirm Password'],
            ['type' => 'first_name', 'label' => 'First Name'],
            ['type' => 'last_name', 'label' => 'Last Name'],
            ['type' => 'text', 'label' => 'Text'],
            ['type' => 'mobile', 'label' => 'Mobile Number'],
            ['type' => 'organization', 'label' => 'Organization'],
            ['type' => 'profession', 'label' => 'Profession'],
            ['type' => 'country', 'label' => 'Country'],
            ['type' => 'radio', 'label' => 'Radio'],
            ['type' => 'checkbox', 'label' => 'Checkbox'],
        ];
        foreach ($items as $i) {
            echo '<div class="wrp-item" draggable="true" data-type="' . esc_attr($i['type']) . '">' . esc_html($i['label']) . '</div>';
        }
        echo '    </div>';
        echo '  </div>';

        echo '  <div class="wrp-canvas">';
        echo '    <h2>Form Canvas</h2>';
        echo '    <div id="wrp-canvas-list" class="wrp-list" aria-label="Form fields"></div>';
        echo '    <div class="wrp-actions">';
        echo '      <button id="wrp-save" class="button button-primary">Save Form</button>';
        echo '    </div>';
        echo '  </div>';
        echo '  <div class="wrp-style-panel">';
        echo '    <h2>Form Styles</h2>';
        echo '    <table class="form-table"><tbody>';
        $theme = get_option('wrp_form_theme', 'light');
        $accent = get_option('wrp_form_accent', 'blue');
        $styleOpt = get_option('wrp_form_style', 'rounded');
        echo '      <tr><th>Theme</th><td>';
        echo '        <select id="wrp-theme-select">';
        foreach ([['light','Light'],['dark','Dark'],['glass','Glass']] as $t) {
            $sel = selected($theme, $t[0], false);
            echo '<option value="' . esc_attr($t[0]) . '" ' . $sel . '>' . esc_html($t[1]) . '</option>';
        }
        echo '        </select>';
        echo '      </td></tr>';
        echo '      <tr><th>Accent Color</th><td>';
        echo '        <select id="wrp-accent-select">';
        foreach ([['blue','Blue'],['green','Green'],['red','Red'],['purple','Purple'],['orange','Orange']] as $a) {
            $sel = selected($accent, $a[0], false);
            echo '<option value="' . esc_attr($a[0]) . '" ' . $sel . '>' . esc_html($a[1]) . '</option>';
        }
        echo '        </select>';
        echo '      </td></tr>';
        echo '      <tr><th>Corners</th><td>';
        echo '        <select id="wrp-style-select">';
        foreach ([['rounded','Rounded'],['square','Square']] as $s) {
            $sel = selected($styleOpt, $s[0], false);
            echo '<option value="' . esc_attr($s[0]) . '" ' . $sel . '>' . esc_html($s[1]) . '</option>';
        }
        echo '        </select>';
        echo '      </td></tr>';
        echo '    </tbody></table>';
        echo '    <p class="description">These options affect the front-end registration form appearance.</p>';
        echo '  </div>';
        echo '</div>';

        echo '</div>';
    }

    public function save_builder() {
        if (!current_user_can('manage_options')) {
            if (!is_user_logged_in()) {
                auth_redirect();
            } else {
                wp_die(
                    '<h1>Access Denied</h1><p>You do not have permission to save form settings.</p>',
                    'Unauthorized',
                    ['response' => 403, 'back_link' => true]
                );
            }
        }
        check_admin_referer('wrp_builder_nonce', 'wrp_builder_nonce_field');
        
        $payload = isset($_POST['wrp_config']) ? wp_unslash($_POST['wrp_config']) : '';
        $data = json_decode($payload, true);
        if (!is_array($data)) { $data = []; }
        
        $allowed = ['username','email','password','password_confirm','first_name','last_name','text','mobile','organization','profession','country','radio','checkbox'];
        $normalized = [];
        foreach ($data as $f) {
            if (!isset($f['type']) || !in_array($f['type'], $allowed, true)) { continue; }
            $normalized[] = [
                'type' => $f['type'],
                'label' => isset($f['label']) ? sanitize_text_field($f['label']) : ucfirst(str_replace('_',' ', $f['type'])),
                'placeholder' => isset($f['placeholder']) ? sanitize_text_field($f['placeholder']) : '',
                'required' => isset($f['required']) ? (bool)$f['required'] : false,
            ];
        }
        update_option('wrp_form_config', $normalized);
        
        // Save style options
        $theme = isset($_POST['wrp_theme']) ? sanitize_text_field($_POST['wrp_theme']) : 'light';
        $accent = isset($_POST['wrp_accent']) ? sanitize_text_field($_POST['wrp_accent']) : 'blue';
        $styleOpt = isset($_POST['wrp_style']) ? sanitize_text_field($_POST['wrp_style']) : 'rounded';
        if (!in_array($theme, ['light','dark','glass'], true)) { $theme = 'light'; }
        if (!in_array($accent, ['blue','green','red','purple','orange'], true)) { $accent = 'blue'; }
        if (!in_array($styleOpt, ['rounded','square'], true)) { $styleOpt = 'rounded'; }
        update_option('wrp_form_theme', $theme);
        update_option('wrp_form_accent', $accent);
        update_option('wrp_form_style', $styleOpt);
        
        // Redirect back with success message
        $redirect = admin_url('admin.php?page=wrp-form-builder&updated=true');
        wp_safe_redirect($redirect);
        exit;
    }

    public function render_professions_page() {
        if (!current_user_can('manage_options')) {
            wp_die('<h1>Access Denied</h1><p>You do not have permission to manage professions.</p>', 'Unauthorized', ['response' => 403]);
        }
        
        $professions = get_option('wrp_professions', ['Doctor', 'Engineer', 'Teacher', 'Lawyer', 'Artist']);
        if (!is_array($professions)) { $professions = []; }
        
        echo '<div class="wrap wrp-professions">';
        echo '<h1>Manage Professions</h1>';
        echo '<p>These options appear in the Profession dropdown field. Drag to reorder. Empty items will be removed.</p>';
        echo '<form method="post" action="">';
        echo wp_nonce_field('wrp_manage_professions', 'wrp_manage_professions_nonce', true, false);
        echo '<table class="form-table"><tbody id="wrp-professions-container">';
        echo '<tr><th>Profession</th><th>Actions</th></tr>';
        foreach ($professions as $i => $profession) {
            echo '<tr class="wrp-profession-row">';
            echo '<td><input type="text" name="professions[]" value="' . esc_attr($profession) . '" class="regular-text" /></td>';
            echo '<td><button type="button" class="button remove-profession">Remove</button></td>';
            echo '</tr>';
        }
        echo '</tbody></table>';
        echo '<p><button type="button" id="add-profession" class="button">Add Profession</button></p>';
        echo '<p class="submit"><button type="submit" class="button button-primary">Save Professions</button></p>';
        echo '</form>';
        echo '</div>';
        
        echo '<script>
        document.addEventListener("DOMContentLoaded", function() {
            document.getElementById("add-profession").addEventListener("click", function() {
                var container = document.getElementById("wrp-professions-container");
                var newRow = document.createElement("tr");
                newRow.className = "wrp-profession-row";
                newRow.innerHTML = \'<td><input type="text" name="professions[]" value="" class="regular-text" /></td><td><button type="button" class="button remove-profession">Remove</button></td>\';
                container.appendChild(newRow);
                newRow.querySelector(".remove-profession").addEventListener("click", function() {
                    container.removeChild(newRow);
                });
            });
            document.querySelectorAll(".remove-profession").forEach(function(button) {
                button.addEventListener("click", function() {
                    var row = this.closest(".wrp-profession-row");
                    row.parentNode.removeChild(row);
                });
            });
        });
        </script>';
    }
}