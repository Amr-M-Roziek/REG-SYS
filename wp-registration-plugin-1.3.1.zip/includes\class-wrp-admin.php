<?php
if (!defined('ABSPATH')) { exit; }

class WRP_Admin {
    private static $instance;

    public static function instance() {
        if (!self::$instance) { self::$instance = new self(); }
        return self::$instance;
    }

    private function __construct() {
        // Register admin menus and enqueue styles/scripts for specific screens
        add_action('admin_menu', [$this, 'add_menu']);
        add_action('admin_enqueue_scripts', [$this, 'enqueue']);
        // Admin Bar shortcut to Builder for admins
        add_action('admin_bar_menu', [$this, 'add_admin_bar_links'], 80);
        // Handler to create helper page combining QR & Profile
        add_action('admin_post_wrp_create_qr_profile', [$this, 'handle_create_qr_profile']);
    }

    public function add_menu() {
        // Top-level WRP menu (parent container for Users, Builder, Settings)
        add_menu_page(
            'WRP',            // Page title
            'WRP',            // Menu title
            'manage_options', // Capability
            'wrp',            // Top-level slug
            [$this, 'render_root_page'], // Callback: redirects to Users
            'dashicons-id',   // Icon
            81                // Position above Users and below default group
        );

        // Submenu: Users list and management
        add_submenu_page(
            'wrp',
            'WRP Users',      // Page title
            'Users',          // Menu label
            'manage_options',
            'wrp-users',
            [$this, 'render_users_page']
        );

        // Submenu: Settings page (reuses plugin settings renderer)
        add_submenu_page(
            'wrp',
            'Registration Settings',
            'Settings',
            'manage_options',
            'wrp-settings',
            [\WRP_Plugin::instance(), 'render_settings_page']
        );

        // Optional quick links to front-end pages (redirects)
        add_submenu_page(
            'wrp',
            'Open Registration Page',
            'Registration Page',
            'manage_options',
            'wrp-open-registration',
            [$this, 'redirect_to_registration_page']
        );
        add_submenu_page(
            'wrp',
            'Open Account Page',
            'Account Page',
            'manage_options',
            'wrp-open-account',
            [$this, 'redirect_to_account_page']
        );

        // Submenu: QR & Profile helper page (front-end)
        add_submenu_page(
            'wrp',
            'Open QR & Profile Page',
            'QR & Profile Page',
            'manage_options',
            'wrp-open-qr-profile',
            [$this, 'redirect_to_qr_profile_page']
        );
    }

    public function enqueue($hook) {
        // Enqueue styles only for our Users screen under WRP
        if ($hook === 'wrp_page_wrp-users') {
            // PHP 5.3-compatible dirname nesting
            $base_file = dirname(dirname(__FILE__)) . '/wp-registration-plugin.php';
            $base_url = plugin_dir_url($base_file);
            wp_enqueue_style('wrp-admin-style', $base_url . 'assets/admin.css', [], null);
            $view = isset($_GET['view']) ? sanitize_text_field($_GET['view']) : '';
            if ($view === 'badge') {
                wp_enqueue_style('wrp-badge-style', $base_url . 'assets/badge.css', [], null);
            }
        }
    }

    public function render_users_page() {
        if (!current_user_can('manage_options')) { return; }
        $view = isset($_GET['view']) ? sanitize_text_field($_GET['view']) : '';
        if ($view === 'edit') { $this->render_edit_user(); return; }
        if ($view === 'badge') { $this->render_badge_page(); return; }
        $this->render_list();
    }

    private function render_list() {
        $search = isset($_GET['s']) ? sanitize_text_field($_GET['s']) : '';
        $role = isset($_GET['role']) ? sanitize_text_field($_GET['role']) : '';
        $args = ['number' => 50, 'orderby' => 'registered', 'order' => 'DESC'];
        if ($search !== '') { $args['search'] = '*' . esc_attr($search) . '*'; $args['search_columns'] = ['user_login','user_email']; }
        if ($role !== '') { $args['role'] = $role; }
        $users = get_users($args);
        $roles = get_editable_roles();

        echo '<div class="wrap wrp-admin">';
        echo '<h1>WRP Users</h1>';
        echo '<form method="get" class="wrp-filter">';
        echo '<input type="hidden" name="page" value="wrp-users" />';
        echo '<input type="search" name="s" placeholder="Search login/email" value="' . esc_attr($search) . '" /> ';
        echo '<select name="role"><option value="">All Roles</option>';
        foreach ($roles as $key => $role_def) {
            $sel = selected($role, $key, false);
            echo '<option value="' . esc_attr($key) . '" ' . $sel . '>' . esc_html($role_def['name']) . '</option>';
        }
        echo '</select> ';
        echo '<button class="button">Filter</button>';
        echo '</form>';

        echo '<table class="wp-list-table widefat fixed striped">';
        echo '<thead><tr><th>User</th><th>Email</th><th>Role</th><th>Unique ID</th><th>Actions</th></tr></thead><tbody>';
        foreach ($users as $u) {
            $uid = get_user_meta($u->ID, 'wrp_unique_id', true);
            $edit_url = admin_url('admin.php?page=wrp-users&view=edit&user_id=' . (int)$u->ID);
            $badge_url = admin_url('admin.php?page=wrp-users&view=badge&user_id=' . (int)$u->ID);
            echo '<tr>';
            echo '<td>' . esc_html($u->display_name) . ' (ID ' . (int)$u->ID . ')</td>';
            echo '<td>' . esc_html($u->user_email) . '</td>';
            echo '<td>' . esc_html(implode(', ', (array)$u->roles)) . '</td>';
            echo '<td>' . esc_html($uid ?: '—') . '</td>';
            echo '<td><a class="button" href="' . esc_url($edit_url) . '">Edit</a> <a class="button" href="' . esc_url($badge_url) . '">Print Badge</a></td>';
            echo '</tr>';
        }
        echo '</tbody></table>';
        echo '</div>';
    }

    private function render_edit_user() {
        $user_id = isset($_GET['user_id']) ? (int) $_GET['user_id'] : 0;
        $user = $user_id ? get_user_by('id', $user_id) : null;
        if (!$user) { echo '<div class="wrap"><h2>User not found</h2></div>'; return; }

        $message = '';
        if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['wrp_admin_edit'])) {
            check_admin_referer('wrp_admin_edit_action', 'wrp_admin_edit_nonce');
            $email = isset($_POST['wrp_email']) ? sanitize_email($_POST['wrp_email']) : $user->user_email;
            $display_name = isset($_POST['wrp_display_name']) ? sanitize_text_field($_POST['wrp_display_name']) : $user->display_name;
            $first = isset($_POST['wrp_first_name']) ? sanitize_text_field($_POST['wrp_first_name']) : get_user_meta($user->ID, 'first_name', true);
            $last = isset($_POST['wrp_last_name']) ? sanitize_text_field($_POST['wrp_last_name']) : get_user_meta($user->ID, 'last_name', true);
            $role = isset($_POST['wrp_role']) ? sanitize_text_field($_POST['wrp_role']) : (is_array($user->roles) ? reset($user->roles) : 'subscriber');
            $unique_id = isset($_POST['wrp_unique_id']) ? sanitize_text_field($_POST['wrp_unique_id']) : get_user_meta($user->ID, 'wrp_unique_id', true);

            $update = ['ID' => $user->ID, 'user_email' => $email, 'display_name' => $display_name];
            $res = wp_update_user($update);
            if (!is_wp_error($res)) {
                update_user_meta($user->ID, 'first_name', $first);
                update_user_meta($user->ID, 'last_name', $last);
                if ($unique_id !== '') { update_user_meta($user->ID, 'wrp_unique_id', $unique_id); }
                if ($role && isset(get_editable_roles()[$role])) { $user->set_role($role); }
                // Regenerate QR if unique ID changed
                $qr_url = $this->build_qr_url($unique_id, 240);
                update_user_meta($user->ID, 'wrp_qr_url', $qr_url);
                $message = '<div class="notice notice-success"><p>Saved.</p></div>';
                $user = get_user_by('id', $user_id); // refresh
            } else {
                $message = '<div class="notice notice-error"><p>Save failed.</p></div>';
            }
        }

        $roles = get_editable_roles();
        $first = get_user_meta($user->ID, 'first_name', true);
        $last = get_user_meta($user->ID, 'last_name', true);
        $unique_id = get_user_meta($user->ID, 'wrp_unique_id', true);
        $qr_url = get_user_meta($user->ID, 'wrp_qr_url', true);
        if (!$unique_id || !$qr_url) { list($unique_id, $qr_url) = $this->ensure_user_id_and_qr($user->ID); }

        echo '<div class="wrap wrp-admin">';
        echo '<h1>Edit User #' . (int)$user->ID . '</h1>';
        echo $message;
        echo '<form method="post">';
        wp_nonce_field('wrp_admin_edit_action', 'wrp_admin_edit_nonce');
        echo '<input type="hidden" name="wrp_admin_edit" value="1" />';
        echo '<table class="form-table"><tbody>';
        echo '<tr><th>Login</th><td>' . esc_html($user->user_login) . '</td></tr>';
        echo '<tr><th>Email</th><td><input type="email" name="wrp_email" value="' . esc_attr($user->user_email) . '" class="regular-text" /></td></tr>';
        echo '<tr><th>Display Name</th><td><input type="text" name="wrp_display_name" value="' . esc_attr($user->display_name) . '" class="regular-text" /></td></tr>';
        echo '<tr><th>First Name</th><td><input type="text" name="wrp_first_name" value="' . esc_attr($first) . '" class="regular-text" /></td></tr>';
        echo '<tr><th>Last Name</th><td><input type="text" name="wrp_last_name" value="' . esc_attr($last) . '" class="regular-text" /></td></tr>';
        echo '<tr><th>Role</th><td><select name="wrp_role">';
        $current_role = is_array($user->roles) ? reset($user->roles) : '';
        foreach ($roles as $key => $role_def) {
            $sel = selected($current_role, $key, false);
            echo '<option value="' . esc_attr($key) . '" ' . $sel . '>' . esc_html($role_def['name']) . '</option>';
        }
        echo '</select></td></tr>';
        echo '<tr><th>Unique ID</th><td><input type="text" name="wrp_unique_id" value="' . esc_attr($unique_id) . '" class="regular-text" /> ';
        echo '<img src="' . esc_url($qr_url) . '" alt="QR" style="max-width:120px;height:auto;border:1px solid #cbd5e1;border-radius:6px;padding:4px;background:#fff;" /></td></tr>';
        echo '</tbody></table>';
        echo '<p class="submit"><button class="button button-primary">Save Changes</button> ';
        $badge_url = admin_url('admin.php?page=wrp-users&view=badge&user_id=' . (int)$user->ID);
        echo '<a class="button" href="' . esc_url($badge_url) . '">Print Badge</a></p>';
        echo '</form>';
        echo '</div>';
    }

    private function render_badge_page() {
        $user_id = isset($_GET['user_id']) ? (int) $_GET['user_id'] : 0;
        $user = $user_id ? get_user_by('id', $user_id) : null;
        if (!$user) { echo '<div class="wrap"><h2>User not found</h2></div>'; return; }
        list($unique_id, $qr_url) = $this->ensure_user_id_and_qr($user->ID);

        echo '<div class="wrap wrp-badge">';
        echo '<h1>Printable Badge</h1>';
        echo '<div class="wrp-badge-card">';
        echo '<div class="wrp-badge-header">' . esc_html(get_bloginfo('name')) . '</div>';
        echo '<div class="wrp-badge-body">';
        echo '<div class="wrp-badge-name">' . esc_html($user->display_name) . '</div>';
        echo '<div class="wrp-badge-id">' . esc_html($unique_id) . '</div>';
        echo '<div class="wrp-badge-qr"><img src="' . esc_url($qr_url) . '" alt="QR" /></div>';
        echo '</div>';
        echo '</div>';
        $edit_url = admin_url('admin.php?page=wrp-users&view=edit&user_id=' . (int)$user->ID);
        echo '<p><button class="button button-primary" onclick="window.print()">Print</button> ';
        echo '<a class="button" href="' . esc_url($edit_url) . '">Edit User</a> ';
        echo '<a class="button" href="' . esc_url(admin_url('admin.php?page=wrp-users')) . '">Back to list</a></p>';
        echo '</div>'; 
    }

    private function ensure_user_id_and_qr($user_id) {
        $unique_id = get_user_meta($user_id, 'wrp_unique_id', true);
        $qr_url = get_user_meta($user_id, 'wrp_qr_url', true);
        if (!$unique_id) { $unique_id = $this->generate_unique_id(); update_user_meta($user_id, 'wrp_unique_id', $unique_id); }
        if (!$qr_url) { $qr_url = $this->build_qr_url($unique_id, 240); update_user_meta($user_id, 'wrp_qr_url', $qr_url); }
        return [$unique_id, $qr_url];
    }

    private function generate_unique_id() {
        $year = date('Y');
        $seq_year = get_option('wrp_seq_year', '');
        $seq_val = (int) get_option('wrp_seq_value', 0);
        if ($seq_year !== $year) { $seq_year = $year; $seq_val = 0; }
        $seq_val++;
        update_option('wrp_seq_year', $seq_year);
        update_option('wrp_seq_value', $seq_val);
        return $seq_year . '-' . str_pad((string)$seq_val, 6, '0', STR_PAD_LEFT);
    }

    private function build_qr_url($data, $size = 200) {
        $size = max(100, min(600, (int)$size));
        $encoded = rawurlencode($data);
        return 'https://api.qrserver.com/v1/create-qr-code/?size=' . $size . 'x' . $size . '&data=' . $encoded;
    }

    // Root page: keep UX simple by redirecting to the Users list
    public function render_root_page() {
        if (!current_user_can('manage_options')) { return; }
        wp_safe_redirect(admin_url('admin.php?page=wrp-users'));
        exit;
    }

    // Add quick access to the WRP Builder in the Admin Bar
    public function add_admin_bar_links($wp_admin_bar) {
        if (!is_admin_bar_showing()) { return; }
        if (!current_user_can('manage_options')) { return; }
        $builder_url = admin_url('admin.php?page=wrp-form-builder');
        $wp_admin_bar->add_node([
            'id'    => 'wrp-builder',
            'title' => 'WRP Builder',
            'href'  => $builder_url,
            'meta'  => ['class' => 'wrp-adminbar-builder']
        ]);
    }

    public function redirect_to_registration_page() {
        if (!current_user_can('manage_options')) { return; }
        $id = WRP_Plugin::instance()->find_page_with_shortcode('wrp_registration_form');
        if ($id) {
            wp_safe_redirect(get_permalink($id));
        } else {
            wp_safe_redirect(admin_url('admin.php?page=wrp-form-builder&missing=registration'));
        }
        exit;
    }

    public function redirect_to_account_page() {
        if (!current_user_can('manage_options')) { return; }
        $id = WRP_Plugin::instance()->find_page_with_shortcode('wrp_account_options');
        if ($id) {
            wp_safe_redirect(get_permalink($id));
        } else {
            wp_safe_redirect(admin_url('admin.php?page=wrp-form-builder&missing=account'));
        }
        exit;
    }

    public function redirect_to_qr_profile_page() {
        if (!current_user_can('manage_options')) { return; }
        $id = WRP_Plugin::instance()->find_qr_profile_page();
        if ($id) {
            wp_safe_redirect(get_permalink($id));
            exit;
        }
        // Create the helper page with both shortcodes
        $create_url = wp_nonce_url(admin_url('admin-post.php?action=wrp_create_qr_profile'), 'wrp_create_qr_profile');
        wp_safe_redirect($create_url);
        exit;
    }

    public function handle_create_qr_profile() {
        if (!current_user_can('manage_options')) { wp_die('Unauthorized'); }
        check_admin_referer('wrp_create_qr_profile');
        $existing = WRP_Plugin::instance()->find_qr_profile_page();
        if ($existing) {
            wp_safe_redirect(get_permalink($existing));
            exit;
        }
        $post_id = wp_insert_post([
            'post_type' => 'page',
            'post_status' => 'publish',
            'post_title' => 'QR & Profile',
            'post_content' => "[wrp_user_qr]\n[wrp_edit_profile]",
        ]);
        if (is_wp_error($post_id) || !$post_id) {
            wp_safe_redirect(admin_url('edit.php?post_type=page'));
            exit;
        }
        wp_safe_redirect(get_permalink((int)$post_id));
        exit;
    }
}