# Server Redirects for WRP Builder

Some older links or bookmarks may point to `wp-admin/wrp-form-builder`, which is not a valid WordPress admin endpoint and will return a 404 at the web server level. The correct URL is:

`/wp-admin/admin.php?page=wrp-form-builder`

To permanently fix this and preserve backward compatibility, add a server-level redirect:

## Apache (.htaccess)

```
RewriteEngine On
RewriteRule ^wp-admin/wrp-form-builder$ wp-admin/admin.php?page=wrp-form-builder [QSA,L]
```

Place this rule in the site’s `.htaccess` (or the appropriate vhost config) within the WordPress host.

## Nginx

```
location = /wp-admin/wrp-form-builder {
  return 301 /wp-admin/admin.php?page=wrp-form-builder;
}
```

Add this block to your server configuration for the WordPress host and reload Nginx.

## Notes

- This redirect operates at the web server layer, ensuring requests to the wrong path are corrected before reaching PHP/WordPress.
- The WRP plugin already links to the correct URL internally; this redirect is for external references (docs, bookmarks, email links).
- Ensure caching/CDN layers respect or propagate the redirect.