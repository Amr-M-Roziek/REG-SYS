/**
 * WRP Attendance Scanner JavaScript
 * Handles QR code scanning and attendance processing
 */
(function($) {
    'use strict';

    let html5QrcodeScanner = null;
    let recentScans = [];

    $(document).ready(function() {
        initScanner();
        initManualEntry();
    });

    function initScanner() {
        const $startBtn = $('#wrp-start-scanner');
        const $stopBtn = $('#wrp-stop-scanner');
        const $reader = $('#wrp-qr-reader');

        $startBtn.on('click', function() {
            startScanning();
        });

        $stopBtn.on('click', function() {
            stopScanning();
        });
    }

    function startScanning() {
        const $reader = $('#wrp-qr-reader');
        $reader.show();
        $('#wrp-start-scanner').hide();
        $('#wrp-stop-scanner').show();

        html5QrcodeScanner = new Html5Qrcode("wrp-qr-reader");
        
        const config = {
            fps: 10,
            qrbox: { width: 250, height: 250 }
        };

        html5QrcodeScanner.start(
            { facingMode: "environment" },
            config,
            onScanSuccess,
            onScanFailure
        ).catch(err => {
            console.error('QR Scanner Error:', err);
            showResult('error', 'Failed to start scanner. Please check camera permissions.');
        });
    }

    function stopScanning() {
        if (html5QrcodeScanner) {
            html5QrcodeScanner.stop().then(() => {
                $('#wrp-qr-reader').hide();
                $('#wrp-start-scanner').show();
                $('#wrp-stop-scanner').hide();
            }).catch(err => {
                console.error('Stop scanner error:', err);
            });
        }
    }

    function onScanSuccess(decodedText, decodedResult) {
        // Process the scanned QR code
        processAttendance(decodedText);
        
        // Stop scanner briefly to prevent multiple scans
        stopScanning();
        setTimeout(() => {
            if ($('#wrp-stop-scanner').is(':visible')) {
                startScanning();
            }
        }, 2000);
    }

    function onScanFailure(error) {
        // Ignore scan failures (they happen frequently during scanning)
    }

    function processAttendance(uniqueId) {
        const actionType = $('input[name="scan_mode"]:checked').val();
        
        $.ajax({
            url: WRP_ATTENDANCE.ajax_url,
            type: 'POST',
            data: {
                action: 'wrp_check_in',
                nonce: WRP_ATTENDANCE.nonce,
                unique_id: uniqueId,
                action_type: actionType
            },
            success: function(response) {
                if (response.success) {
                    showResult('success', response.data.message + ' - ' + response.data.user + ' at ' + response.data.time);
                    addToRecentScans(response.data.user, actionType, 'success');
                } else {
                    showResult('error', response.data.message);
                    addToRecentScans(uniqueId, actionType, 'error');
                }
            },
            error: function() {
                showResult('error', 'Connection error. Please try again.');
            }
        });
    }

    function showResult(type, message) {
        const $result = $('#wrp-scan-result');
        const className = type === 'success' ? 'wrp-success' : 'wrp-error';
        
        $result.html('<div class="wrp-message ' + className + '">' + message + '</div>');
        $result.show();
        
        setTimeout(() => {
            $result.fadeOut();
        }, 5000);
    }

    function addToRecentScans(user, action, status) {
        const time = new Date().toLocaleTimeString();
        const $item = $('<div class="wrp-scan-item ' + (status === 'error' ? 'error' : '') + '">' +
            '<strong>' + user + '</strong> - ' + action.replace('_', ' ') + ' at ' + time +
            '</div>');
        
        $('#wrp-recent-list').prepend($item);
        
        // Keep only last 10 scans
        const $items = $('#wrp-recent-list .wrp-scan-item');
        if ($items.length > 10) {
            $items.last().remove();
        }
    }

    function initManualEntry() {
        $('#wrp-manual-scan-form').on('submit', function(e) {
            e.preventDefault();
            const uniqueId = $('#wrp-manual-id').val().trim();
            
            if (uniqueId) {
                processAttendance(uniqueId);
                $('#wrp-manual-id').val('');
            }
        });
    }

})(jQuery);
