<?php if (!defined('ABSPATH')) { exit; } ?>
<?php
$theme = get_option('wrp_form_theme', 'light');
$accent = get_option('wrp_form_accent', 'blue');
$styleOpt = get_option('wrp_form_style', 'rounded');
$wrapper_classes = 'wrp-theme-' . sanitize_html_class($theme) . ' wrp-accent-' . sanitize_html_class($accent) . ' ' . ($styleOpt==='square'?'wrp-style-square':'');
$type_counts = ['text'=>0,'country'=>0,'radio'=>0,'checkbox'=>0];
$countries = [
    '','Afghanistan','Albania','Algeria','Andorra','Angola','Argentina','Armenia','Australia','Austria','Azerbaijan','Bahamas','Bahrain','Bangladesh','Barbados','Belarus','Belgium','Belize','Benin','Bhutan','Bolivia','Bosnia and Herzegovina','Botswana','Brazil','Brunei','Bulgaria','Burkina Faso','Burundi','Cambodia','Cameroon','Canada','Cape Verde','Central African Republic','Chad','Chile','China','Colombia','Comoros','Congo','Costa Rica','Croatia','Cuba','Cyprus','Czech Republic','Denmark','Djibouti','Dominica','Dominican Republic','Ecuador','Egypt','El Salvador','Equatorial Guinea','Eritrea','Estonia','Eswatini','Ethiopia','Fiji','Finland','France','Gabon','Gambia','Georgia','Germany','Ghana','Greece','Grenada','Guatemala','Guinea','Guinea-Bissau','Guyana','Haiti','Honduras','Hong Kong','Hungary','Iceland','India','Indonesia','Iran','Iraq','Ireland','Israel','Italy','Ivory Coast','Jamaica','Japan','Jordan','Kazakhstan','Kenya','Kiribati','Kuwait','Kyrgyzstan','Laos','Latvia','Lebanon','Lesotho','Liberia','Libya','Liechtenstein','Lithuania','Luxembourg','Madagascar','Malawi','Malaysia','Maldives','Mali','Malta','Marshall Islands','Mauritania','Mauritius','Mexico','Moldova','Monaco','Mongolia','Montenegro','Morocco','Mozambique','Myanmar','Namibia','Nauru','Nepal','Netherlands','New Zealand','Nicaragua','Niger','Nigeria','North Macedonia','Norway','Oman','Pakistan','Palau','Panama','Papua New Guinea','Paraguay','Peru','Philippines','Poland','Portugal','Qatar','Romania','Russia','Rwanda','Saint Kitts and Nevis','Saint Lucia','Saint Vincent and the Grenadines','Samoa','San Marino','Sao Tome and Principe','Saudi Arabia','Senegal','Serbia','Seychelles','Sierra Leone','Singapore','Slovakia','Slovenia','Solomon Islands','Somalia','South Africa','South Korea','Spain','Sri Lanka','Sudan','Suriname','Sweden','Switzerland','Syria','Taiwan','Tajikistan','Tanzania','Thailand','Togo','Tonga','Trinidad and Tobago','Tunisia','Turkey','Turkmenistan','Tuvalu','Uganda','Ukraine','United Arab Emirates','United Kingdom','United States','Uruguay','Uzbekistan','Vanuatu','Vatican City','Venezuela','Vietnam','Yemen','Zambia','Zimbabwe'
];
?>
<div class="<?php echo esc_attr($wrapper_classes); ?>">
<div class="wrp-form-wrapper">
    <?php if (!empty($messages)): ?>
        <div class="wrp-messages">
            <?php foreach ($messages as $m): ?>
                <div class="wrp-message wrp-<?php echo esc_attr($m['type']); ?>"><?php echo esc_html($m['text']); ?></div>
            <?php endforeach; ?>
        </div>
    <?php endif; ?>

    <?php if (!$success): ?>
    <form method="post" class="wrp-form" autocomplete="off">
        <?php wp_nonce_field('wrp_register_action', 'wrp_nonce'); ?>
        <input type="hidden" name="wrp_register" value="1" />
        <input type="text" name="wrp_website" value="" class="wrp-hp" aria-hidden="true" tabindex="-1" />

        <?php foreach ($form_config as $f): ?>
            <?php 
                $type = isset($f['type']) ? $f['type'] : ''; 
                $label = isset($f['label']) ? $f['label'] : ucfirst($type); 
                $placeholder = isset($f['placeholder']) ? $f['placeholder'] : '';
                $required = !empty($f['required']); 
            ?>
            <div class="wrp-field">
                <?php if ($type === 'username'): ?>
                    <label for="wrp_username"><?php echo esc_html($label); ?></label>
                    <input id="wrp_username" type="text" name="wrp_username" value="<?php echo isset($values['wrp_username']) ? esc_attr($values['wrp_username']) : ''; ?>" placeholder="<?php echo esc_attr($placeholder); ?>" <?php echo $required ? 'required' : ''; ?> />
                <?php elseif ($type === 'email'): ?>
                    <label for="wrp_email"><?php echo esc_html($label); ?></label>
                    <input id="wrp_email" type="email" name="wrp_email" value="<?php echo isset($values['wrp_email']) ? esc_attr($values['wrp_email']) : ''; ?>" placeholder="<?php echo esc_attr($placeholder); ?>" <?php echo $required ? 'required' : ''; ?> />
                <?php elseif ($type === 'first_name'): ?>
                    <label for="wrp_first_name"><?php echo esc_html($label); ?></label>
                    <input id="wrp_first_name" type="text" name="wrp_first_name" value="<?php echo isset($values['wrp_first_name']) ? esc_attr($values['wrp_first_name']) : ''; ?>" placeholder="<?php echo esc_attr($placeholder); ?>" <?php echo $required ? 'required' : ''; ?> />
                <?php elseif ($type === 'last_name'): ?>
                    <label for="wrp_last_name"><?php echo esc_html($label); ?></label>
                    <input id="wrp_last_name" type="text" name="wrp_last_name" value="<?php echo isset($values['wrp_last_name']) ? esc_attr($values['wrp_last_name']) : ''; ?>" placeholder="<?php echo esc_attr($placeholder); ?>" <?php echo $required ? 'required' : ''; ?> />
                <?php elseif ($type === 'password'): ?>
                    <label for="wrp_password"><?php echo esc_html($label); ?></label>
                    <input id="wrp_password" type="password" name="wrp_password" placeholder="<?php echo esc_attr($placeholder); ?>" <?php echo $required ? 'required' : ''; ?> />
                <?php elseif ($type === 'password_confirm'): ?>
                    <label for="wrp_password2"><?php echo esc_html($label); ?></label>
                    <input id="wrp_password2" type="password" name="wrp_password2" placeholder="<?php echo esc_attr($placeholder); ?>" <?php echo $required ? 'required' : ''; ?> />
                <?php elseif ($type === 'text'): ?>
                    <?php $type_counts['text']++; $name = 'wrp_text_' . $type_counts['text']; ?>
                    <label for="<?php echo esc_attr($name); ?>"><?php echo esc_html($label); ?></label>
                    <input id="<?php echo esc_attr($name); ?>" type="text" name="<?php echo esc_attr($name); ?>" value="<?php echo isset($values[$name]) ? esc_attr($values[$name]) : ''; ?>" placeholder="<?php echo esc_attr($placeholder); ?>" <?php echo $required ? 'required' : ''; ?> />
                <?php elseif ($type === 'mobile'): ?>
                    <?php $type_counts['text']++; $name = 'wrp_mobile_' . $type_counts['text']; ?>
                    <label for="<?php echo esc_attr($name); ?>"><?php echo esc_html($label); ?></label>
                    <input id="<?php echo esc_attr($name); ?>" type="tel" name="<?php echo esc_attr($name); ?>" value="<?php echo isset($values[$name]) ? esc_attr($values[$name]) : ''; ?>" placeholder="<?php echo esc_attr($placeholder); ?>" <?php echo $required ? 'required' : ''; ?> />
                <?php elseif ($type === 'organization'): ?>
                    <?php $type_counts['text']++; $name = 'wrp_organization_' . $type_counts['text']; ?>
                    <label for="<?php echo esc_attr($name); ?>"><?php echo esc_html($label); ?></label>
                    <input id="<?php echo esc_attr($name); ?>" type="text" name="<?php echo esc_attr($name); ?>" value="<?php echo isset($values[$name]) ? esc_attr($values[$name]) : ''; ?>" placeholder="<?php echo esc_attr($placeholder); ?>" <?php echo $required ? 'required' : ''; ?> />
                <?php elseif ($type === 'profession'): ?>
                    <?php $type_counts['text']++; $name = 'wrp_profession_' . $type_counts['text']; $val = isset($values[$name]) ? $values[$name] : ''; $professions = get_option('wrp_professions', ['Doctor', 'Engineer', 'Teacher', 'Lawyer', 'Artist']); ?>
                    <label for="<?php echo esc_attr($name); ?>"><?php echo esc_html($label); ?></label>
                    <select id="<?php echo esc_attr($name); ?>" name="<?php echo esc_attr($name); ?>" <?php echo $required ? 'required' : ''; ?>>
                        <option value=""><?php echo esc_html($placeholder ?: 'Select profession...'); ?></option>
                        <?php foreach ($professions as $p): $sel = selected($val, $p, false); ?>
                            <option value="<?php echo esc_attr($p); ?>" <?php echo $sel; ?>><?php echo esc_html($p); ?></option>
                        <?php endforeach; ?>
                    </select>
                <?php elseif ($type === 'country'): ?>
                    <?php $type_counts['country']++; $name = 'wrp_country_' . $type_counts['country']; $val = isset($values[$name]) ? $values[$name] : ''; ?>
                    <label for="<?php echo esc_attr($name); ?>"><?php echo esc_html($label); ?></label>
                    <select id="<?php echo esc_attr($name); ?>" name="<?php echo esc_attr($name); ?>" <?php echo $required ? 'required' : ''; ?>>
                        <option value=""><?php echo esc_html($placeholder ?: 'Select a country'); ?></option>
                        <?php foreach ($countries as $c): $sel = selected($val, $c, false); ?>
                            <option value="<?php echo esc_attr($c); ?>" <?php echo $sel; ?>><?php echo esc_html($c ?: ''); ?></option>
                        <?php endforeach; ?>
                    </select>
                <?php elseif ($type === 'radio'): ?>
                    <?php $type_counts['radio']++; $name = 'wrp_radio_' . $type_counts['radio']; $val = isset($values[$name]) ? $values[$name] : ''; ?>
                    <fieldset>
                        <legend><?php echo esc_html($label); ?><?php echo $required ? ' *' : ''; ?></legend>
                        <label><input type="radio" name="<?php echo esc_attr($name); ?>" value="yes" <?php echo $val==='yes'?'checked':''; ?> <?php echo $required ? 'required' : ''; ?> /> <?php echo esc_html($placeholder ?: 'Yes'); ?></label>
                        <label style="margin-left:12px"><input type="radio" name="<?php echo esc_attr($name); ?>" value="no" <?php echo $val==='no'?'checked':''; ?> <?php echo $required ? 'required' : ''; ?> /> <?php echo esc_html($placeholder ?: 'No'); ?></label>
                    </fieldset>
                <?php elseif ($type === 'checkbox'): ?>
                    <?php $type_counts['checkbox']++; $name = 'wrp_checkbox_' . $type_counts['checkbox']; $val = isset($values[$name]) ? $values[$name] : ''; ?>
                    <label><input type="checkbox" name="<?php echo esc_attr($name); ?>" value="1" <?php echo ($val==='1')?'checked':''; ?> <?php echo $required ? 'required' : ''; ?> /> <?php echo esc_html($placeholder ?: $label); ?></label>
                <?php endif; ?>
            </div>
        <?php endforeach; ?>

        <div class="wrp-actions">
            <button type="submit" class="wrp-btn">Register</button>
        </div>
    </form>
    <?php else: ?>
        <?php if (!empty($created_unique_id)): ?>
            <div class="wrp-field"><strong>Your ID:</strong> <?php echo esc_html($created_unique_id); ?></div>
        <?php endif; ?>
        <?php if (!empty($created_qr_url)): ?>
            <div class="wrp-field"><img alt="Your QR Code" src="<?php echo esc_url($created_qr_url); ?>" style="max-width:240px;height:auto;border:1px solid #cbd5e1;border-radius:6px;padding:6px;background:#fff;" /></div>
        <?php endif; ?>
        <?php if (is_user_logged_in()): ?>
            <div class="wrp-field">
                <strong>Next steps:</strong>
            </div>
            <div class="wrp-field">
                <?php echo do_shortcode('[wrp_edit_profile]'); ?>
            </div>
            <div class="wrp-field">
                <?php echo do_shortcode('[wrp_logout]'); ?>
            </div>
            <div class="wrp-field">
                <?php echo do_shortcode('[wrp_delete_account]'); ?>
            </div>
        <?php endif; ?>
    <?php endif; ?>
</div>
</div>