<?php
// Shared library functions for SimpleRegistration index site

function sr_generate_signed_url(array $config, string $file, string $version): string {
    $exp = time() + (int)$config['security']['download_token_ttl'];
    $secret = $config['security']['download_secret'];
    $params = http_build_query(['v' => $version, 'file' => $file, 'exp' => $exp]);
    $sig = hash_hmac('sha256', $params, $secret);
    return 'download.php?' . $params . '&sig=' . $sig;
}

function sr_classify_release(array $item): string {
    $channel = strtolower($item['channel'] ?? 'stable');
    if ($channel === 'beta' || $channel === 'rc') return $channel;
    return ($item['stable'] ?? false) ? 'stable' : 'previous';
}

function sr_load_versions(array $config): array {
    $cacheFile = $config['paths']['data'] . '/versions.cache.php';
    $versionsFile = __DIR__ . '/versions.json';
    $ttl = (int)$config['cache']['versions_ttl'];
    if (file_exists($cacheFile)) {
        $cached = include $cacheFile;
        if (is_array($cached) && isset($cached['time']) && (time() - $cached['time']) < $ttl) {
            return $cached['data'];
        }
    }
    $json = file_get_contents($versionsFile);
    $data = json_decode($json, true) ?: [];
    if (!is_dir($config['paths']['data'])) {
        @mkdir($config['paths']['data'], 0775, true);
    }
    $payload = var_export(['time' => time(), 'data' => $data], true);
    file_put_contents($cacheFile, "<?php\nreturn ${payload};\n");
    return $data;
}

?>