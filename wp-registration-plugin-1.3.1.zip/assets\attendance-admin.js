/**
 * WRP Attendance Admin JavaScript
 */
(function($) {
    'use strict';

    $(document).ready(function() {
        // Any admin-specific JS can go here
    });

})(jQuery);
