<?php if (!defined('ABSPATH')) { exit; } ?>
<div class="wrap wrp-admin-attendance">
    <h1>Attendance Management</h1>
    
    <div class="wrp-admin-tabs">
        <a href="<?php echo admin_url('admin.php?page=wrp-attendance'); ?>" class="wrp-tab active">Daily List</a>
        <a href="<?php echo admin_url('admin.php?page=wrp-attendance&view=report'); ?>" class="wrp-tab">Reports</a>
        <a href="<?php echo admin_url('admin.php?page=wrp-attendance&view=manual'); ?>" class="wrp-tab">Manual Entry</a>
    </div>

    <div class="wrp-filters">
        <form method="get" style="display: inline-block;">
            <input type="hidden" name="page" value="wrp-attendance" />
            <label>Date:</label>
            <input type="date" name="date" value="<?php echo esc_attr($date_filter); ?>" />
            
            <label>User:</label>
            <select name="user_id">
                <option value="">All Users</option>
                <?php
                $users = get_users(['orderby' => 'display_name']);
                foreach ($users as $u) {
                    $selected = selected($user_filter, $u->ID, false);
                    echo '<option value="' . esc_attr($u->ID) . '" ' . $selected . '>' . esc_html($u->display_name) . '</option>';
                }
                ?>
            </select>
            
            <button type="submit" class="button">Filter</button>
            <a href="<?php echo admin_url('admin.php?page=wrp-attendance'); ?>" class="button">Reset</a>
        </form>

        <div style="float: right;">
            <button id="wrp-export-csv" class="button button-primary">Export CSV</button>
        </div>
    </div>

    <table class="wp-list-table widefat fixed striped">
        <thead>
            <tr>
                <th>ID</th>
                <th>User</th>
                <th>Unique ID</th>
                <th>Check In</th>
                <th>Check Out</th>
                <th>Duration</th>
                <th>Status</th>
                <th>IP Address</th>
                <th>Notes</th>
            </tr>
        </thead>
        <tbody>
            <?php if (empty($records)): ?>
                <tr>
                    <td colspan="9" style="text-align: center;">No records found for this date.</td>
                </tr>
            <?php else: ?>
                <?php foreach ($records as $record): ?>
                    <tr>
                        <td><?php echo esc_html($record->id); ?></td>
                        <td><?php echo esc_html($record->display_name); ?><br><small><?php echo esc_html($record->user_email); ?></small></td>
                        <td><?php echo esc_html($record->unique_id); ?></td>
                        <td><?php echo esc_html(date('H:i:s', strtotime($record->check_in))); ?></td>
                        <td>
                            <?php 
                            if ($record->check_out) {
                                echo esc_html(date('H:i:s', strtotime($record->check_out)));
                            } else {
                                echo '<span style="color: #999;">—</span>';
                            }
                            ?>
                        </td>
                        <td>
                            <?php 
                            if ($record->check_out) {
                                $diff = strtotime($record->check_out) - strtotime($record->check_in);
                                $hours = floor($diff / 3600);
                                $minutes = floor(($diff % 3600) / 60);
                                echo esc_html($hours . 'h ' . $minutes . 'm');
                            } else {
                                echo '<span style="color: #999;">—</span>';
                            }
                            ?>
                        </td>
                        <td>
                            <span class="wrp-status-badge wrp-status-<?php echo esc_attr($record->status); ?>">
                                <?php echo esc_html(ucfirst($record->status)); ?>
                            </span>
                        </td>
                        <td><small><?php echo esc_html($record->ip_address ?: '—'); ?></small></td>
                        <td><?php echo esc_html($record->notes ?: '—'); ?></td>
                    </tr>
                <?php endforeach; ?>
            <?php endif; ?>
        </tbody>
    </table>
</div>

<style>
.wrp-admin-attendance {
    margin-top: 20px;
}

.wrp-admin-tabs {
    margin: 20px 0;
    border-bottom: 2px solid #e5e7eb;
}

.wrp-tab {
    display: inline-block;
    padding: 10px 20px;
    text-decoration: none;
    color: #6b7280;
    border-bottom: 2px solid transparent;
    margin-bottom: -2px;
}

.wrp-tab.active {
    color: #2563eb;
    border-bottom-color: #2563eb;
    font-weight: 600;
}

.wrp-filters {
    background: #f9fafb;
    padding: 15px;
    border-radius: 6px;
    margin: 20px 0;
    overflow: hidden;
}

.wrp-filters label {
    margin: 0 10px 0 15px;
    font-weight: 500;
}

.wrp-filters input[type="date"],
.wrp-filters select {
    padding: 6px 10px;
    border: 1px solid #d1d5db;
    border-radius: 4px;
}

.wrp-status-badge {
    display: inline-block;
    padding: 4px 12px;
    border-radius: 12px;
    font-size: 12px;
    font-weight: 500;
}

.wrp-status-present {
    background: #dcfce7;
    color: #166534;
}

.wrp-status-absent {
    background: #fee2e2;
    color: #991b1b;
}

.wrp-status-late {
    background: #fef3c7;
    color: #92400e;
}
</style>

<script>
jQuery(document).ready(function($) {
    $('#wrp-export-csv').on('click', function() {
        var date = $('input[name="date"]').val();
        window.location.href = ajaxurl + '?action=wrp_export_attendance&nonce=' + WRP_ATTENDANCE_ADMIN.nonce + '&start_date=' + date + '&end_date=' + date;
    });
});
</script>
