<?php if (!defined('ABSPATH')) { exit; } ?>
<div class="wrap wrp-admin-attendance">
    <h1>Attendance Reports</h1>
    
    <div class="wrp-admin-tabs">
        <a href="<?php echo admin_url('admin.php?page=wrp-attendance'); ?>" class="wrp-tab">Daily List</a>
        <a href="<?php echo admin_url('admin.php?page=wrp-attendance&view=report'); ?>" class="wrp-tab active">Reports</a>
        <a href="<?php echo admin_url('admin.php?page=wrp-attendance&view=manual'); ?>" class="wrp-tab">Manual Entry</a>
    </div>

    <div class="wrp-filters">
        <form method="get">
            <input type="hidden" name="page" value="wrp-attendance" />
            <input type="hidden" name="view" value="report" />
            
            <label>From:</label>
            <input type="date" name="start_date" value="<?php echo esc_attr($start_date); ?>" />
            
            <label>To:</label>
            <input type="date" name="end_date" value="<?php echo esc_attr($end_date); ?>" />
            
            <button type="submit" class="button button-primary">Generate Report</button>
        </form>
    </div>

    <div class="wrp-report-stats">
        <div class="wrp-stat-card">
            <div class="wrp-stat-value"><?php echo esc_html($stats['total_records']); ?></div>
            <div class="wrp-stat-label">Total Records</div>
        </div>
        <div class="wrp-stat-card">
            <div class="wrp-stat-value"><?php echo esc_html($stats['unique_users']); ?></div>
            <div class="wrp-stat-label">Unique Users</div>
        </div>
        <div class="wrp-stat-card">
            <div class="wrp-stat-value">
                <?php echo esc_html(isset($stats['by_status']['present']) ? $stats['by_status']['present']->count : 0); ?>
            </div>
            <div class="wrp-stat-label">Present</div>
        </div>
        <div class="wrp-stat-card">
            <div class="wrp-stat-value">
                <?php echo esc_html(isset($stats['by_status']['absent']) ? $stats['by_status']['absent']->count : 0); ?>
            </div>
            <div class="wrp-stat-label">Absent</div>
        </div>
    </div>

    <h2>Daily Breakdown</h2>
    <table class="wp-list-table widefat fixed striped">
        <thead>
            <tr>
                <th>Date</th>
                <th>Check-ins</th>
            </tr>
        </thead>
        <tbody>
            <?php if (empty($stats['daily_stats'])): ?>
                <tr>
                    <td colspan="2" style="text-align: center;">No data for selected period.</td>
                </tr>
            <?php else: ?>
                <?php foreach ($stats['daily_stats'] as $day): ?>
                    <tr>
                        <td><?php echo esc_html(date('l, F j, Y', strtotime($day->date))); ?></td>
                        <td><?php echo esc_html($day->count); ?></td>
                    </tr>
                <?php endforeach; ?>
            <?php endif; ?>
        </tbody>
    </table>
</div>

<style>
.wrp-report-stats {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
    gap: 20px;
    margin: 30px 0;
}

.wrp-stat-card {
    background: white;
    border: 1px solid #e5e7eb;
    border-radius: 8px;
    padding: 20px;
    text-align: center;
}

.wrp-stat-value {
    font-size: 32px;
    font-weight: 700;
    color: #1f2937;
    margin-bottom: 8px;
}

.wrp-stat-label {
    font-size: 14px;
    color: #6b7280;
    text-transform: uppercase;
    letter-spacing: 0.5px;
}
</style>
