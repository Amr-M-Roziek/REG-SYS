/* SimpleRegistration index interactions */
function formatMB(bytes){return (bytes/1048576).toFixed(2)}
function parseDate(s){return s? new Date(s): null}
function withinRange(d, from, to){
  if(!d) return true;
  if(from && d < from) return false;
  if(to && d > to) return false;
  return true;
}

function badgeClass(channel){
  const ch = (channel||'stable').toLowerCase();
  if(ch==='beta' || ch==='rc') return ch;
  return ch==='stable' ? 'stable' : 'previous';
}

function renderList(list){
  const root = document.getElementById('versionList');
  root.innerHTML = '';
  list.forEach(item => {
    const card = document.createElement('div');
    card.className = 'card';
    const header = document.createElement('div');
    header.className = 'card-header';
    const title = document.createElement('div');
    title.innerHTML = `<strong>v${item.version}</strong>`;
    const badge = document.createElement('span');
    badge.className = 'badge ' + badgeClass(item.channel);
    badge.textContent = (item.channel||'stable').toUpperCase();
    header.appendChild(title); header.appendChild(badge);
    card.appendChild(header);

    const meta = document.createElement('div');
    meta.className = 'meta';
    const dt = new Date(item.release_date);
    meta.textContent = `Released ${dt.toLocaleDateString()} • ${formatMB(item.size_bytes)} MB`;
    card.appendChild(meta);

    const checksum = document.createElement('div');
    checksum.className = 'checksum';
    checksum.textContent = item.sha256;
    card.appendChild(checksum);

    const actions = document.createElement('div');
    actions.className = 'actions';
    const a = document.createElement('a');
    a.className = 'btn primary';
    a.href = `download.php?v=${encodeURIComponent(item.version)}&file=${encodeURIComponent(item.file)}&exp=${Math.floor(Date.now()/1000)+600}&sig=`; // will be swapped by server if used via SSR; fallback client uses direct link
    a.textContent = 'Download';
    // Direct link fallback for static hosting
    a.href = item.direct_url || a.href;
    actions.appendChild(a);

    const info = document.createElement('a');
    info.className = 'btn secondary';
    info.href = item.direct_url;
    info.textContent = 'View';
    actions.appendChild(info);

    const statsEl = document.createElement('div');
    statsEl.className = 'meta';
    statsEl.textContent = 'Downloads: …';
    actions.appendChild(statsEl);

    card.appendChild(actions);
    root.appendChild(card);
  });
}

function filterVersions(){
  const all = window.__SR_VERSIONS__ || [];
  const q = document.getElementById('searchVersion').value.trim().toLowerCase();
  const df = document.getElementById('dateFrom').value ? new Date(document.getElementById('dateFrom').value) : null;
  const dt = document.getElementById('dateTo').value ? new Date(document.getElementById('dateTo').value) : null;
  const minMB = parseFloat(document.getElementById('sizeThreshold').value||'0');
  const minBytes = isNaN(minMB)?0: Math.floor(minMB*1048576);
  const list = all.filter(v => {
    const matchVersion = !q || (`${v.version}`.toLowerCase().includes(q));
    const releaseDate = parseDate(v.release_date);
    const matchDate = withinRange(releaseDate, df, dt);
    const matchSize = v.size_bytes >= minBytes;
    return matchVersion && matchDate && matchSize;
  }).sort((a,b)=> new Date(b.release_date)-new Date(a.release_date));
  renderList(list);
}

function bindControls(){
  ['searchVersion','dateFrom','dateTo','sizeThreshold'].forEach(id => {
    const el = document.getElementById(id);
    el.addEventListener('input', filterVersions);
    el.addEventListener('change', filterVersions);
  });
}

async function loadStats(){
  try{
    const res = await fetch('stats.php');
    const json = await res.json();
    const root = document.getElementById('versionList');
    Array.from(root.children).forEach((card, idx)=>{
      const v = (window.__SR_VERSIONS__||[])[idx];
      const meta = card.querySelector('.actions .meta');
      if(v && meta && json[v.version]){
        meta.textContent = `Downloads: ${json[v.version].downloads}`;
      } else if(meta){ meta.textContent = 'Downloads: 0'; }
    });
  }catch(e){/* ignore */}
}

document.addEventListener('DOMContentLoaded', ()=>{
  bindControls();
  filterVersions();
  loadStats();
});

// Expose for tests
window.__SR_FILTER__ = { filterVersions, withinRange };