<?php if (!defined('ABSPATH')) { exit; } ?>
<div class="wrap wrp-admin-attendance">
    <h1>Manual Attendance Entry</h1>
    
    <div class="wrp-admin-tabs">
        <a href="<?php echo admin_url('admin.php?page=wrp-attendance'); ?>" class="wrp-tab">Daily List</a>
        <a href="<?php echo admin_url('admin.php?page=wrp-attendance&view=report'); ?>" class="wrp-tab">Reports</a>
        <a href="<?php echo admin_url('admin.php?page=wrp-attendance&view=manual'); ?>" class="wrp-tab active">Manual Entry</a>
    </div>

    <div class="wrp-manual-form">
        <form id="wrp-admin-manual-form">
            <table class="form-table">
                <tbody>
                    <tr>
                        <th><label for="user_id">User *</label></th>
                        <td>
                            <select id="user_id" name="user_id" required style="width: 300px;">
                                <option value="">Select User</option>
                                <?php foreach ($users as $u): ?>
                                    <option value="<?php echo esc_attr($u->ID); ?>">
                                        <?php echo esc_html($u->display_name . ' (' . $u->user_email . ')'); ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </td>
                    </tr>
                    <tr>
                        <th><label for="date">Date *</label></th>
                        <td>
                            <input type="date" id="date" name="date" value="<?php echo esc_attr(current_time('Y-m-d')); ?>" required />
                        </td>
                    </tr>
                    <tr>
                        <th><label for="status">Status *</label></th>
                        <td>
                            <select id="status" name="status" required>
                                <option value="present">Present</option>
                                <option value="absent">Absent</option>
                                <option value="late">Late</option>
                                <option value="excused">Excused</option>
                            </select>
                        </td>
                    </tr>
                    <tr>
                        <th><label for="notes">Notes</label></th>
                        <td>
                            <textarea id="notes" name="notes" rows="3" style="width: 400px;"></textarea>
                        </td>
                    </tr>
                </tbody>
            </table>
            
            <p class="submit">
                <button type="submit" class="button button-primary">Add Attendance Record</button>
            </p>
        </form>

        <div id="wrp-manual-result" style="margin-top: 20px;"></div>
    </div>
</div>

<style>
.wrp-manual-form {
    background: white;
    padding: 20px;
    border: 1px solid #e5e7eb;
    border-radius: 8px;
    margin-top: 20px;
}
</style>

<script>
jQuery(document).ready(function($) {
    $('#wrp-admin-manual-form').on('submit', function(e) {
        e.preventDefault();
        
        var formData = {
            action: 'wrp_manual_attendance',
            nonce: WRP_ATTENDANCE_ADMIN.nonce,
            user_id: $('#user_id').val(),
            date: $('#date').val(),
            status: $('#status').val(),
            notes: $('#notes').val()
        };

        $.post(WRP_ATTENDANCE_ADMIN.ajax_url, formData, function(response) {
            if (response.success) {
                $('#wrp-manual-result').html('<div class="notice notice-success"><p>' + response.data.message + '</p></div>');
                $('#wrp-admin-manual-form')[0].reset();
            } else {
                $('#wrp-manual-result').html('<div class="notice notice-error"><p>' + response.data.message + '</p></div>');
            }
        });
    });
});
</script>
