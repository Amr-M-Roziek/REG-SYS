    public function find_page_with_shortcode($shortcode)
    {
        $pages = get_pages(['post_status' => 'publish']);
        foreach ($pages as $p) {
            if (function_exists('has_shortcode') && has_shortcode($p->post_content, $shortcode)) {
                return (int)$p->ID;
            }
        }
        return 0;
    }

    public function find_qr_profile_page()
    {
        $pages = get_pages(['post_status' => 'publish']);
        foreach ($pages as $p) {
            $has_qr = function_exists('has_shortcode') && has_shortcode($p->post_content, 'wrp_user_qr');
            $has_profile = function_exists('has_shortcode') && has_shortcode($p->post_content, 'wrp_edit_profile');
            if ($has_qr && $has_profile) { return (int)$p->ID; }
        }
        return 0;
    }
}