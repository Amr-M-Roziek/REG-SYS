<?php if (!defined('ABSPATH')) { exit; } ?>
<div class="wrp-my-attendance">
    <h2>My Attendance History</h2>
    
    <?php if (empty($records)): ?>
        <p>No attendance records found.</p>
    <?php else: ?>
        <table class="wrp-attendance-table">
            <thead>
                <tr>
                    <th>Date</th>
                    <th>Check In</th>
                    <th>Check Out</th>
                    <th>Duration</th>
                    <th>Status</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($records as $record): ?>
                    <tr>
                        <td><?php echo esc_html(date('M d, Y', strtotime($record->check_in))); ?></td>
                        <td><?php echo esc_html(date('H:i', strtotime($record->check_in))); ?></td>
                        <td>
                            <?php 
                            if ($record->check_out) {
                                echo esc_html(date('H:i', strtotime($record->check_out)));
                            } else {
                                echo '—';
                            }
                            ?>
                        </td>
                        <td>
                            <?php 
                            if ($record->check_out) {
                                $diff = strtotime($record->check_out) - strtotime($record->check_in);
                                $hours = floor($diff / 3600);
                                $minutes = floor(($diff % 3600) / 60);
                                echo esc_html($hours . 'h ' . $minutes . 'm');
                            } else {
                                echo '—';
                            }
                            ?>
                        </td>
                        <td>
                            <span class="wrp-status-badge wrp-status-<?php echo esc_attr($record->status); ?>">
                                <?php echo esc_html(ucfirst($record->status)); ?>
                            </span>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    <?php endif; ?>
</div>

<style>
.wrp-my-attendance {
    padding: 20px;
}

.wrp-attendance-table {
    width: 100%;
    border-collapse: collapse;
    margin-top: 20px;
}

.wrp-attendance-table th,
.wrp-attendance-table td {
    padding: 12px;
    text-align: left;
    border-bottom: 1px solid #e2e8f0;
}

.wrp-attendance-table th {
    background: #f1f5f9;
    font-weight: 600;
}

.wrp-attendance-table tr:hover {
    background: #f8fafc;
}

.wrp-status-badge {
    display: inline-block;
    padding: 4px 12px;
    border-radius: 12px;
    font-size: 12px;
    font-weight: 500;
}

.wrp-status-present {
    background: #dcfce7;
    color: #166534;
}

.wrp-status-absent {
    background: #fee2e2;
    color: #991b1b;
}

.wrp-status-late {
    background: #fef3c7;
    color: #92400e;
}
</style>
