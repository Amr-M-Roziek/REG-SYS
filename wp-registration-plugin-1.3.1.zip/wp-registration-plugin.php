<?php
/*
Plugin Name: Simple Registration Form (WRP)
Description: Provides shortcode `[wrp_registration_form]` to render a secure user registration form with configurable role and email notifications. Includes QR code-based attendance tracking system.
Version: 1.3.1
Author: Reg-sys.com
Author URI: http://reg-sys.com
*/

if (!defined('ABSPATH')) {
    exit;
}

define('WRP_PLUGIN_VERSION', '1.3.1');
define('WRP_PLUGIN_DIR', plugin_dir_path(__FILE__));
define('WRP_PLUGIN_URL', plugin_dir_url(__FILE__));
define('WRP_MIN_PHP', '7.4.0');
define('WRP_MAX_TESTED_PHP', '8.2.999');

// Version guard: prevent activation on too-old PHP and show notice in admin
function wrp_php_version_supported() {
    return version_compare(PHP_VERSION, WRP_MIN_PHP, '>=');
}

function wrp_show_php_version_notice() {
    if (wrp_php_version_supported()) { return; }
    add_action('admin_notices', function () {
        echo '<div class="notice notice-error"><p>'
            . esc_html__('Simple Registration Form (WRP) requires PHP ', 'wrp')
            . esc_html(WRP_MIN_PHP)
            . esc_html__(' or higher. Your server is running PHP ', 'wrp')
            . esc_html(PHP_VERSION)
            . esc_html__('. Please upgrade PHP to use this plugin.', 'wrp')
            . '</p></div>';
    });
}

wrp_show_php_version_notice();

register_activation_hook(__FILE__, function () {
    if (!wrp_php_version_supported()) {
        deactivate_plugins(plugin_basename(__FILE__));
        wp_die('Simple Registration Form (WRP) requires PHP ' . esc_html(WRP_MIN_PHP) . '. Your version: ' . esc_html(PHP_VERSION));
    }
    // Create attendance table
    require_once __DIR__ . '/includes/class-wrp-attendance.php';
    WRP_Attendance::create_table();
    
    // Auto-create required pages
    require_once __DIR__ . '/includes/class-wrp-plugin.php';
    $plugin = WRP_Plugin::instance();
    $plugin->auto_create_pages_on_activation();
});

require_once __DIR__ . '/includes/class-wrp-plugin.php';
require_once __DIR__ . '/includes/class-wrp-builder.php';
require_once __DIR__ . '/includes/class-wrp-admin.php';
require_once __DIR__ . '/includes/class-wrp-attendance.php';

add_action('plugins_loaded', function () {
    if (!wrp_php_version_supported()) { return; }
    \WRP_Plugin::instance();
    \WRP_Builder::instance();
    \WRP_Admin::instance();
    \WRP_Attendance::instance();
});

// Add quick "Settings" link in the Plugins list
add_filter('plugin_action_links_' . plugin_basename(__FILE__), function ($links) {
    $settings_url = admin_url('options-general.php?page=wrp-settings');
    $builder_url = admin_url('admin.php?page=wrp-form-builder');
    $users_url = admin_url('admin.php?page=wrp-users');
    array_unshift($links, '<a href="' . esc_url($settings_url) . '">Settings</a>');
    $links[] = '<a href="' . esc_url($builder_url) . '">Builder</a>';
    $links[] = '<a href="' . esc_url($users_url) . '">Users</a>';
    // Add a Delete link consistent with WordPress UI when plugin is inactive
    $plugin_file = plugin_basename(__FILE__);
    if (current_user_can('delete_plugins') && function_exists('is_plugin_active') && !is_plugin_active($plugin_file)) {
        $delete_url = wp_nonce_url(admin_url('plugins.php?action=delete-selected&checked[]=' . $plugin_file), 'bulk-plugins');
        $links[] = '<a href="' . esc_url($delete_url) . '" class="delete">Delete</a>';
    }
    return $links;
});